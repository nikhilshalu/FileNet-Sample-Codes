﻿//* DISCLAIMER OF WARRANTIES.  This is 
//* sample code created by IBM Corporation.  This sample code is
//* not part of any standard or IBM product and is provided to you
//* solely for the purpose of assisting you in the development of
//* your applications.  The code is provided "AS IS", without
//* warranty of any kind.  IBM shall not be liable for any damages
//* arising out of your use of the sample code, even if it has
//* been advised of the possibility of such damages
/*
 * 
 * IBM grants you a nonexclusive copyright license to use all programming
 * code examples from which you can generate similar function tailored 
 * to your own specific needs.
 * All sample code is provided by IBM for illustrative purposes only.
 * These examples have not been thoroughly tested under all conditions.
 * IBM, therefore cannot guarantee or imply reliability, serviceability, 
 * or function of these programs.
 * All Programs or code component contained herein are provided to you 
 * “AS IS “ without any warranties of any kind.
 * The implied warranties of non-infringement, merchantability and fitness 
 * for a particular purpose are expressly disclaimed.

© Copyright IBM Corporation 2007, ALL RIGHTS RESERVED
*/
using System;
using System.ServiceModel;

using System.ServiceModel.Channels;

using System.ServiceModel.Dispatcher;
using System.ServiceModel.Description;

namespace PE_C_Sharp_solution
{

    public class PEWSCustomBehavior : IEndpointBehavior
    {
        private String peRouter;
        private String theLocale;

        public PEWSCustomBehavior(String router, String locale)
        {
            peRouter = router;
            theLocale = locale;
        }


        public void AddBindingParameters(ServiceEndpoint endpoint,

    System.ServiceModel.Channels.BindingParameterCollection bindingParameters)
        {
        }

        public void ApplyClientBehavior(ServiceEndpoint endpoint, System.ServiceModel.Dispatcher.ClientRuntime

    clientRuntime)
        {
            PEWSClientMessageInspector inspector = new PEWSClientMessageInspector(peRouter, theLocale);
            clientRuntime.MessageInspectors.Add(inspector);
        }

        public void ApplyDispatchBehavior(ServiceEndpoint endpoint, System.ServiceModel.Dispatcher.EndpointDispatcher

    endpointDispatcher)
        {
        }

        public void Validate(ServiceEndpoint endpoint)
        {
        }


    }
}