//* DISCLAIMER OF WARRANTIES.  This is 
//* sample code created by IBM Corporation.  This sample code is
//* not part of any standard or IBM product and is provided to you
//* solely for the purpose of assisting you in the development of
//* your applications.  The code is provided "AS IS", without
//* warranty of any kind.  IBM shall not be liable for any damages
//* arising out of your use of the sample code, even if it has
//* been advised of the possibility of such damages.

/*
 * 
 * IBM grants you a nonexclusive copyright license to use all programming
 * code examples from which you can generate similar function tailored 
 * to your own specific needs.
 * All sample code is provided by IBM for illustrative purposes only.
 * These examples have not been thoroughly tested under all conditions.
 * IBM, therefore cannot guarantee or imply reliability, serviceability, 
 * or function of these programs.
 * All Programs or code component contained herein are provided to you 
 * �AS IS � without any warranties of any kind.
 * The implied warranties of non-infringement, merchantability and fitness 
 * for a particular purpose are expressly disclaimed.

� Copyright IBM Corporation 2007, ALL RIGHTS RESERVED
*/


using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
namespace PE_C_Sharp_solution
{
	/// <summary>
	/// The worklaunch step form contains two datagrids and a listbox. The first datagrid is used to present a list of the 
	/// exposed properties in the launch step selected.	This sample code is able to present all the possible data types with 
	/// the exception of the new XML data type. Additional code would have to be written to ensure that XML data properties 
	/// are correctly handled. Since any of the standard data types can be set up to be either single value or arrays, this 
	/// simple UI uses the second data grid to allow the user to view and/or modify the values of the properties. When 
	/// modifying a value, the Apply button is provided to put the changed value into the step element being worked on. The 
	/// listbox is provided to show the user any step responses.
	/// </summary>
	public class worklaunchstep : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.ListBox lbResponses;
		internal System.Windows.Forms.Button btClose;
		internal System.Windows.Forms.DataGrid dgProperties;
		internal System.Windows.Forms.DataGrid dgProperty;
		internal System.Windows.Forms.Button btLaunch;
		internal System.Windows.Forms.Button btStepApply;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public peFunctions mypeFunctions = new peFunctions();


		public worklaunchstep()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			
		}

		// Processes the selected step element.
		public void loadstep()
		{
			// Populate the datagrid with the step parameters
			mypeFunctions.selectedStepElementIntoDataGrid(dgProperties);
			mypeFunctions.gridApplyStyle(dgProperties);

			// get the step responses. The try/catch is just in case there are no responses and we get a null back
			try
			{
				string[] responses = mypeFunctions.getStepResponses();
				
				foreach (string response in responses)
				{
					lbResponses.Items.Add(response);
				}
				lbResponses.SelectedIndex = 0;
			}
			catch(Exception e)
			{
				lbResponses.Visible = false;
			}

		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lbResponses = new System.Windows.Forms.ListBox();
			this.btClose = new System.Windows.Forms.Button();
			this.dgProperties = new System.Windows.Forms.DataGrid();
			this.dgProperty = new System.Windows.Forms.DataGrid();
			this.btLaunch = new System.Windows.Forms.Button();
			this.btStepApply = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dgProperties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dgProperty)).BeginInit();
			this.SuspendLayout();
			// 
			// lbResponses
			// 
			this.lbResponses.Location = new System.Drawing.Point(408, 344);
			this.lbResponses.Name = "lbResponses";
			this.lbResponses.Size = new System.Drawing.Size(200, 108);
			this.lbResponses.TabIndex = 26;
			this.lbResponses.SelectedIndexChanged += new System.EventHandler(this.lbResponses_SelectedIndexChanged);
			// 
			// btClose
			// 
			this.btClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btClose.Location = new System.Drawing.Point(664, 104);
			this.btClose.Name = "btClose";
			this.btClose.Size = new System.Drawing.Size(88, 24);
			this.btClose.TabIndex = 25;
			this.btClose.Text = "Close";
			// 
			// dgProperties
			// 
			this.dgProperties.DataMember = "";
			this.dgProperties.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgProperties.Location = new System.Drawing.Point(16, 16);
			this.dgProperties.Name = "dgProperties";
			this.dgProperties.ReadOnly = true;
			this.dgProperties.Size = new System.Drawing.Size(384, 440);
			this.dgProperties.TabIndex = 21;
			this.dgProperties.Click += new System.EventHandler(this.dgProperties_Click);
			// 
			// dgProperty
			// 
			this.dgProperty.DataMember = "";
			this.dgProperty.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgProperty.Location = new System.Drawing.Point(408, 16);
			this.dgProperty.Name = "dgProperty";
			this.dgProperty.Size = new System.Drawing.Size(224, 160);
			this.dgProperty.TabIndex = 22;
			// 
			// btLaunch
			// 
			this.btLaunch.Location = new System.Drawing.Point(664, 40);
			this.btLaunch.Name = "btLaunch";
			this.btLaunch.Size = new System.Drawing.Size(88, 24);
			this.btLaunch.TabIndex = 24;
			this.btLaunch.Text = "Launch";
			this.btLaunch.Click += new System.EventHandler(this.btLaunch_Click);
			// 
			// btStepApply
			// 
			this.btStepApply.Location = new System.Drawing.Point(472, 200);
			this.btStepApply.Name = "btStepApply";
			this.btStepApply.Size = new System.Drawing.Size(88, 24);
			this.btStepApply.TabIndex = 23;
			this.btStepApply.Text = "Apply";
			this.btStepApply.Click += new System.EventHandler(this.btStepApply_Click);
			// 
			// worklaunchstep
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(832, 478);
			this.Controls.Add(this.lbResponses);
			this.Controls.Add(this.btClose);
			this.Controls.Add(this.dgProperties);
			this.Controls.Add(this.dgProperty);
			this.Controls.Add(this.btLaunch);
			this.Controls.Add(this.btStepApply);
			this.Name = "worklaunchstep";
			this.Text = "worklaunchstep";
			((System.ComponentModel.ISupportInitialize)(this.dgProperties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dgProperty)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		// Called by event handler to get the properties of a selected step element.
		private void dgProperties_Click(object sender, System.EventArgs ne)
		{
			DataGrid dgSender = (DataGrid)sender;
			int rowid = dgSender.CurrentRowIndex;
			DataView rdv = (DataView)dgSender.DataSource;
			DataTable rdt = rdv.Table;

			string propertyName = (string)rdt.Rows[rowid][rdt.Columns.IndexOf("Property Name")];
			mypeFunctions.selectedStepElementPropertyIntoDataGrid(propertyName, dgProperty);
			mypeFunctions.gridApplyStyle(dgProperty);
		}

		// Called by event handler when Apply button is clicked.
		private void btStepApply_Click(object sender, System.EventArgs e)
		{
			int rowid = dgProperties.CurrentRowIndex;
			DataView rdv = (DataView)dgProperties.DataSource;
			DataTable rdt = rdv.Table;
			string propertyName = (string)rdt.Rows[rowid][rdt.Columns.IndexOf("Property Name")];

			mypeFunctions.applyStepPropertyChanges(propertyName, dgProperty);
		}

		// Calls mypeFunctions.dispatchStepElement() on the selected step element.
		private void btLaunch_Click(object sender, System.EventArgs e)
		{
			mypeFunctions.dispatchStepElement();
			this.Close();
		}

		// Sets the step response string to the name of the selected step element.
		private void lbResponses_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			mypeFunctions.setStepResponse((string)lbResponses.SelectedItem);
		}
	}
}
