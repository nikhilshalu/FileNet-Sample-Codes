//* DISCLAIMER OF WARRANTIES.  This is 
//* sample code created by IBM Corporation.  This sample code is
//* not part of any standard or IBM product and is provided to you
//* solely for the purpose of assisting you in the development of
//* your applications.  The code is provided "AS IS", without
//* warranty of any kind.  IBM shall not be liable for any damages
//* arising out of your use of the sample code, even if it has
//* been advised of the possibility of such damages.

/*
 * 
 * IBM grants you a nonexclusive copyright license to use all programming
 * code examples from which you can generate similar function tailored 
 * to your own specific needs.
 * All sample code is provided by IBM for illustrative purposes only.
 * These examples have not been thoroughly tested under all conditions.
 * IBM, therefore cannot guarantee or imply reliability, serviceability, 
 * or function of these programs.
 * All Programs or code component contained herein are provided to you 
 * �AS IS � without any warranties of any kind.
 * The implied warranties of non-infringement, merchantability and fitness 
 * for a particular purpose are expressly disclaimed.

� Copyright IBM Corporation 2007, ALL RIGHTS RESERVED
*/


using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Collections.Generic;
using System.Text;
using PE_C_Sharp_solution.pewsWCF;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Security;
using System.ServiceModel.Channels;
using System.Security.Cryptography.X509Certificates;
using System.Net;
using System.Net.Security;

namespace PE_C_Sharp_solution
{
	/// <summary>
	/// The main form of the project. The user interface is spit into three 
    /// panels. Logon, Create Work and Queues. The Logon panel allows the 
    /// user to enter the username and password for the system they are 
    /// attaching to. The Create Work panel allows the user to see a list 
    /// of workflows available in the Process Engine. They can then select
    /// one and instantiate a launch step processor. If they launch the 
    /// workflow, the worklaunchstep form is instantiated to handle it.
	/// The Queue panel enables the user to get a list of available queues 
    /// defined in the Process Engine. You can select a queue and list 
    /// either the queue elements or the step elements in that queue. 
    /// You can then select an entry and either display or process it. In 
    /// both of these cases, the stepprocessor form is used.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.GroupBox GroupBox3;
		internal System.Windows.Forms.Button btLaunchWorkflow;
		internal System.Windows.Forms.ListBox lbWorkclasses;
		internal System.Windows.Forms.Button btGetWorkClasses;
		internal System.Windows.Forms.GroupBox GroupBox1;
		internal System.Windows.Forms.Button btViewStep;
		internal System.Windows.Forms.Button btGetQueues;
		internal System.Windows.Forms.ListBox lbQueues;
		internal System.Windows.Forms.Button btnGetQueueElements;
		internal System.Windows.Forms.Button btnGetStepElements;
		internal System.Windows.Forms.DataGrid dgQueueContents;
		internal System.Windows.Forms.Button btProcessStep;
		internal System.Windows.Forms.GroupBox GroupBox2;
		internal System.Windows.Forms.TextBox tbPEWebServiceUrl;
		internal System.Windows.Forms.Label Label3;
		internal System.Windows.Forms.Label Label2;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.TextBox tbUsername;
		internal System.Windows.Forms.Button btLogon;
		internal System.Windows.Forms.TextBox tbPassword;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		public PESession mypeLogon = new PESession();
		private System.Windows.Forms.Button btnGetRosters;
		private System.Windows.Forms.Button btnGetRosterElements;
		private System.Windows.Forms.Button btnStepElementsFromRoster;
		public peFunctions mypeFunctions = new peFunctions();
		internal System.Windows.Forms.Button btnGetMilesontesForRoster_WOB;
		internal System.Windows.Forms.Button btnGetMilestonesForRoster_WFL;
		private System.Windows.Forms.DataGrid dgMilestones;
		internal System.Windows.Forms.Label label4;
		internal System.Windows.Forms.TextBox routerTextBox;
        private Label label5;
        private TextBox LocaleTextBox;
        private CheckBox testCustomAuthCheckBox;
        private CheckBox cbKerberos;
        internal Button btSimpleLaunch;
        private TextBox tbSPN;
        private Button btnMoreAdvancedQuery;
		private bool isRoster= false;
        private static ProcessEngineServiceClient client;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
            // Close the ProcessEngineServiceClient
            if (client != null)
                client.Close();

			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.btSimpleLaunch = new System.Windows.Forms.Button();
            this.btLaunchWorkflow = new System.Windows.Forms.Button();
            this.lbWorkclasses = new System.Windows.Forms.ListBox();
            this.btGetWorkClasses = new System.Windows.Forms.Button();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.btnMoreAdvancedQuery = new System.Windows.Forms.Button();
            this.dgMilestones = new System.Windows.Forms.DataGrid();
            this.btnStepElementsFromRoster = new System.Windows.Forms.Button();
            this.btnGetRosterElements = new System.Windows.Forms.Button();
            this.btnGetRosters = new System.Windows.Forms.Button();
            this.btViewStep = new System.Windows.Forms.Button();
            this.btGetQueues = new System.Windows.Forms.Button();
            this.lbQueues = new System.Windows.Forms.ListBox();
            this.btnGetQueueElements = new System.Windows.Forms.Button();
            this.btnGetStepElements = new System.Windows.Forms.Button();
            this.dgQueueContents = new System.Windows.Forms.DataGrid();
            this.btProcessStep = new System.Windows.Forms.Button();
            this.btnGetMilesontesForRoster_WOB = new System.Windows.Forms.Button();
            this.btnGetMilestonesForRoster_WFL = new System.Windows.Forms.Button();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.tbSPN = new System.Windows.Forms.TextBox();
            this.tbSPN.Visible = false;     // not supported
            this.cbKerberos = new System.Windows.Forms.CheckBox();
            cbKerberos.Visible = false;  // not supported
            this.testCustomAuthCheckBox = new System.Windows.Forms.CheckBox();
            testCustomAuthCheckBox.Visible = false;  // not supported
            this.LocaleTextBox = new System.Windows.Forms.TextBox();
            LocaleTextBox.Visible = false; // not supported
            this.label5 = new System.Windows.Forms.Label();
            label5.Visible = false;  // label for Locale - not supported
            this.tbPEWebServiceUrl = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.tbUsername = new System.Windows.Forms.TextBox();
            this.btLogon = new System.Windows.Forms.Button();
            this.tbPassword = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.routerTextBox = new System.Windows.Forms.TextBox();
            this.GroupBox3.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgMilestones)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgQueueContents)).BeginInit();
            this.GroupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // GroupBox3
            // 
            this.GroupBox3.Controls.Add(this.btSimpleLaunch);
            this.GroupBox3.Location = new System.Drawing.Point(368, 8);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(336, 189);
            this.GroupBox3.TabIndex = 12;
            this.GroupBox3.TabStop = false;
            this.GroupBox3.Text = "Create Work";
            // 
            // btSimpleLaunch
            // 
            this.btSimpleLaunch.Enabled = false;
            this.btSimpleLaunch.Location = new System.Drawing.Point(24, 90);
            this.btSimpleLaunch.Name = "btSimpleLaunch";
            this.btSimpleLaunch.Size = new System.Drawing.Size(112, 24);
            this.btSimpleLaunch.TabIndex = 6;
            this.btSimpleLaunch.Text = "Simple Launch";
            this.btSimpleLaunch.Click += new System.EventHandler(this.btSimpleLaunch_Click);
            // 
            // btLaunchWorkflow
            // 
            this.btLaunchWorkflow.Enabled = false;
            this.btLaunchWorkflow.Location = new System.Drawing.Point(392, 64);
            this.btLaunchWorkflow.Name = "btLaunchWorkflow";
            this.btLaunchWorkflow.Size = new System.Drawing.Size(112, 24);
            this.btLaunchWorkflow.TabIndex = 6;
            this.btLaunchWorkflow.Text = "Launch Workflow";
            this.btLaunchWorkflow.Click += new System.EventHandler(this.btLaunchWorkflow_Click);
            // 
            // lbWorkclasses
            // 
            this.lbWorkclasses.Location = new System.Drawing.Point(512, 24);
            this.lbWorkclasses.Name = "lbWorkclasses";
            this.lbWorkclasses.Size = new System.Drawing.Size(184, 160);
            this.lbWorkclasses.TabIndex = 3;
            this.lbWorkclasses.SelectedIndexChanged += new System.EventHandler(this.lbWorkclasses_SelectedIndexChanged);
            // 
            // btGetWorkClasses
            // 
            this.btGetWorkClasses.Enabled = false;
            this.btGetWorkClasses.Location = new System.Drawing.Point(392, 24);
            this.btGetWorkClasses.Name = "btGetWorkClasses";
            this.btGetWorkClasses.Size = new System.Drawing.Size(112, 24);
            this.btGetWorkClasses.TabIndex = 4;
            this.btGetWorkClasses.Text = "Get Work Classes";
            this.btGetWorkClasses.Click += new System.EventHandler(this.btGetWorkClasses_Click);
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.btnMoreAdvancedQuery);
            this.GroupBox1.Controls.Add(this.dgMilestones);
            this.GroupBox1.Controls.Add(this.btnStepElementsFromRoster);
            this.GroupBox1.Controls.Add(this.btnGetRosterElements);
            this.GroupBox1.Controls.Add(this.btnGetRosters);
            this.GroupBox1.Controls.Add(this.btViewStep);
            this.GroupBox1.Controls.Add(this.btGetQueues);
            this.GroupBox1.Controls.Add(this.lbQueues);
            this.GroupBox1.Controls.Add(this.btnGetQueueElements);
            this.GroupBox1.Controls.Add(this.btnGetStepElements);
            this.GroupBox1.Controls.Add(this.dgQueueContents);
            this.GroupBox1.Controls.Add(this.btProcessStep);
            this.GroupBox1.Controls.Add(this.btnGetMilesontesForRoster_WOB);
            this.GroupBox1.Controls.Add(this.btnGetMilestonesForRoster_WFL);
            this.GroupBox1.Location = new System.Drawing.Point(8, 203);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(738, 471);
            this.GroupBox1.TabIndex = 10;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Queues/Rosters";
            // 
            // btnMoreAdvancedQuery
            // 
            this.btnMoreAdvancedQuery.Enabled = false;
            this.btnMoreAdvancedQuery.Location = new System.Drawing.Point(400, 95);
            this.btnMoreAdvancedQuery.Name = "btnMoreAdvancedQuery";
            this.btnMoreAdvancedQuery.Size = new System.Drawing.Size(247, 23);
            this.btnMoreAdvancedQuery.TabIndex = 18;
            this.btnMoreAdvancedQuery.Text = "More Advanced Queries...";
            this.btnMoreAdvancedQuery.UseVisualStyleBackColor = true;
            this.btnMoreAdvancedQuery.Click += new System.EventHandler(this.MoreAdvancedQueryButton_Click);
            // 
            // dgMilestones
            // 
            this.dgMilestones.DataMember = "";
            this.dgMilestones.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgMilestones.Location = new System.Drawing.Point(22, 375);
            this.dgMilestones.Name = "dgMilestones";
            this.dgMilestones.Size = new System.Drawing.Size(704, 80);
            this.dgMilestones.TabIndex = 17;
            // 
            // btnStepElementsFromRoster
            // 
            this.btnStepElementsFromRoster.Enabled = false;
            this.btnStepElementsFromRoster.Location = new System.Drawing.Point(468, 53);
            this.btnStepElementsFromRoster.Name = "btnStepElementsFromRoster";
            this.btnStepElementsFromRoster.Size = new System.Drawing.Size(179, 32);
            this.btnStepElementsFromRoster.TabIndex = 16;
            this.btnStepElementsFromRoster.Text = "Step Elements from Roster";
            this.btnStepElementsFromRoster.Click += new System.EventHandler(this.btnStepElementsFromRoster_Click);
            // 
            // btnGetRosterElements
            // 
            this.btnGetRosterElements.Enabled = false;
            this.btnGetRosterElements.Location = new System.Drawing.Point(468, 19);
            this.btnGetRosterElements.Name = "btnGetRosterElements";
            this.btnGetRosterElements.Size = new System.Drawing.Size(179, 32);
            this.btnGetRosterElements.TabIndex = 15;
            this.btnGetRosterElements.Text = "Get Roster ElementsEx";
            this.btnGetRosterElements.Click += new System.EventHandler(this.btnGetRosterElements_Click);
            // 
            // btnGetRosters
            // 
            this.btnGetRosters.Enabled = false;
            this.btnGetRosters.Location = new System.Drawing.Point(16, 56);
            this.btnGetRosters.Name = "btnGetRosters";
            this.btnGetRosters.Size = new System.Drawing.Size(112, 23);
            this.btnGetRosters.TabIndex = 14;
            this.btnGetRosters.Text = "Get Rosters";
            this.btnGetRosters.Click += new System.EventHandler(this.btnGetRosters_Click);
            // 
            // btViewStep
            // 
            this.btViewStep.Enabled = false;
            this.btViewStep.Location = new System.Drawing.Point(19, 342);
            this.btViewStep.Name = "btViewStep";
            this.btViewStep.Size = new System.Drawing.Size(88, 24);
            this.btViewStep.TabIndex = 13;
            this.btViewStep.Text = "View Step";
            this.btViewStep.Click += new System.EventHandler(this.btViewStep_Click);
            // 
            // btGetQueues
            // 
            this.btGetQueues.Enabled = false;
            this.btGetQueues.Location = new System.Drawing.Point(16, 24);
            this.btGetQueues.Name = "btGetQueues";
            this.btGetQueues.Size = new System.Drawing.Size(112, 24);
            this.btGetQueues.TabIndex = 4;
            this.btGetQueues.Text = "Get queues";
            this.btGetQueues.Click += new System.EventHandler(this.btGetQueues_Click);
            // 
            // lbQueues
            // 
            this.lbQueues.Location = new System.Drawing.Point(136, 16);
            this.lbQueues.Name = "lbQueues";
            this.lbQueues.Size = new System.Drawing.Size(312, 69);
            this.lbQueues.TabIndex = 3;
            this.lbQueues.SelectedIndexChanged += new System.EventHandler(this.lbQueues_SelectedIndexChanged);
            // 
            // btnGetQueueElements
            // 
            this.btnGetQueueElements.Enabled = false;
            this.btnGetQueueElements.Location = new System.Drawing.Point(204, 91);
            this.btnGetQueueElements.Name = "btnGetQueueElements";
            this.btnGetQueueElements.Size = new System.Drawing.Size(171, 32);
            this.btnGetQueueElements.TabIndex = 6;
            this.btnGetQueueElements.Text = "Get Queue Elements";
            this.btnGetQueueElements.Click += new System.EventHandler(this.btnGetQueueElements_Click);
            // 
            // btnGetStepElements
            // 
            this.btnGetStepElements.Enabled = false;
            this.btnGetStepElements.Location = new System.Drawing.Point(22, 91);
            this.btnGetStepElements.Name = "btnGetStepElements";
            this.btnGetStepElements.Size = new System.Drawing.Size(173, 30);
            this.btnGetStepElements.TabIndex = 6;
            this.btnGetStepElements.Text = "Step Elements from queue";
            this.btnGetStepElements.Click += new System.EventHandler(this.btnGetStepElements_Click);
            // 
            // dgQueueContents
            // 
            this.dgQueueContents.DataMember = "";
            this.dgQueueContents.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgQueueContents.Location = new System.Drawing.Point(19, 134);
            this.dgQueueContents.Name = "dgQueueContents";
            this.dgQueueContents.ReadOnly = true;
            this.dgQueueContents.Size = new System.Drawing.Size(704, 200);
            this.dgQueueContents.TabIndex = 5;
            this.dgQueueContents.Click += new System.EventHandler(this.dgQueueContents_Click);
            // 
            // btProcessStep
            // 
            this.btProcessStep.Enabled = false;
            this.btProcessStep.Location = new System.Drawing.Point(115, 342);
            this.btProcessStep.Name = "btProcessStep";
            this.btProcessStep.Size = new System.Drawing.Size(88, 24);
            this.btProcessStep.TabIndex = 13;
            this.btProcessStep.Text = "Process Step";
            this.btProcessStep.Click += new System.EventHandler(this.btProcessStep_Click);
            // 
            // btnGetMilesontesForRoster_WOB
            // 
            this.btnGetMilesontesForRoster_WOB.Enabled = false;
            this.btnGetMilesontesForRoster_WOB.Location = new System.Drawing.Point(267, 342);
            this.btnGetMilesontesForRoster_WOB.Name = "btnGetMilesontesForRoster_WOB";
            this.btnGetMilesontesForRoster_WOB.Size = new System.Drawing.Size(208, 24);
            this.btnGetMilesontesForRoster_WOB.TabIndex = 13;
            this.btnGetMilesontesForRoster_WOB.Text = "getMilestonesForRosterElement_WOB";
            this.btnGetMilesontesForRoster_WOB.Click += new System.EventHandler(this.btnGetMilesontesForRoster_WOB_Click);
            // 
            // btnGetMilestonesForRoster_WFL
            // 
            this.btnGetMilestonesForRoster_WFL.Enabled = false;
            this.btnGetMilestonesForRoster_WFL.Location = new System.Drawing.Point(483, 342);
            this.btnGetMilestonesForRoster_WFL.Name = "btnGetMilestonesForRoster_WFL";
            this.btnGetMilestonesForRoster_WFL.Size = new System.Drawing.Size(216, 24);
            this.btnGetMilestonesForRoster_WFL.TabIndex = 13;
            this.btnGetMilestonesForRoster_WFL.Text = "getMilestonesForRosterElement_WFL";
            this.btnGetMilestonesForRoster_WFL.Click += new System.EventHandler(this.btnGetMilestonesForRoster_WFL_Click);
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.tbSPN);
            this.GroupBox2.Controls.Add(this.cbKerberos);
            this.GroupBox2.Controls.Add(this.testCustomAuthCheckBox);
            this.GroupBox2.Controls.Add(this.LocaleTextBox);
            this.GroupBox2.Controls.Add(this.label5);
            this.GroupBox2.Controls.Add(this.tbPEWebServiceUrl);
            this.GroupBox2.Controls.Add(this.Label3);
            this.GroupBox2.Controls.Add(this.Label2);
            this.GroupBox2.Controls.Add(this.Label1);
            this.GroupBox2.Controls.Add(this.tbUsername);
            this.GroupBox2.Controls.Add(this.btLogon);
            this.GroupBox2.Controls.Add(this.tbPassword);
            this.GroupBox2.Controls.Add(this.label4);
            this.GroupBox2.Controls.Add(this.routerTextBox);
            this.GroupBox2.Location = new System.Drawing.Point(8, 8);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(344, 189);
            this.GroupBox2.TabIndex = 11;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Logon";
            // 
            // tbSPN
            // 
            this.tbSPN.Location = new System.Drawing.Point(110, 156);
            this.tbSPN.Name = "tbSPN";
            this.tbSPN.Size = new System.Drawing.Size(226, 20);
            this.tbSPN.TabIndex = 13;
            this.tbSPN.TextChanged += new System.EventHandler(this.tbSPN_TextChanged);
            // 
            // cbKerberos
            // 
            this.cbKerberos.AutoSize = true;
            this.cbKerberos.Location = new System.Drawing.Point(16, 159);
            this.cbKerberos.Name = "cbKerberos";
            this.cbKerberos.Size = new System.Drawing.Size(88, 17);
            this.cbKerberos.TabIndex = 12;
            this.cbKerberos.Text = "use Kerberos";
            this.cbKerberos.UseVisualStyleBackColor = true;
            this.cbKerberos.CheckedChanged += new System.EventHandler(this.cbKerberos_CheckedChanged);
            // 
            // testCustomAuthCheckBox
            // 
            this.testCustomAuthCheckBox.AutoSize = true;
            this.testCustomAuthCheckBox.Location = new System.Drawing.Point(16, 141);
            this.testCustomAuthCheckBox.Name = "testCustomAuthCheckBox";
            this.testCustomAuthCheckBox.Size = new System.Drawing.Size(150, 17);
            this.testCustomAuthCheckBox.TabIndex = 11;
            this.testCustomAuthCheckBox.Text = "test custom authentication";
            this.testCustomAuthCheckBox.UseVisualStyleBackColor = true;
            this.testCustomAuthCheckBox.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // LocaleTextBox
            // 
            this.LocaleTextBox.Location = new System.Drawing.Point(128, 122);
            this.LocaleTextBox.Name = "LocaleTextBox";
            this.LocaleTextBox.Size = new System.Drawing.Size(100, 20);
            this.LocaleTextBox.TabIndex = 10;
            this.LocaleTextBox.Text = "en_US";
            this.LocaleTextBox.TextChanged += new System.EventHandler(this.LocaleTextBox_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 125);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Locale";
            // 
            // tbPEWebServiceUrl
            // 
            this.tbPEWebServiceUrl.Location = new System.Drawing.Point(128, 16);
            this.tbPEWebServiceUrl.Name = "tbPEWebServiceUrl";
            this.tbPEWebServiceUrl.Size = new System.Drawing.Size(208, 20);
            this.tbPEWebServiceUrl.TabIndex = 8;
            this.tbPEWebServiceUrl.Text = "http://xxxx:###/wsi/ProcessEngineWS";
            // 
            // Label3
            // 
            this.Label3.Location = new System.Drawing.Point(16, 16);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(104, 24);
            this.Label3.TabIndex = 7;
            this.Label3.Text = "PE Web Service Url";
            // 
            // Label2
            // 
            this.Label2.Location = new System.Drawing.Point(16, 64);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(56, 16);
            this.Label2.TabIndex = 6;
            this.Label2.Text = "Password";
            // 
            // Label1
            // 
            this.Label1.Location = new System.Drawing.Point(16, 40);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(56, 16);
            this.Label1.TabIndex = 5;
            this.Label1.Text = "Username";
            // 
            // tbUsername
            // 
            this.tbUsername.Location = new System.Drawing.Point(128, 40);
            this.tbUsername.Name = "tbUsername";
            this.tbUsername.Size = new System.Drawing.Size(144, 20);
            this.tbUsername.TabIndex = 1;
            this.tbUsername.Text = "user";
            // 
            // btLogon
            // 
            this.btLogon.Location = new System.Drawing.Point(280, 40);
            this.btLogon.Name = "btLogon";
            this.btLogon.Size = new System.Drawing.Size(56, 48);
            this.btLogon.TabIndex = 0;
            this.btLogon.Text = "Logon";
            this.btLogon.Click += new System.EventHandler(this.btLogon_Click);
            // 
            // tbPassword
            // 
            this.tbPassword.Location = new System.Drawing.Point(128, 64);
            this.tbPassword.Name = "tbPassword";
            this.tbPassword.Size = new System.Drawing.Size(144, 20);
            this.tbPassword.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(19, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Router";
            // 
            // routerTextBox
            // 
            this.routerTextBox.Location = new System.Drawing.Point(128, 96);
            this.routerTextBox.Name = "routerTextBox";
            this.routerTextBox.Size = new System.Drawing.Size(144, 20);
            this.routerTextBox.TabIndex = 2;
            this.routerTextBox.Text = "PEWSConnectionPoint";
            this.routerTextBox.TextChanged += new System.EventHandler(this.routerTextBox_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(765, 670);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.GroupBox2);
            this.Controls.Add(this.btGetWorkClasses);
            this.Controls.Add(this.lbWorkclasses);
            this.Controls.Add(this.btLaunchWorkflow);
            this.Controls.Add(this.GroupBox3);
            this.Name = "Form1";
            this.Text = "VW Web Service Test";
            this.GroupBox3.ResumeLayout(false);
            this.GroupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgMilestones)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgQueueContents)).EndInit();
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox2.PerformLayout();
            this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{			
			//PEHeaderFilter.InstallPEHeaderFilter ();
			Application.Run(new Form1());
		}


		// Sets up the session and enables the GetQueues/GetWorkClasses 
        // buttons (in the Create Work section).
		private void btLogon_Click(object sender, System.EventArgs e)
		{
            // Custom Binding
            BindingElementCollection bec = new BindingElementCollection();

            TransportSecurityBindingElement sbe = SecurityBindingElement.CreateUserNameOverTransportBindingElement();
            sbe.IncludeTimestamp = false;		// Otherwise WCF will expect a timestamp in the response
            bec.Add(sbe);

            TextMessageEncodingBindingElement tme = new TextMessageEncodingBindingElement();
            tme.MessageVersion = MessageVersion.Soap11;
            tme.ReaderQuotas.MaxDepth = 1024;	// maximum depth of XML nesting in responses, YMMV
            tme.ReaderQuotas.MaxStringContentLength = 1024 * 1024;
            // maximum size of content for an XML element in response
            bec.Add(tme);

            // Note that WCF will not allow username/password to be sent over HTTP, must use an HTTPS URL.
            HttpsTransportBindingElement tbe = new HttpsTransportBindingElement();
            tbe.MaxReceivedMessageSize = 2147483647;	// maximum total size of response message
            tbe.MaxBufferSize = 2147483647;
            bec.Add(tbe);

            CustomBinding binding = new CustomBinding(bec);
            // default timeouts too short for CEWS
            binding.ReceiveTimeout = new TimeSpan(10000 * 10000);    // 100 nanonsecond units
            binding.SendTimeout = binding.ReceiveTimeout;

            // initialize the PESession object 
            mypeLogon = new PESession();
            mypeLogon.userName = tbUsername.Text;
            mypeLogon.password = tbPassword.Text;
            mypeLogon.wsUrl = tbPEWebServiceUrl.Text;
            mypeLogon.router = routerTextBox.Text;
            mypeLogon.peLocale = LocaleTextBox.Text;
            mypeLogon.customCredential = testCustomAuthCheckBox.Checked;
            mypeLogon.useKerberos = cbKerberos.Checked;
            if (tbSPN.Text.Trim().Length == 0)
                tbSPN.Text = PESession.GetKerberosSPN(tbPEWebServiceUrl.Text);
            mypeLogon.spn = this.tbSPN.Text;

            // Create an EndPointAddress.
            // url have to be like https format, e.g., https://cmepwin11a:9443/wsi/ProcessEngineWS
            String url = tbPEWebServiceUrl.Text;
            EndpointAddress ea = new EndpointAddress(url);

            // Create a ProcessEngineServiceClient object
            client = new ProcessEngineServiceClient(binding, ea);

            // To insert security header for authentication
            client.ClientCredentials.UserName.UserName = tbUsername.Text;
            client.ClientCredentials.UserName.Password = tbPassword.Text;

            // To insert Router soap header
            PEWSCustomBehavior pewsBehavior = new PEWSCustomBehavior(routerTextBox.Text, null);
            client.Endpoint.Behaviors.Add(pewsBehavior);
            client.Endpoint.Address = new EndpointAddress(url);

            // Open the ProcessEngineServiceClient to call web service operations
            client.Open();

            // set the ProcessEngineServiceClient in these modules to be used later
            mypeLogon.setPEServiceClient(client);
            mypeFunctions.setPEServiceClient(client);

            //If the logon doesn't fail, use it.
            if (mypeLogon.logon())
            {
                mypeFunctions.setPeSession(mypeLogon);
                btGetQueues.Enabled = true;
                btnGetRosters.Enabled = true;
                btGetWorkClasses.Enabled = true;
                btnMoreAdvancedQuery.Enabled = true;
            }
            else
            {
                btGetQueues.Enabled = false;
                btnGetRosters.Enabled = false;
                btGetWorkClasses.Enabled = false;
                btnMoreAdvancedQuery.Enabled = false;
            }

		}

		// Called by event handler to get the list of work classes. 
        // Displayed in the Create Work section when the Get Work Classes button 
        // is clicked.
		private void btGetWorkClasses_Click(object sender, System.EventArgs e)
		{
			ArrayList workClasses  = mypeFunctions.getWorkClasses();
			lbWorkclasses.Items.Clear();
			foreach (string workClass in workClasses)
			{
				lbWorkclasses.Items.Add(workClass);
			}
		}
		private void clearElementsGrid()
		{
			this.dgQueueContents.DataSource = null;
			this.dgQueueContents.CaptionText = "";
			this.btViewStep.Enabled = false;
			this.btProcessStep.Enabled = false;
			this.btnGetMilesontesForRoster_WOB.Enabled = false;
			this.btnGetMilestonesForRoster_WFL.Enabled = false;
		}

        /*
         * Called by event handler to get the list of queue when the Get 
         * Queues button is clicked.
         */
		private void btGetQueues_Click(object sender, System.EventArgs e)
		{
			lbQueues.Items.Clear();
			ArrayList queues = mypeFunctions.getQueues();
			foreach (string queue in queues)
			{
				lbQueues.Items.Add(queue);
			}
			lbQueues.SelectedIndex = 0;
			// need to disable other..
			isRoster = false;
			this.btnGetRosterElements.Enabled = isRoster;
			this.btnStepElementsFromRoster.Enabled = isRoster;
			this.btnGetQueueElements.Enabled = !isRoster;
			this.btnGetStepElements.Enabled = !isRoster;
			clearElementsGrid();
		}

        /**
         * Called by event handler to get the queue elements when the Queue 
		 * Elements from queue button is clicked.
         */

		private void btnGetQueueElements_Click(object sender, System.EventArgs e)
		{
			mypeFunctions.populateQueueElementsIntoDataGrid(dgQueueContents, (string)lbQueues.SelectedItem);
			mypeFunctions.gridApplyStyle(dgQueueContents);
		}

		// Enables the Queue Elements from queue and Step Elements from queue buttons (in the Queues section).
		private void lbQueues_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			this.btnGetRosterElements.Enabled = isRoster;
			this.btnStepElementsFromRoster.Enabled = isRoster;
			this.btnGetQueueElements.Enabled = !isRoster;
			this.btnGetStepElements.Enabled = !isRoster;
		}

		// Called by event handler to get the step elements from the queue. Displayed in the Queues section when the Step Elements from queue
		// button is clicked.
		private void btnGetStepElements_Click(object sender, System.EventArgs e)
		{
			mypeFunctions.populateStepElementsIntoDataGrid(dgQueueContents, (string)lbQueues.SelectedItem);
			mypeFunctions.gridApplyStyle(dgQueueContents);
		}

		// Called by event handler (when the View Step button is clicked) to get the details of the selected workflow step. 
		private void btViewStep_Click(object sender, System.EventArgs e)
		{
			
			// This section checks which line in the dgQueueContents datagrid is selected and gets the 
			// value of the F_WobNum column
			int rowid = dgQueueContents.CurrentRowIndex;
			DataView rdv = (DataView)dgQueueContents.DataSource;
			DataTable rdt = rdv.Table;
			string wobnum = (string)rdt.Rows[rowid][rdt.Columns.IndexOf("F_WobNum")];

			// We now create an instance of the stepprocessor form.
			// The stepprocessor form has its own instance of the helper classses.
			// We give it the current logon session so that it can access the PE.
			stepprocessor stepproc = new stepprocessor();
			stepproc.Text = "View Step";
			//  buttons to enable/disable
	        
			stepproc.btSaveUnlock.Visible = false;
			stepproc.btDispatch.Visible = false;
			stepproc.btStepApply.Visible = false;
			stepproc.btClose.Visible = true;
			stepproc.CancelButton = stepproc.btClose;

            stepproc.mypeFunctions.setPeSession(mypeLogon);
            stepproc.mypeFunctions.setPEServiceClient(client);

			// selectStepElementFromQueueByWobNum does a query for the step.
			// The 'False' parameter means don't lock it since we are only viewing it.
			if (stepproc.mypeFunctions.selectStepElementFromQueueByWobNum((string)lbQueues.SelectedItem, wobnum, false))
			{
				// If the item is found show the form.
				stepproc.loadstep();
				stepproc.ShowDialog();
			}

		}

		// Enables the Launch Workflow button (in the Create Work section).
		private void lbWorkclasses_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			btLaunchWorkflow.Enabled = true;
            btSimpleLaunch.Enabled = true;
			
		}

		/* Called by event handler (when the Launch Workflow button is clicked) to 
           launch a workflow.
         */
		private void btLaunchWorkflow_Click(object sender, System.EventArgs e)
		{
			worklaunchstep  wrkLaunchStep = new worklaunchstep ();
			wrkLaunchStep.mypeFunctions.setPeSession(mypeLogon);
            wrkLaunchStep.mypeFunctions.setPEServiceClient(client);
			wrkLaunchStep.mypeFunctions.createWorkFlowLaunchStepElement((string)lbWorkclasses.SelectedItem);
			wrkLaunchStep.loadstep();
			wrkLaunchStep.ShowDialog();
		}

        /* Called by event handler (when the SimpleLaunch Workflow button is clicked) to 
   launch a workflow.
 */
        private void btSimpleLaunch_Click(object sender, System.EventArgs e)
        {
            simpleLaunchStep mySimpleLaunchStep = new simpleLaunchStep(client);
            mySimpleLaunchStep.launch((string)lbWorkclasses.SelectedItem);
        }
		// Called when the Process Step button is clicked.
		private void btProcessStep_Click(object sender, System.EventArgs e)
		{
			// This section checks which line in the dgQueueContents datagrid is selected and gets the 
			// value of the F_WobNum column
			int rowid = dgQueueContents.CurrentRowIndex;
			DataView rdv = (DataView)dgQueueContents.DataSource;
			DataTable rdt = rdv.Table;
			string wobnum = (string)rdt.Rows[rowid][rdt.Columns.IndexOf("F_WobNum")];

			// We now create an instance of the stepprocessor form
			// The stepprocessor form has its own instance of the helperclassses
			// We give it the current logon session so that it can access the PE
			stepprocessor stepproc = new stepprocessor();
			stepproc.Text = "Process Step";

			// buttons to enable/disable
		    stepproc.btSaveUnlock.Visible = true;
            stepproc.btDispatch.Visible = true;
            stepproc.btStepApply.Visible = true;
            stepproc.btClose.Visible = false;
        
            stepproc.mypeFunctions.setPeSession(mypeLogon);
            stepproc.mypeFunctions.setPEServiceClient(client);

			if (stepproc.mypeFunctions.retrieveStep((string)lbQueues.SelectedItem, wobnum, true))
			{
				// If the item is found show the form
				stepproc.loadstep();
				stepproc.ShowDialog();
			}
		
		}

		private void btnGetRosters_Click(object sender, System.EventArgs e)
		{
			lbQueues.Items.Clear();
			string[] rosters = mypeFunctions.getRosters();
			foreach (string s in rosters)
			{
				lbQueues.Items.Add(s);
			}
			lbQueues.SelectedIndex = 0;

			// need to disable others..
			// need to disable other..
			isRoster = true;
			this.btnGetRosterElements.Enabled = isRoster;
			this.btnStepElementsFromRoster.Enabled = isRoster;
			this.btnGetQueueElements.Enabled = !isRoster;
			this.btnGetStepElements.Enabled = !isRoster;
			this.clearElementsGrid();
		}

		private void btnGetRosterElements_Click(object sender, System.EventArgs e)
		{
			mypeFunctions.populateRosterElementsIntoDataGrid(dgQueueContents, (string)lbQueues.SelectedItem);
			mypeFunctions.gridApplyStyle(dgQueueContents);
		}

		private void btnStepElementsFromRoster_Click(object sender, System.EventArgs e)
		{
			mypeFunctions.populateStepElementsFromRosterIntoDataGrid(dgQueueContents, (string)lbQueues.SelectedItem);
			mypeFunctions.gridApplyStyle(dgQueueContents);
		}

		private void dgQueueContents_Click(object sender, System.EventArgs e)
		{
			// want to enable accordingly.

			this.btnGetMilestonesForRoster_WFL.Enabled = isRoster;
			this.btnGetMilesontesForRoster_WOB.Enabled = isRoster;

			this.btViewStep.Enabled = true;
			this.btProcessStep.Enabled = true;

		}

		private void btnGetMilesontesForRoster_WOB_Click(object sender, System.EventArgs e)
		{
			getMilestones(true);
		}
		private void getMilestones(bool isWob)
		{
			// This section checks which line in the dgQueueContents datagrid is selected and gets the 
			// value of the F_WobNum column
			int rowid = dgQueueContents.CurrentRowIndex;
			DataView rdv = (DataView)dgQueueContents.DataSource;
            DataTable rdt = rdv.Table;
            string wobnum = (string)rdt.Rows[rowid][rdt.Columns.IndexOf((isWob?"F_WobNum":"F_WorkFlowNumber"))];

			// need to populate the dgMilestones..
			this.mypeFunctions.populateMilestonesIntoDataGrid (this.dgMilestones, wobnum,
				(string)lbQueues.SelectedItem ,isWob);
		}

		private void btnGetMilestonesForRoster_WFL_Click(object sender, System.EventArgs e)
		{
			getMilestones(false);
		}

		private void routerTextBox_TextChanged(object sender, System.EventArgs e)
		{
			mypeLogon.router =routerTextBox.Text ;
		}

        private void LocaleTextBox_TextChanged(object sender, EventArgs e)
        {
            mypeLogon.peLocale = LocaleTextBox.Text;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            mypeLogon.customCredential = testCustomAuthCheckBox.Checked;
        }
        /*
        private void tbPEWebServiceUrl_TextChanged(object sender, EventArgs e)
        {
             tbSPN.Text = PESession.GetKerberosSPN(tbPEWebServiceUrl.Text);
        }
    */
        private void cbKerberos_CheckedChanged(object sender, EventArgs e)
        {
            mypeLogon.useKerberos = cbKerberos.Checked;
        }

        private void MoreAdvancedQueryButton_Click(object sender, EventArgs e)
        {
            QueueQueryForm queryForm = new QueueQueryForm(client);
            queryForm.ShowDialog();
        }

        private void tbSPN_TextChanged(object sender, EventArgs e)
        {
            mypeLogon.spn = tbSPN.Text;
        }
	}
}
