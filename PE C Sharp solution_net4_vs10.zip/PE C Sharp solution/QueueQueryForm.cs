//* DISCLAIMER OF WARRANTIES.  This is 
//* sample code created by IBM Corporation.  This sample code is
//* not part of any standard or IBM product and is provided to you
//* solely for the purpose of assisting you in the development of
//* your applications.  The code is provided "AS IS", without
//* warranty of any kind.  IBM shall not be liable for any damages
//* arising out of your use of the sample code, even if it has
//* been advised of the possibility of such damages.

/*
 * 
 * IBM grants you a nonexclusive copyright license to use all programming
 * code examples from which you can generate similar function tailored 
 * to your own specific needs.
 * All sample code is provided by IBM for illustrative purposes only.
 * These examples have not been thoroughly tested under all conditions.
 * IBM, therefore cannot guarantee or imply reliability, serviceability, 
 * or function of these programs.
 * All Programs or code component contained herein are provided to you 
 * �AS IS � without any warranties of any kind.
 * The implied warranties of non-infringement, merchantability and fitness 
 * for a particular purpose are expressly disclaimed.

� Copyright IBM Corporation 2007, ALL RIGHTS RESERVED
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PE_C_Sharp_solution.pewsWCF;

namespace PE_C_Sharp_solution
{
    public partial class QueueQueryForm : Form
    {
        private int mSelection = 1; //1 for queues, 0 for roster.
        private ProcessEngineServiceClient peWSClient;

        public QueueQueryForm()
        {
            InitializeComponent();
        }
        public QueueQueryForm(ProcessEngineServiceClient client)
        {
            peWSClient = client;
            InitializeComponent();
        }

        private void RosterRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (mSelection == 1)
            {
                // also make sure to disable the text
                btnGetXXXXElementsEx.Enabled = false;
                lbNames.Items.Clear();
                dgQueueContents.DataSource = null;
                mSelection = 0;
                // see if it's previoys roster or not..
                btnGetXXXXWrapped.Text = "GetRosterWrapped";
                btnGetXXXXElementsEx.Text = "GetRosterElementsEx";
                this.ckboxCheckSecurity.Checked = false;

            }
        }

        private void QueueRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (mSelection == 0)
            {                // also make sure to disable the text
                btnGetXXXXElementsEx.Enabled = false;
                lbNames.Items.Clear();
                dgQueueContents.DataSource = null;
                mSelection = 1;
                btnGetXXXXWrapped.Text = "GetQueuesWrapped";
                btnGetXXXXElementsEx.Text = "GetQueueElementsEx";
            }
        }

        private void getXXXXWrappedButton_Click(object sender, EventArgs e)
        {
            lbNames.Items.Clear();
            btnGetXXXXElementsEx.Enabled = false;
            if (rbRoster.Checked)
            {
                GetRosterNamesWrappedRequest req = new GetRosterNamesWrappedRequest();

                string[] rosters = peWSClient.getRosterNamesWrapped(req);
                foreach (string roster in rosters)
                {
                    lbNames.Items.Add(roster);
                }
                if (rosters.Length >0)
                    btnGetXXXXElementsEx.Enabled = true;
            }
            else
                if (rbQueue.Checked)
                {
                    GetQueuesWrappedRequest req = new GetQueuesWrappedRequest();
                    req.checkSecurity = ckboxCheckSecurity.Checked;
                    QueueInfo[] queues = peWSClient.getQueuesWrapped(req);
                    foreach (QueueInfo queue in queues)
                    {
                        if (queue == null)
                            continue;
                        lbNames.Items.Add(queue.Name);
                    }
                    if (queues.Length > 0)
                        btnGetXXXXElementsEx.Enabled = true;
                }
            if (lbNames.Items.Count>0)
                lbNames.SelectedIndex = 0;
           
        }
        private void clearElementsGrid()
        {
            this.dgQueueContents.DataSource = null;
            this.dgQueueContents.CaptionText = "";
        }

        private int getQueryFlagsCount()
        {
            int count = 0;

            if (QUERY_GET_NO_SYSTEM_FIELDS_CHKBOX.Checked)
                count++;
            if (QUERY_GET_NO_TRANSLATED_SYSTEM_FIELDS_CHKBOX.Checked)
                count++;
            if (QUERY_LITE_ELEMENTS_CHKBOX.Checked)
                count++;
            if (QUERY_LOCK_OBJECT_CHKBOX.Checked)
                count++;
            if (QUERY_MAX_VALUES_INCLUSIVE_CHKBOX.Checked)
                count++;
            if (QUERY_MIN_VALUES_INCLUSIVE_CHKBOX.Checked)
                count++;
            if (QUERY_READ_BOUND_CHKBOX.Checked)
                count++;
            if (QUERY_READ_LOCKED_CHKBOX.Checked)
                count++;
            if (QUERY_READ_UNWRITABLE_CHKBOX.Checked)
                count++;
            if (QUERY_RESOLVE_NAMES_CHKBOX.Checked)
                count++;
            return count;
        }
        private QueryFlagEnum?[] getQueryFlags()
        {
            int count = 0;
            int totalCount = getQueryFlagsCount();

            QueryFlagEnum?[] queryFlags = new QueryFlagEnum?[totalCount];
            if (QUERY_GET_NO_SYSTEM_FIELDS_CHKBOX.Checked)
                queryFlags[count++] = QueryFlagEnum.QUERY_GET_NO_SYSTEM_FIELDS;
            if (QUERY_GET_NO_TRANSLATED_SYSTEM_FIELDS_CHKBOX.Checked)
                queryFlags[count++] = QueryFlagEnum.QUERY_GET_NO_TRANSLATED_SYSTEM_FIELDS;
            if (QUERY_LITE_ELEMENTS_CHKBOX.Checked)
                queryFlags[count++] = QueryFlagEnum.QUERY_LITE_ELEMENTS;
            if (QUERY_LOCK_OBJECT_CHKBOX.Checked)
                queryFlags[count++] = QueryFlagEnum.QUERY_LOCK_OBJECTS;
            if (QUERY_MAX_VALUES_INCLUSIVE_CHKBOX.Checked)
                queryFlags[count++] = QueryFlagEnum.QUERY_MAX_VALUES_INCLUSIVE;
            if (QUERY_MIN_VALUES_INCLUSIVE_CHKBOX.Checked)
                queryFlags[count++] = QueryFlagEnum.QUERY_MIN_VALUES_INCLUSIVE;
            if (QUERY_READ_BOUND_CHKBOX.Checked)
                queryFlags[count++] = QueryFlagEnum.QUERY_READ_BOUND;
            if (QUERY_READ_LOCKED_CHKBOX.Checked)
                queryFlags[count++] = QueryFlagEnum.QUERY_READ_LOCKED;
            if (QUERY_READ_UNWRITABLE_CHKBOX.Checked)
                queryFlags[count++] = QueryFlagEnum.QUERY_READ_UNWRITABLE;
            if (QUERY_RESOLVE_NAMES_CHKBOX.Checked)
                queryFlags[count++] = QueryFlagEnum.QUERY_RESOLVE_NAMES;
            return queryFlags;
        }
        private void GetXXXXElementsEx_Click(object sender, EventArgs e)
        {
            try
            {
                //depending on roster or queue,
                if (this.rbRoster.Checked)
                {
                    doGetRosterElementsEx();
                }
                else
                {
                    doGetQueueElementsEx();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private String getTxtBoxValueIfSet(TextBox aTxtBox)
        {
            String s = aTxtBox.Text;
            if (s != null && s.Trim().Length > 0)
                return s;
            return null;
        }
        private char[] splitChars = new char[] { ',' };
        private Value[] getSubstitutionVarsValue()
        {
            //parse the sub var listbox
            int count = lbSubVars.Items.Count;
            Value[] res = new Value[count];
            
            for (int i = 0; i < count; i++)
            {
                res[i] = new Value();
                String s = (String)lbSubVars.Items[i];
                
                String[] ss = s.Split(splitChars);
                // must have 2
                if (ss.Length<2) continue;
                if (ss[1].Equals("boolean"))
                {
                    res[i].Item = ss[0];  // string at least?
                    res[i].ItemElementName = ItemChoiceType.booleanField;
                }
                else if (ss[1].Equals("float"))
                {
                    res[i].Item = double.Parse(ss[0]);
                    res[i].ItemElementName = ItemChoiceType.doubleField;
                }
                else if (ss[1].Equals("int"))
                {
                    res[i].Item = int.Parse(ss[0]);
                    res[i].ItemElementName = ItemChoiceType.integerField;
                }
                else if (ss[1].Equals("time"))
                {
                    res[i].Item = ss[0];    //TBD converting to datetime?
                    res[i].ItemElementName = ItemChoiceType.dateField;
                }
                else if (ss[1].Equals("string"))
                {
                    res[i].Item = ss[0];
                    res[i].ItemElementName = ItemChoiceType.stringField;
                }
            }
            return res;
        }
        private void doGetRosterElementsEx()
        {
            DataTable dt = new DataTable();
            DataView dv = new DataView(dt);
            DataRow dr;
            GetRosterElementsExRequest req = new GetRosterElementsExRequest();
            req.rosterName = (String)lbNames.SelectedItem;
            req.nToReturn = Int32.Parse(txtBoxNtoReturn.Text);
            req.filter = getTxtBoxValueIfSet(txtBoxFilterString);
            req.indexName = getTxtBoxValueIfSet(txtBoxIndexName);
            req.substitutionVars = getSubstitutionVarsValue ();
            String s = getTxtBoxValueIfSet(txtBoxMaxValue);
            if (s != null)
                req.maxValues = s.Split(splitChars );
            s = getTxtBoxValueIfSet(txtBoxMinValue);
            if (s != null)
                req.minValues = s.Split(splitChars );
            req.queryFlags = getQueryFlags();

            RosterElement[] elements=peWSClient.getRosterElementsEx(req);
            			// If we add fields here they are at the left of the array. 
			// All others are added as they are discovered in queue elements.

			dt.Columns.Add(new DataColumn("No.", System.Type.GetType("System.Int32")));
			dt.Columns.Add(new DataColumn("F_Subject", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("F_WobNum", System.Type.GetType("System.String")));

				int i=0;
			try
			{
                foreach (pewsWCF.RosterElement element in elements)
				{
					dr = dt.NewRow();
                    pewsWCF.Field[] fields = element.Fields;
					dr[dt.Columns.IndexOf("No.")] = i++;

                    foreach (pewsWCF.Field field in fields)
					{
						// Only process the field if there is a value
						if (field.Values.Length > 0) 
						{
							// If the column doesn't already exist in the table, add it
							if (dt.Columns.IndexOf(field.Name) < 0)
							{
								dt.Columns.Add(new DataColumn(field.Name, field.Values[0].Item.GetType()));
							}
							// Put the field into the row
							
							dr[dt.Columns.IndexOf(field.Name)] = field.Values[0].Item;
						}
					}
					dt.Rows.Add(dr);
				}
			}
			catch(Exception e)
			{
				Console.WriteLine(e.Message);
			}

	
			dgQueueContents.CaptionText = i+ " roster elements in the " + lbNames.SelectedItem  + " roster";
			dgQueueContents.DataSource = dv;
            gridApplyStyle(dgQueueContents);
		}


        
        private void doGetQueueElementsEx()
        {
           
            DataTable dt = new DataTable();
            DataView dv = new DataView(dt);
            DataRow dr;
            GetQueueElementsExRequest  req = new GetQueueElementsExRequest();
            req.queueName = (String)lbNames.SelectedItem;
            req.nToReturn = Int32.Parse(txtBoxNtoReturn.Text);
            req.filter = getTxtBoxValueIfSet(txtBoxFilterString);
            req.indexName = getTxtBoxValueIfSet(txtBoxIndexName);
            req.substitutionVars = getSubstitutionVarsValue();
            String s = getTxtBoxValueIfSet(txtBoxMaxValue);
            if (s != null)
                req.maxValues = s.Split(splitChars);
            s = getTxtBoxValueIfSet(txtBoxMinValue);
            if (s != null)
                req.minValues = s.Split(splitChars);
            req.queryFlags = getQueryFlags();

            QueueElement [] elements = peWSClient.getQueueElementsEx(req);
            // If we add fields here they are at the left of the array. 
            // All others are added as they are discovered in queue elements.

            dt.Columns.Add(new DataColumn("No.", System.Type.GetType("System.Int32")));
            dt.Columns.Add(new DataColumn("F_Subject", System.Type.GetType("System.String")));
            dt.Columns.Add(new DataColumn("F_WobNum", System.Type.GetType("System.String")));

            int i = 0;
            try
            {
                foreach (pewsWCF.QueueElement element in elements)
                {
                    dr = dt.NewRow();
                    pewsWCF.Field[] fields = element.Fields;
                    dr[dt.Columns.IndexOf("No.")] = i++;


                    foreach (pewsWCF.Field field in fields)
                    {
                        // Only process the field if there is a value
                        if (field.Values.Length > 0)
                        {
                            // If the column doesn't already exist in the table, add it
                            if (dt.Columns.IndexOf(field.Name) < 0)
                            {
                                dt.Columns.Add(new DataColumn(field.Name, field.Values[0].Item.GetType()));
                            }
                            // Put the field into the row

                            dr[dt.Columns.IndexOf(field.Name)] = field.Values[0].Item;
                        }
                    }
                    dt.Rows.Add(dr);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }


            dgQueueContents.CaptionText = i + " queue elements in the " + lbNames.SelectedItem + " queue ";
            dgQueueContents.DataSource = dv;
            gridApplyStyle(dgQueueContents);

        }

        private void txtBoxNewSubVar_TextChanged(object sender, EventArgs e)
        {
            if (txtBoxNewSubVar.Text.Length > 0)
                btnAddSubsVar.Enabled = true;
            else
                btnAddSubsVar.Enabled = false;
        }

        private void btnAddSubsVar_Click(object sender, EventArgs e)
        {
            // add to the sub var list and clear the new subvar
            String val = txtBoxNewSubVar.Text;
            String valType =(String) comboBoxSubVarType.SelectedItem;
            if (valType.Equals("time"))
            {
                //datetimepicker
                val=dateTimePicker1.Text;
            }
            lbSubVars.Items.Add(val + "," + valType);
            txtBoxNewSubVar.Clear();
        }

        private void comboBoxSubVarType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxSubVarType.SelectedItem.Equals("time"))
            {
                // show thedate time picker
                dateTimePicker1.Visible = true;
            }
            else{
                dateTimePicker1.Visible = false;
                 if (comboBoxSubVarType.SelectedItem.Equals ("boolean"))
                {
                    txtBoxNewSubVar.Text="true";
                }
            
            }
        }
        // Applies the data grid styles. Used to apply an easy to read style to the datagrids on all three forms.
        public void gridApplyStyle(DataGrid theDataGrid)
        {
            DataView dv = (DataView)theDataGrid.DataSource;
            DataTable dt = dv.Table;


            DataGridTableStyle grdTableStyle1 = new DataGridTableStyle();

            grdTableStyle1.MappingName = dv.Table.TableName;
            grdTableStyle1.AlternatingBackColor = System.Drawing.Color.SpringGreen;
            grdTableStyle1.BackColor = System.Drawing.Color.White;
            grdTableStyle1.GridLineStyle = System.Windows.Forms.DataGridLineStyle.None;
            grdTableStyle1.GridLineColor = System.Drawing.Color.White;

            if (grdTableStyle1.RowHeadersVisible == true)
            {
                grdTableStyle1.RowHeaderWidth = 10;
            }

            DataGridColumnStyle[] gridColStyleArray = new DataGridColumnStyle[dt.Columns.Count];

            int x = 0;
            foreach (DataColumn column in dt.Columns)
            {
                DataGridTextBoxColumn grdCol = new DataGridTextBoxColumn();
                grdCol.MappingName = column.ColumnName;
                grdCol.HeaderText = column.ColumnName;
                grdCol.Width = 142;
                grdCol.Format = "c";
                grdCol.ReadOnly = false;
                switch (column.DataType.ToString())
                {
                    case "System.Double":
                        grdCol.Format = "r";
                        grdCol.Width = 100;
                        break;
                    case "System.Int32":
                        grdCol.Format = "r";
                        grdCol.Width = 100;
                        break;
                    case "System.Float":
                        grdCol.Format = "r";
                        grdCol.Width = 100;
                        break;
                    case "System.DateTime":
                        grdCol.Format = "f";
                        grdCol.Width = 200;
                        break;
                    default:
                        break;
                }

                gridColStyleArray[x] = grdCol;
                x = x + 1;
            }

            grdTableStyle1.GridColumnStyles.AddRange(gridColStyleArray);

            theDataGrid.TableStyles.Add(grdTableStyle1);
        }


    }
}