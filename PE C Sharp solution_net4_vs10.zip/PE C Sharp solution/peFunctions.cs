//* DISCLAIMER OF WARRANTIES.  This is 
//* sample code created by IBM Corporation.  This sample code is
//* not part of any standard or IBM product and is provided to you
//* solely for the purpose of assisting you in the development of
//* your applications.  The code is provided "AS IS", without
//* warranty of any kind.  IBM shall not be liable for any damages
//* arising out of your use of the sample code, even if it has
//* been advised of the possibility of such damages.

/*
 * 
 * IBM grants you a nonexclusive copyright license to use all programming
 * code examples from which you can generate similar function tailored 
 * to your own specific needs.
 * All sample code is provided by IBM for illustrative purposes only.
 * These examples have not been thoroughly tested under all conditions.
 * IBM, therefore cannot guarantee or imply reliability, serviceability, 
 * or function of these programs.
 * All Programs or code component contained herein are provided to you 
 * �AS IS � without any warranties of any kind.
 * The implied warranties of non-infringement, merchantability and fitness 
 * for a particular purpose are expressly disclaimed.

� Copyright IBM Corporation 2007, ALL RIGHTS RESERVED
*/


using System;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using PE_C_Sharp_solution.pewsWCF;

namespace PE_C_Sharp_solution
{
	/// <summary>
	/// This class performs the bulk of all the Process Engine functionality.
    /// It is an instantiatable class, and contains two private variables, 
    /// logon and stepElement. The logon variable has to be an instance of 
    /// the peLogon class set via the setPeSession method. Many of the methods 
    /// of peFunctions work in the context of a specific stepElement. 
	/// When worklaunchstep or stepprocessor forms are instantiated, each 
    /// has its own instance of peFunctions and a specific stepElement selected.
    /// In a production application, this class could be served as a data
	/// provider. As such, it would be divorced from any direct UI interaction. 
    /// Other classes would perform the functions of translating results f
    /// rom the data provider into UI elements like data grids or list boxes. 
    /// 
    /// Since this sample is intended as a learning tool, the peFunctions 
    /// class interacts directly with datagrid controls. 

	/// </summary>
	public class peFunctions
	{

		private PESession logon;
		private pewsWCF.StepElement stepElement;
		private ProcessEngineServiceClient peWSClient;

		public void setPeSession(PESession peLogon)
		{
			logon = peLogon;
		}

        public void setPEServiceClient(ProcessEngineServiceClient client)
        {
            peWSClient = client;
        }

		// Used by Form1 to get a list of queues that can be accessed.
		public ArrayList getQueues()
		{
			ArrayList arrayQueues = new ArrayList();
            pewsWCF.QueueInfo[] queues = peWSClient.getQueues();

            foreach (pewsWCF.QueueInfo queue in queues)
			{
                if (queue == null)
                    continue;
				arrayQueues.Add(queue.Name);
			}
			return arrayQueues;
		}
		// Used by Form1 to get a list of rosters that can be accessed.
		public string[] getRosters()
		{
			return peWSClient.getRosterNames();
		}
		// Used by Form1 to get a list of available workflows that can be launched.
		public ArrayList getWorkClasses()
		{
			ArrayList arrayWorkClasses = new ArrayList();
			// Get the available workclasses

			string[] workClassNames = peWSClient.getWorkClassNames();
			foreach (string workClassName in workClassNames)
			{
				arrayWorkClasses.Add(workClassName);
			}

			return arrayWorkClasses;
		}

		// Used by Form1 to populate the datagrid with a list of queue elements in the currently selected queue.
		public void populateMilestonesIntoDataGrid(DataGrid dGrid,string queryValue, string rosterName, bool isWOB)
		{
			DataTable dt = new DataTable();
			DataView dv = new DataView(dt);
			DataRow dr;


			pewsWCF.GetMilestoneForRosterElementRequest query = new pewsWCF.GetMilestoneForRosterElementRequest ();
			query.milestoneLevel = 1;
			query.rosterName = rosterName;
			query.queryValue =queryValue;
			if (isWOB)
				query.queryEnum = pewsWCF.MilestoneQueryEnum.MILESTONE_QUERY_WOBNUMBER;
			else
				query.queryEnum = pewsWCF.MilestoneQueryEnum.MILESTONE_QUERY_WORKFLOW_NUMBER;

			pewsWCF.Milestone [] res = peWSClient.getMilestoneForRosterElement(query);
			if (res==null)
				return;

			// If we add fields here they are at the left of the array. 
			// All others are added as they are discovered in queue elements.

			dt.Columns.Add(new DataColumn("Map", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("Message", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("Name", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("Id", System.Type.GetType("System.Int32")));
			dt.Columns.Add(new DataColumn("Level", System.Type.GetType("System.Int32")));
			dt.Columns.Add(new DataColumn("Step Id", System.Type.GetType("System.Int32")));
			dt.Columns.Add(new DataColumn("Date Reached", System.Type.GetType("System.DateTime")));
			//dt.Columns.Add(new DataColumn("Reached Specified", System.Type.GetType("System.Boolean")));
			
	

			try
			{
				foreach (pewsWCF.Milestone m in res)
				{
					if (m.ReachedSpecified)
					{
						dr = dt.NewRow();
						dr[dt.Columns.IndexOf("Map")] = m.Map;
						dr[dt.Columns.IndexOf("Message")] = m.Message;
						dr[dt.Columns.IndexOf("Name")] = m.Name;
						dr[dt.Columns.IndexOf("Id")] = m.Id ;
						dr[dt.Columns.IndexOf("Level")] = m.Level ;
						dr[dt.Columns.IndexOf("Step Id")] = m.StepId;
						dr[dt.Columns.IndexOf("Date Reached")] = m.Reached ;
						dt.Rows.Add(dr);
					}
				}
			}
			catch(Exception e)
			{
				Console.WriteLine(e.Message);
			}
        	dGrid.CaptionText = "Milestones for " +(isWOB?"WOB ":"WORKFLOW ")+ 
                                queryValue + " roster "+rosterName;
			dGrid.DataSource = dv;
		}

		// Used by Form1 to populate the datagrid with a list of queue elements in the currently selected queue.
		public void populateQueueElementsIntoDataGrid(DataGrid dGrid,string queueName)
		{
			DataTable dt = new DataTable();
			DataView dv = new DataView(dt);
			DataRow dr;


			pewsWCF.GetQueueElementsRequest query = new pewsWCF.GetQueueElementsRequest();

            query.queryFlags = new pewsWCF.QueryFlagEnum?[1] { pewsWCF.QueryFlagEnum.QUERY_READ_LOCKED };
			query.nToReturn = 1000;
			query.queueName = queueName;

			pewsWCF.QueueElement[] queueelements = peWSClient.getQueueElements(query);

			// If we add fields here they are at the left of the array. 
			// All others are added as they are discovered in queue elements.

			dt.Columns.Add(new DataColumn("No.", System.Type.GetType("System.Int32")));
			dt.Columns.Add(new DataColumn("F_Subject", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("F_WobNum", System.Type.GetType("System.String")));

				int i = 0;
			try
			{
				foreach (pewsWCF.QueueElement queueelement in queueelements)
				{
					dr = dt.NewRow();
					pewsWCF.Field[] fields = queueelement.Fields;
					dr[dt.Columns.IndexOf("No.")] = i++;

					foreach(pewsWCF.Field field in fields)
					{
						// Only process the field if there is a value
						if (field.Values.Length > 0) 
						{
							// If the column doesn't already exist in the table, add it
							if (dt.Columns.IndexOf(field.Name) < 0)
							{
								dt.Columns.Add(new DataColumn(field.Name, field.Values[0].Item.GetType()));
							}
							// Put the field into the row
							
							dr[dt.Columns.IndexOf(field.Name)] = field.Values[0].Item;
						}
					}
					dt.Rows.Add(dr);
				}
			}
			catch(Exception e)
			{
				Console.WriteLine(e.Message);

			}

	
			dGrid.CaptionText = i+ " queue Elements in the " + queueName + " queue";
			dGrid.DataSource = dv;
		}

		// Used by Form1 to populate the datagrid with a list of queue elements in the currently selected queue.
		public void populateRosterElementsIntoDataGrid(DataGrid dGrid,string rosterName)
		{
			DataTable dt = new DataTable();
			DataView dv = new DataView(dt);
			DataRow dr;

            pewsWCF.GetRosterElementsExRequest query = new pewsWCF.GetRosterElementsExRequest();
            query.queryFlags = new pewsWCF.QueryFlagEnum?[] {pewsWCF.QueryFlagEnum.QUERY_READ_LOCKED
												  , pewsWCF.QueryFlagEnum.QUERY_LITE_ELEMENTS 
											  }; ;
			query.nToReturn = 1000;

			query.rosterName = rosterName;

			pewsWCF.RosterElement[] elements = peWSClient.getRosterElementsEx(query); //.getRosterElements(query);

			// If we add fields here they are at the left of the array. 
			// All others are added as they are discovered in queue elements.

			dt.Columns.Add(new DataColumn("No.", System.Type.GetType("System.Int32")));
			dt.Columns.Add(new DataColumn("F_Subject", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("F_WobNum", System.Type.GetType("System.String")));

				int i=0;
			try
			{
				foreach (pewsWCF.RosterElement element in elements)
				{
					dr = dt.NewRow();
					pewsWCF.Field[] fields = element.Fields;
					dr[dt.Columns.IndexOf("No.")] = i++;

					foreach(pewsWCF.Field field in fields)
					{
						// Only process the field if there is a value
						if (field.Values.Length > 0) 
						{
							// If the column doesn't already exist in the table, add it
							if (dt.Columns.IndexOf(field.Name) < 0)
							{
								dt.Columns.Add(new DataColumn(field.Name, field.Values[0].Item.GetType()));
							}
							// Put the field into the row
							
							dr[dt.Columns.IndexOf(field.Name)] = field.Values[0].Item;
						}
					}
					dt.Rows.Add(dr);
				}
			}
			catch(Exception e)
			{
				Console.WriteLine(e.Message);
			}

	
			dGrid.CaptionText = i+ " roster elements in the " + rosterName + " roster";
			dGrid.DataSource = dv;
		}


		// Used by Form1 to populate the datagrid with a list of step elements in the currently selected queue.
		public void populateStepElementsIntoDataGrid(DataGrid dGrid,string queueName)
		{
			DataTable dt = new DataTable();
			DataRow dr;
			DataView dv  = new DataView(dt);
			
			
			pewsWCF.GetStepElementsFromQueueRequest query = new pewsWCF.GetStepElementsFromQueueRequest();

			query.queueName = queueName;
			query.nToReturn = 1000;
            query.queryFlags = new pewsWCF.QueryFlagEnum?[] {pewsWCF.QueryFlagEnum.QUERY_GET_NO_SYSTEM_FIELDS,
											 pewsWCF.QueryFlagEnum.QUERY_READ_LOCKED }; ;
			
			pewsWCF.StepElement[] stepelements = peWSClient.getStepElementsFromQueue(query);
			
			//	 If we add fields here they are at the left of the array. 
			//	 All others are added as they are discovered in step elements
			//
			dt.Columns.Add(new DataColumn("No.", System.Type.GetType("System.Int32")));
			dt.Columns.Add(new DataColumn("F_Subject", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("F_WobNum", System.Type.GetType("System.String")));
			
				int i=0;
			try
			{
		
				//	For Each step element in stepelements
				foreach (pewsWCF.StepElement stepelement in stepelements)
				{
					dr = dt.NewRow();
					pewsWCF.Parameter[] parameters = stepelement.Parameters;
					dr[dt.Columns.IndexOf("No.")] = i++;
					
					
					dr[dt.Columns.IndexOf("F_WobNum")] = stepelement.WOBNumber;
					
					foreach(pewsWCF.Parameter param in parameters)
					{

						//	Only process the parameter if there is a value
						if (param.Values.Length > 0)
						{
							//	If the column doesnt already exist in the table, add it
							if(dt.Columns.IndexOf(param.Name) < 0)
							{
								dt.Columns.Add(new DataColumn(param.Name, System.Type.GetType("System.String")));
							}
							//	' Put the parameter into the row
							dr[dt.Columns.IndexOf(param.Name)] = getParamValuesAsString(param);
						}
					}
					
					dt.Rows.Add(dr);
				}
			}
			catch(Exception e)
			{
				Console.WriteLine(e.Message);
			}

			dGrid.CaptionText = i+ " Step Elements in the " + queueName + " queue";
			dGrid.DataSource = dv;
			
		}
		
		// Used by Form1 to populate the datagrid with a list of step elements in the currently selected queue.
		public void populateStepElementsFromRosterIntoDataGrid(DataGrid dGrid,string rosterName)
		{
			DataTable dt = new DataTable();
			DataRow dr;
			DataView dv  = new DataView(dt);			
			
			pewsWCF.GetStepElementsFromRosterRequest query = new pewsWCF.GetStepElementsFromRosterRequest();

			query.rosterName = rosterName;
			query.nToReturn = 1000;
            query.queryFlags = new pewsWCF.QueryFlagEnum?[] {//pewsWCF.QueryFlagEnum.QUERY_GET_NO_SYSTEM_FIELDS,
												pewsWCF.QueryFlagEnum.QUERY_READ_LOCKED }; ;
			
			pewsWCF.StepElement[] stepelements = peWSClient.getStepElementsFromRoster(query);
			
			//	 If we add fields here they are at the left of the array. 
			//	 All others are added as they are discovered in step elements
			//
			dt.Columns.Add(new DataColumn("No.", System.Type.GetType("System.Int32")));
			dt.Columns.Add(new DataColumn("F_Subject", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("F_WobNum", System.Type.GetType("System.String")));
			
			int i=0;
			try
			{
				//	For Each step element in stepelements
				foreach (pewsWCF.StepElement stepelement in stepelements)
				{
					dr = dt.NewRow();
					pewsWCF.Parameter[] parameters = stepelement.Parameters;
					dr[dt.Columns.IndexOf("No.")] = i++;
					
					dr[dt.Columns.IndexOf("F_WobNum")] = stepelement.WOBNumber;
					
					foreach(pewsWCF.Parameter param in parameters)
					{

						//	Only process the parameter if there is a value
						if (param.Values.Length > 0)
						{
							//	If the column doesnt already exist in the table, add it
							if(dt.Columns.IndexOf(param.Name) < 0)
							{
								dt.Columns.Add(new DataColumn(param.Name, System.Type.GetType("System.String")));
							}
							//	' Put the parameter into the row
							dr[dt.Columns.IndexOf(param.Name)] = getParamValuesAsString(param);
						}
					}
					
					dt.Rows.Add(dr);
				}
			}
			catch(Exception e)
			{
				Console.WriteLine(e.Message);
			}

			dGrid.CaptionText = i+" Step Elements in the " + rosterName + " roster";
			dGrid.DataSource = dv;
			
		}

		// Used by Form1 to create a launch stepelement in preparation for displaying the launch form. This method sets 
		// the private variable stepElement.

		public pewsWCF.StepElement createWorkFlowLaunchStepElement(string workflowName)
		{
		
			stepElement = peWSClient.createWorkflow(workflowName);
            return stepElement;
		
		}

		public pewsWCF.Parameter getParameter(string sePropertyName, pewsWCF.StepElement aStepElement)
		{
			if (aStepElement==null)
				aStepElement = stepElement;
			if (aStepElement==null)	// still null
				return null;
			pewsWCF.Parameter[] parameters = aStepElement.Parameters;
			
			foreach(pewsWCF.Parameter param in parameters)
				if (param.Name == sePropertyName)
					return param;
			return null;
		}

		// Gets the properties of a step element for display.
		public void selectedStepElementPropertyIntoDataGrid(string sePropertyName,DataGrid dataGrid)
		{
			DataTable dt = new DataTable();
			DataRow dr;
			DataView dv = new DataView(dt);
				
			bool readOnly = false;
			pewsWCF.Parameter[] parameters = stepElement.Parameters;
			
			//Responses as pewsWCF.ArrayOfResponse = stepElement.Responses
								
			foreach(pewsWCF.Parameter param in parameters)
			{
				if (param.Name == sePropertyName)
				{
					readOnly = param.Mode == pewsWCF.ModeTypeEnum.MODE_TYPE_IN;
					switch(param.Type)
					{
						case pewsWCF.FieldTypeEnum.FIELD_TYPE_ATTACHMENT:
							dt.Columns.Add(new DataColumn("Value", System.Type.GetType("System.String")));
							dt.Columns.Add(new DataColumn("Description", System.Type.GetType("System.String")));
							dt.Columns.Add(new DataColumn("Id", System.Type.GetType("System.String")));
							dt.Columns.Add(new DataColumn("Library", System.Type.GetType("System.String")));
							dt.Columns.Add(new DataColumn("LibraryType", System.Type.GetType("System.String")));
							dt.Columns.Add(new DataColumn("Name", System.Type.GetType("System.String")));
							dt.Columns.Add(new DataColumn("Type", System.Type.GetType("System.String")));
							dt.Columns.Add(new DataColumn("Version", System.Type.GetType("System.String")));
							break;
						case pewsWCF.FieldTypeEnum.FIELD_TYPE_BOOLEAN:
							dt.Columns.Add(new DataColumn("Value", System.Type.GetType("System.Boolean")));
							break;
						case pewsWCF.FieldTypeEnum.FIELD_TYPE_DOUBLE:
							dt.Columns.Add(new DataColumn("Value", System.Type.GetType("System.Double")));
							break;
						case pewsWCF.FieldTypeEnum.FIELD_TYPE_INTEGER:
							dt.Columns.Add(new DataColumn("Value", System.Type.GetType("System.Int32")));
							break;
						case pewsWCF.FieldTypeEnum.FIELD_TYPE_PARTICIPANT:
							dt.Columns.Add(new DataColumn("Value", System.Type.GetType("System.String")));
							break;
						case pewsWCF.FieldTypeEnum.FIELD_TYPE_STRING:
							dt.Columns.Add(new DataColumn("Value", System.Type.GetType("System.String")));
							break;
						case pewsWCF.FieldTypeEnum.FIELD_TYPE_TIME:
							dt.Columns.Add(new DataColumn("Value", System.Type.GetType("System.DateTime")));
							break;
						default:
							break;
					}
					
					
					if( param.Values.Length > 0)
					{
						foreach( pewsWCF.Value stepvalue in param.Values)
						{
							dr = dt.NewRow();
							switch(param.Type)
							{
								case pewsWCF.FieldTypeEnum.FIELD_TYPE_ATTACHMENT:
									pewsWCF.Attachment peAttachment  = (pewsWCF.Attachment)stepvalue.Item;

                                    //peAttachment.LibraryType = pewsWCF.LibraryTypeEnum.LIBRARY_TYPE_CONTENT_ENGINE;

									dr[dt.Columns.IndexOf("Description")] = peAttachment.Description;
									dr[dt.Columns.IndexOf("Id")] = peAttachment.Id;
									dr[dt.Columns.IndexOf("Library")] = peAttachment.Library;
									dr[dt.Columns.IndexOf("Value")] = peAttachment.LibraryType;
									dr[dt.Columns.IndexOf("Name")] = peAttachment.Name;
									dr[dt.Columns.IndexOf("Type")] = peAttachment.Type;
									dr[dt.Columns.IndexOf("Version")] = peAttachment.Version;
									break;
								case pewsWCF.FieldTypeEnum.FIELD_TYPE_BOOLEAN:
									dr[dt.Columns.IndexOf("Value")] = stepvalue.Item;
									break;
								case pewsWCF.FieldTypeEnum.FIELD_TYPE_DOUBLE:
									dr[dt.Columns.IndexOf("Value")] = stepvalue.Item;
									break;
								case pewsWCF.FieldTypeEnum.FIELD_TYPE_INTEGER:
									dr[dt.Columns.IndexOf("Value")] = stepvalue.Item;
									break;
								case pewsWCF.FieldTypeEnum.FIELD_TYPE_PARTICIPANT:
									dr[dt.Columns.IndexOf("Value")] = stepvalue.Item;
									break;
								case pewsWCF.FieldTypeEnum.FIELD_TYPE_STRING:
									dr[dt.Columns.IndexOf("Value")] = stepvalue.Item;
									break;
								case pewsWCF.FieldTypeEnum.FIELD_TYPE_TIME:
									dr[dt.Columns.IndexOf("Value")] = stepvalue.Item;
									break;
								default:
									break;
							}
							dt.Rows.Add(dr);
						}
					}


				}
			}
			dataGrid.CaptionText = "Property:" + sePropertyName +(readOnly?" (READONLY)":" (MODIFIABLE)");
			dataGrid.DataSource = dv;
			
		}
		

		private string stepSubject =null;
		// Used by both launch and stepprocessor form to populate the list of step properties into a datagrid.
		public void selectedStepElementIntoDataGrid(DataGrid dataGrid)
		{
		
			DataTable dt = new DataTable();
			
			DataView dv = new DataView(dt);
			DataRow dr = dt.NewRow();
		
			dt.Columns.Add(new DataColumn("Property Name", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("Type", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("Array?", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("Mode", System.Type.GetType("System.String")));
			dt.Columns.Add(new DataColumn("Value", System.Type.GetType("System.String")));							

			pewsWCF.Parameter[] parameters = stepElement.Parameters;
								
				
			foreach (pewsWCF.Parameter parameter in parameters)
			{
								
				String s = getParamValuesAsString(parameter);					   
				dr = dt.NewRow();
				dr[dt.Columns.IndexOf("Property Name")] = parameter.Name;
				dr[dt.Columns.IndexOf("Type")] = parameter.Type;
				dr[dt.Columns.IndexOf("Array?")] = parameter.IsArray;
				dr[dt.Columns.IndexOf("Mode")] = parameter.Mode;
				dr[dt.Columns.IndexOf("Value")] = s;
				dt.Rows.Add(dr);
				if (parameter.Name=="F_Subject")
					stepSubject = s;
			}
				
				
			dataGrid.DataSource = dv;
			dataGrid.CaptionText = stepElement.StepName+":"+stepSubject;		
		}

		// returns string format of the parameter values..
		public string getParamValuesAsString(pewsWCF.Parameter param)
		{
			string res = "";
			if (param==null)
				return res;
			int i=0;
			if( param.Values.Length > 0)
			{
				foreach( pewsWCF.Value stepvalue in param.Values)
				{
					switch(param.Type)
					{
						case pewsWCF.FieldTypeEnum.FIELD_TYPE_ATTACHMENT:
							pewsWCF.Attachment peAttachment  = (pewsWCF.Attachment)stepvalue.Item;
							String s = "{"+peAttachment.Description+"|"
										+ peAttachment.Id + "|"
										+ peAttachment.Library + "|"
										+ peAttachment.LibraryType + "|"
										+ peAttachment.Name + "|"
										+ peAttachment.Type + "|"
										+ peAttachment.Version + "}";
							res+=s;
							break;
						default:
							res+=stepvalue.Item;
							break;
					}
					i++;
					if (i<param.Values.Length)
						res+=",";
				}
			}			
			return res;
		}
		public bool retrieveStep(string queueName, string wobNum, bool lockitem)
		{
			pewsWCF.RetrieveStepRequest req = new pewsWCF.RetrieveStepRequest();
			req.bLock = lockitem;
			req.bOverrideLock = true;
			req.queueName = queueName;
			req.wobNum = wobNum;
			pewsWCF.GetStepElementsFromQueueRequest qry = new pewsWCF.GetStepElementsFromQueueRequest();
			req.queryFlags = new pewsWCF.QueryFlagEnum? []{pewsWCF.QueryFlagEnum.QUERY_NO_OPTIONS};
			
			stepElement = peWSClient.retrieveStep(req);
			
			if (stepElement==null)
			{
				System.Windows.Forms.MessageBox.Show("Queue: "+queueName+":  Failed to retrieve work object: "+wobNum);
				return false;
			}
			return true;
		}

		// Used by Form1 to select and optionally lock a workitem. This method set the private variable stepElement.
		public bool selectStepElementFromQueueByWobNum(string queueName, string wobNum, bool lockitem)
		{
			pewsWCF.GetStepElementsFromQueueRequest qry = new pewsWCF.GetStepElementsFromQueueRequest();
			pewsWCF.QueryFlagEnum?[] qryflgs = new pewsWCF.QueryFlagEnum?[]{pewsWCF.QueryFlagEnum.QUERY_MIN_VALUES_INCLUSIVE, 
											pewsWCF.QueryFlagEnum.QUERY_MAX_VALUES_INCLUSIVE,
											pewsWCF.QueryFlagEnum.QUERY_READ_LOCKED };
            pewsWCF.QueryFlagEnum?[] qryflgslock = new pewsWCF.QueryFlagEnum?[]{pewsWCF.QueryFlagEnum.QUERY_MIN_VALUES_INCLUSIVE, 
												   pewsWCF.QueryFlagEnum.QUERY_MAX_VALUES_INCLUSIVE, 
												pewsWCF.QueryFlagEnum.QUERY_LOCK_OBJECTS};
			
			qry.queueName = queueName;
			qry.nToReturn = 1;
			
			if (lockitem)
			{
				qry.queryFlags = qryflgslock;
			}
			else
			{
				qry.queryFlags = qryflgs;
			}
			
			qry.indexName = "F_WobNum";
			
			string[] minmaxvals  = {wobNum};
			qry.minValues = minmaxvals;
			qry.maxValues = minmaxvals;
			
			pewsWCF.StepElement[] stepelements = peWSClient.getStepElementsFromQueue(qry);
			
			if (stepelements!=null && stepelements.Length == 1)
			{
				stepElement = stepelements[0];
				return true;
			}
			else
			{
				//retry the operation without locking object.
				if (!lockitem)
				{
					System.Windows.Forms.MessageBox.Show("Queue: "+queueName+":  Failed to retrieve work object: "+wobNum);
					return false;
				}
				
				qry.queryFlags=qryflgs;
				stepelements = peWSClient.getStepElementsFromQueue(qry);
			
				if (stepelements!=null && stepelements.Length == 1)
				{
					stepElement = stepelements[0];
					return true;
				}
			}
			System.Windows.Forms.MessageBox.Show("Queue: "+queueName+":  Failed to lock work object: "+wobNum);
			return false;
			
		}

		// Used by both launch and stepprocessor form to apply a value change for the current step.
		public void applyStepPropertyChanges(string propName,DataGrid dataGrid)
		{
			DataView rdv = (DataView)dataGrid.DataSource;
			DataTable rdt = rdv.Table;
			

			pewsWCF.Parameter[] parameters = stepElement.Parameters;
			
			
			int valueIndex = 0;
			
			foreach (pewsWCF.Parameter param in parameters)
			{
				if (param.Name == propName)
				{
					// only do this if param is not MODE_TYPE_IN
					if (param.Mode == pewsWCF.ModeTypeEnum.MODE_TYPE_IN)
					{
						System.Windows.Forms.MessageBox.Show(propName+" is READONLY");
						break;
					}
					foreach (DataRow row in rdt.Rows)
					{
						
						try
						{
                            /** this only allows for one item?  what about arrays? */
							param.Values[valueIndex].Item = row[0];
						}
						catch(Exception e)
						{
							Console.WriteLine(e.Message);
							pewsWCF.Value stepvalue = new pewsWCF.Value();
							stepvalue.ItemElementName = pewsWCF.ItemChoiceType.integerField;
							stepvalue.Item = row[0];
							pewsWCF.Value[] values = {stepvalue};
							param.Values = values;
						}
						
						param.Modified = true;
						
						valueIndex = valueIndex + 1;
					}
				}
			}
		}

		// Gets the step element reponse strings. Used by both launch and stepprocessor form to apply a value change 
		// for the current step.
		public string[] getStepResponses()
		{
			pewsWCF.ArrayOfResponse stepResponses = stepElement.Responses;
			return stepResponses.Response;
		}
		public int getSelectedResponseIndex()
		{
			pewsWCF.ArrayOfResponse stepResponses = stepElement.Responses;
			if (stepResponses==null||stepResponses.Selected==null)
				return -1;
			int i = 0;
			foreach (string s in stepResponses.Response)
			{
				if (s==stepResponses.Selected)
					return i;
				i++;
			}
			return -1;
		}
		
		// Sets the step element response string to that specified. Used by both launch and stepprocessor form to set 
		// a selected response.
		public void setStepResponse(string stepResponse)
		{
			pewsWCF.ArrayOfResponse stepResponses = stepElement.Responses;
			stepResponses.Selected = stepResponse;
		}
		
		// Unlocks and saves the work object associated with the step element. Used by the steprocessor to save updated 
		// values but not to dispatch a workitem. Called when the Save Unlock
		// button is clicked on the stepprocessor form.
		public void saveunlockStepElement()
		{
			pewsWCF.UpdateStepRequest updStepRequest = new pewsWCF.UpdateStepRequest();
			pewsWCF.UpdateFlagEnum updFlagEnum = pewsWCF.UpdateFlagEnum.UPDATE_SAVE_UNLOCK;
			updStepRequest.stepElement = stepElement;
			updStepRequest.updateFlag = updFlagEnum;
			peWSClient.updateStep(updStepRequest);
		}

		// Unlocks and saves the work object associated with the step element, then advances the work 
		// object in the workflow. Used by both launch and stepprocessor form. 
		public void dispatchStepElement()
		{
			pewsWCF.UpdateStepRequest updStepRequest = new pewsWCF.UpdateStepRequest();
			pewsWCF.UpdateFlagEnum updFlagEnum  = pewsWCF.UpdateFlagEnum.UPDATE_DISPATCH;
			updStepRequest.stepElement = stepElement;
			updStepRequest.updateFlag = updFlagEnum;
			peWSClient.updateStep(updStepRequest);
		}


		// Applies the data grid styles. Used to apply an easy to read style to the datagrids on all three forms.
		public void gridApplyStyle(DataGrid theDataGrid)
		{
			DataView dv  = (DataView) theDataGrid.DataSource;
			DataTable dt = dv.Table;

			
			DataGridTableStyle grdTableStyle1 = new DataGridTableStyle();
			
			grdTableStyle1.MappingName = dv.Table.TableName;
			grdTableStyle1.AlternatingBackColor = System.Drawing.Color.SpringGreen;
			grdTableStyle1.BackColor = System.Drawing.Color.White;
			grdTableStyle1.GridLineStyle = System.Windows.Forms.DataGridLineStyle.None;
			grdTableStyle1.GridLineColor = System.Drawing.Color.White;
			
			if(grdTableStyle1.RowHeadersVisible == true)
			{
				grdTableStyle1.RowHeaderWidth = 10;
			}
			
			DataGridColumnStyle[] gridColStyleArray = new DataGridColumnStyle[dt.Columns.Count];

			int x  = 0;
			foreach( DataColumn column in dt.Columns)
			{
				DataGridTextBoxColumn grdCol = new DataGridTextBoxColumn();
				grdCol.MappingName = column.ColumnName;
				grdCol.HeaderText = column.ColumnName;
				grdCol.Width = 142;
				grdCol.Format = "c";
				grdCol.ReadOnly = false;
				switch(column.DataType.ToString())
				{
					case "System.Double":
						grdCol.Format = "r";
						grdCol.Width = 100;							
						break;
					case "System.Int32":
						grdCol.Format = "r";
						grdCol.Width = 100;							
						break;
					case "System.Float":
						grdCol.Format = "r";
						grdCol.Width = 100;							
						break;
					case "System.DateTime":
						grdCol.Format = "f";
						grdCol.Width = 200;							
						break;
					default:
						break;
				}
				
				gridColStyleArray[x] = grdCol;
				x = x + 1;
			}
			        
			grdTableStyle1.GridColumnStyles.AddRange(gridColStyleArray);
			
			theDataGrid.TableStyles.Add(grdTableStyle1);
		}


//**************************************************************************

		public peFunctions()
		{
		}
	}
}
