namespace PE_C_Sharp_solution
{
    partial class QueueQueryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGetXXXXWrapped = new System.Windows.Forms.Button();
            this.ckboxCheckSecurity = new System.Windows.Forms.CheckBox();
            this.lbNames = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBoxFilterString = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBoxIndexName = new System.Windows.Forms.TextBox();
            this.rbRoster = new System.Windows.Forms.RadioButton();
            this.rbQueue = new System.Windows.Forms.RadioButton();
            this.rbQueue.Checked = true;
            this.MaxValueLabel = new System.Windows.Forms.Label();
            this.txtBoxMinValue = new System.Windows.Forms.TextBox();
            this.MinValueLabel = new System.Windows.Forms.Label();
            this.txtBoxMaxValue = new System.Windows.Forms.TextBox();
            this.btnGetXXXXElementsEx = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBoxNtoReturn = new System.Windows.Forms.TextBox();
            this.QUERY_GET_NO_SYSTEM_FIELDS_CHKBOX = new System.Windows.Forms.CheckBox();
            this.QUERY_GET_NO_TRANSLATED_SYSTEM_FIELDS_CHKBOX = new System.Windows.Forms.CheckBox();
            this.QUERY_LITE_ELEMENTS_CHKBOX = new System.Windows.Forms.CheckBox();
            this.QUERY_LOCK_OBJECT_CHKBOX = new System.Windows.Forms.CheckBox();
            this.QUERY_MAX_VALUES_INCLUSIVE_CHKBOX = new System.Windows.Forms.CheckBox();
            this.QUERY_MIN_VALUES_INCLUSIVE_CHKBOX = new System.Windows.Forms.CheckBox();
            this.QUERY_READ_BOUND_CHKBOX = new System.Windows.Forms.CheckBox();
            this.QUERY_READ_LOCKED_CHKBOX = new System.Windows.Forms.CheckBox();
            this.QUERY_READ_UNWRITABLE_CHKBOX = new System.Windows.Forms.CheckBox();
            this.QUERY_RESOLVE_NAMES_CHKBOX = new System.Windows.Forms.CheckBox();
            this.dgQueueContents = new System.Windows.Forms.DataGrid();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAddSubsVar = new System.Windows.Forms.Button();
            this.txtBoxNewSubVar = new System.Windows.Forms.TextBox();
            this.comboBoxSubVarType = new System.Windows.Forms.ComboBox();
            this.lbSubVars = new System.Windows.Forms.ListBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dgQueueContents)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnGetXXXXWrapped
            // 
            this.btnGetXXXXWrapped.Location = new System.Drawing.Point(336, 17);
            this.btnGetXXXXWrapped.Name = "btnGetXXXXWrapped";
            this.btnGetXXXXWrapped.Size = new System.Drawing.Size(152, 51);
            this.btnGetXXXXWrapped.TabIndex = 0;
            this.btnGetXXXXWrapped.Text = "Get XXXX Wrapped";
            this.btnGetXXXXWrapped.UseVisualStyleBackColor = true;
            this.btnGetXXXXWrapped.Click += new System.EventHandler(this.getXXXXWrappedButton_Click);
            // 
            // ckboxCheckSecurity
            // 
            this.ckboxCheckSecurity.AutoSize = true;
            this.ckboxCheckSecurity.Location = new System.Drawing.Point(12, 12);
            this.ckboxCheckSecurity.Name = "ckboxCheckSecurity";
            this.ckboxCheckSecurity.Size = new System.Drawing.Size(97, 17);
            this.ckboxCheckSecurity.TabIndex = 1;
            this.ckboxCheckSecurity.Text = "check Security";
            this.ckboxCheckSecurity.UseVisualStyleBackColor = true;
            // 
            // lbNames
            // 
            this.lbNames.FormattingEnabled = true;
            this.lbNames.Location = new System.Drawing.Point(133, 12);
            this.lbNames.Name = "lbNames";
            this.lbNames.Size = new System.Drawing.Size(189, 56);
            this.lbNames.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoEllipsis = true;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 221);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Filter String";
            // 
            // txtBoxFilterString
            // 
            this.txtBoxFilterString.Location = new System.Drawing.Point(94, 217);
            this.txtBoxFilterString.Name = "txtBoxFilterString";
            this.txtBoxFilterString.Size = new System.Drawing.Size(171, 20);
            this.txtBoxFilterString.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(279, 250);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Index Name";
            // 
            // txtBoxIndexName
            // 
            this.txtBoxIndexName.Location = new System.Drawing.Point(355, 247);
            this.txtBoxIndexName.Name = "txtBoxIndexName";
            this.txtBoxIndexName.Size = new System.Drawing.Size(171, 20);
            this.txtBoxIndexName.TabIndex = 6;
            // 
            // rbRoster
            // 
            this.rbRoster.AutoSize = true;
            this.rbRoster.Location = new System.Drawing.Point(15, 35);
            this.rbRoster.Name = "rbRoster";
            this.rbRoster.Size = new System.Drawing.Size(56, 17);
            this.rbRoster.TabIndex = 7;
            this.rbRoster.TabStop = true;
            this.rbRoster.Text = "Roster";
            this.rbRoster.UseVisualStyleBackColor = true;
            this.rbRoster.CheckedChanged += new System.EventHandler(this.RosterRadioButton_CheckedChanged);
            // 
            // rbQueue
            // 
            this.rbQueue.AutoSize = true;
            this.rbQueue.Location = new System.Drawing.Point(15, 58);
            this.rbQueue.Name = "rbQueue";
            this.rbQueue.Size = new System.Drawing.Size(57, 17);
            this.rbQueue.TabIndex = 8;
            this.rbQueue.TabStop = true;
            this.rbQueue.Text = "Queue";
            this.rbQueue.UseVisualStyleBackColor = true;
            this.rbQueue.CheckedChanged += new System.EventHandler(this.QueueRadioButton_CheckedChanged);
            // 
            // MaxValueLabel
            // 
            this.MaxValueLabel.AutoSize = true;
            this.MaxValueLabel.Location = new System.Drawing.Point(281, 195);
            this.MaxValueLabel.Name = "MaxValueLabel";
            this.MaxValueLabel.Size = new System.Drawing.Size(62, 13);
            this.MaxValueLabel.TabIndex = 9;
            this.MaxValueLabel.Text = "Max Values";
            // 
            // txtBoxMinValue
            // 
            this.txtBoxMinValue.Location = new System.Drawing.Point(361, 118);
            this.txtBoxMinValue.Name = "txtBoxMinValue";
            this.txtBoxMinValue.Size = new System.Drawing.Size(171, 20);
            this.txtBoxMinValue.TabIndex = 10;
            // 
            // MinValueLabel
            // 
            this.MinValueLabel.AutoSize = true;
            this.MinValueLabel.Location = new System.Drawing.Point(281, 227);
            this.MinValueLabel.Name = "MinValueLabel";
            this.MinValueLabel.Size = new System.Drawing.Size(59, 13);
            this.MinValueLabel.TabIndex = 11;
            this.MinValueLabel.Text = "Min Values";
            // 
            // txtBoxMaxValue
            // 
            this.txtBoxMaxValue.Location = new System.Drawing.Point(361, 144);
            this.txtBoxMaxValue.Name = "txtBoxMaxValue";
            this.txtBoxMaxValue.Size = new System.Drawing.Size(171, 20);
            this.txtBoxMaxValue.TabIndex = 12;
            // 
            // btnGetXXXXElementsEx
            // 
            this.btnGetXXXXElementsEx.Location = new System.Drawing.Point(544, 117);
            this.btnGetXXXXElementsEx.Name = "btnGetXXXXElementsEx";
            this.btnGetXXXXElementsEx.Size = new System.Drawing.Size(159, 138);
            this.btnGetXXXXElementsEx.TabIndex = 0;
            this.btnGetXXXXElementsEx.Text = "Get XXXX ElementsExRequest";
            this.btnGetXXXXElementsEx.UseVisualStyleBackColor = true;
            this.btnGetXXXXElementsEx.Click += new System.EventHandler(this.GetXXXXElementsEx_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 191);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "nToReturn";
            // 
            // txtBoxNtoReturn
            // 
            this.txtBoxNtoReturn.Location = new System.Drawing.Point(94, 191);
            this.txtBoxNtoReturn.Name = "txtBoxNtoReturn";
            this.txtBoxNtoReturn.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.txtBoxNtoReturn.Size = new System.Drawing.Size(171, 20);
            this.txtBoxNtoReturn.TabIndex = 14;
            this.txtBoxNtoReturn.Text = "50";
            // 
            // QUERY_GET_NO_SYSTEM_FIELDS_CHKBOX
            // 
            this.QUERY_GET_NO_SYSTEM_FIELDS_CHKBOX.AutoSize = true;
            this.QUERY_GET_NO_SYSTEM_FIELDS_CHKBOX.Location = new System.Drawing.Point(6, 104);
            this.QUERY_GET_NO_SYSTEM_FIELDS_CHKBOX.Name = "QUERY_GET_NO_SYSTEM_FIELDS_CHKBOX";
            this.QUERY_GET_NO_SYSTEM_FIELDS_CHKBOX.Size = new System.Drawing.Size(207, 17);
            this.QUERY_GET_NO_SYSTEM_FIELDS_CHKBOX.TabIndex = 1;
            this.QUERY_GET_NO_SYSTEM_FIELDS_CHKBOX.Text = "QUERY_GET_NO_SYSTEM_FIELDS";
            this.QUERY_GET_NO_SYSTEM_FIELDS_CHKBOX.UseVisualStyleBackColor = true;
            // 
            // QUERY_GET_NO_TRANSLATED_SYSTEM_FIELDS_CHKBOX
            // 
            this.QUERY_GET_NO_TRANSLATED_SYSTEM_FIELDS_CHKBOX.AutoSize = true;
            this.QUERY_GET_NO_TRANSLATED_SYSTEM_FIELDS_CHKBOX.Location = new System.Drawing.Point(6, 126);
            this.QUERY_GET_NO_TRANSLATED_SYSTEM_FIELDS_CHKBOX.Name = "QUERY_GET_NO_TRANSLATED_SYSTEM_FIELDS_CHKBOX";
            this.QUERY_GET_NO_TRANSLATED_SYSTEM_FIELDS_CHKBOX.Size = new System.Drawing.Size(285, 17);
            this.QUERY_GET_NO_TRANSLATED_SYSTEM_FIELDS_CHKBOX.TabIndex = 1;
            this.QUERY_GET_NO_TRANSLATED_SYSTEM_FIELDS_CHKBOX.Text = "QUERY_GET_NO_TRANSLATED_SYSTEM_FIELDS";
            this.QUERY_GET_NO_TRANSLATED_SYSTEM_FIELDS_CHKBOX.UseVisualStyleBackColor = true;
            // 
            // QUERY_LITE_ELEMENTS_CHKBOX
            // 
            this.QUERY_LITE_ELEMENTS_CHKBOX.AutoSize = true;
            this.QUERY_LITE_ELEMENTS_CHKBOX.Location = new System.Drawing.Point(6, 146);
            this.QUERY_LITE_ELEMENTS_CHKBOX.Name = "QUERY_LITE_ELEMENTS_CHKBOX";
            this.QUERY_LITE_ELEMENTS_CHKBOX.Size = new System.Drawing.Size(157, 17);
            this.QUERY_LITE_ELEMENTS_CHKBOX.TabIndex = 1;
            this.QUERY_LITE_ELEMENTS_CHKBOX.Text = "QUERY_LITE_ELEMENTS";
            this.QUERY_LITE_ELEMENTS_CHKBOX.UseVisualStyleBackColor = true;
            // 
            // QUERY_LOCK_OBJECT_CHKBOX
            // 
            this.QUERY_LOCK_OBJECT_CHKBOX.AutoSize = true;
            this.QUERY_LOCK_OBJECT_CHKBOX.Location = new System.Drawing.Point(6, 169);
            this.QUERY_LOCK_OBJECT_CHKBOX.Name = "QUERY_LOCK_OBJECT_CHKBOX";
            this.QUERY_LOCK_OBJECT_CHKBOX.Size = new System.Drawing.Size(152, 17);
            this.QUERY_LOCK_OBJECT_CHKBOX.TabIndex = 1;
            this.QUERY_LOCK_OBJECT_CHKBOX.Text = "QUERY_LOCK_OBJECTS";
            this.QUERY_LOCK_OBJECT_CHKBOX.UseVisualStyleBackColor = true;
            // 
            // QUERY_MAX_VALUES_INCLUSIVE_CHKBOX
            // 
            this.QUERY_MAX_VALUES_INCLUSIVE_CHKBOX.AutoSize = true;
            this.QUERY_MAX_VALUES_INCLUSIVE_CHKBOX.Location = new System.Drawing.Point(448, 108);
            this.QUERY_MAX_VALUES_INCLUSIVE_CHKBOX.Name = "QUERY_MAX_VALUES_INCLUSIVE_CHKBOX";
            this.QUERY_MAX_VALUES_INCLUSIVE_CHKBOX.Size = new System.Drawing.Size(203, 17);
            this.QUERY_MAX_VALUES_INCLUSIVE_CHKBOX.TabIndex = 1;
            this.QUERY_MAX_VALUES_INCLUSIVE_CHKBOX.Text = "QUERY_MAX_VALUES_INCLUSIVE";
            this.QUERY_MAX_VALUES_INCLUSIVE_CHKBOX.UseVisualStyleBackColor = true;
            // 
            // QUERY_MIN_VALUES_INCLUSIVE_CHKBOX
            // 
            this.QUERY_MIN_VALUES_INCLUSIVE_CHKBOX.AutoSize = true;
            this.QUERY_MIN_VALUES_INCLUSIVE_CHKBOX.Location = new System.Drawing.Point(448, 126);
            this.QUERY_MIN_VALUES_INCLUSIVE_CHKBOX.Name = "QUERY_MIN_VALUES_INCLUSIVE_CHKBOX";
            this.QUERY_MIN_VALUES_INCLUSIVE_CHKBOX.Size = new System.Drawing.Size(200, 17);
            this.QUERY_MIN_VALUES_INCLUSIVE_CHKBOX.TabIndex = 1;
            this.QUERY_MIN_VALUES_INCLUSIVE_CHKBOX.Text = "QUERY_MIN_VALUES_INCLUSIVE";
            this.QUERY_MIN_VALUES_INCLUSIVE_CHKBOX.UseVisualStyleBackColor = true;
            // 
            // QUERY_READ_BOUND_CHKBOX
            // 
            this.QUERY_READ_BOUND_CHKBOX.AutoSize = true;
            this.QUERY_READ_BOUND_CHKBOX.Location = new System.Drawing.Point(288, 103);
            this.QUERY_READ_BOUND_CHKBOX.Name = "QUERY_READ_BOUND_CHKBOX";
            this.QUERY_READ_BOUND_CHKBOX.Size = new System.Drawing.Size(145, 17);
            this.QUERY_READ_BOUND_CHKBOX.TabIndex = 1;
            this.QUERY_READ_BOUND_CHKBOX.Text = "QUERY_READ_BOUND";
            this.QUERY_READ_BOUND_CHKBOX.UseVisualStyleBackColor = true;
            // 
            // QUERY_READ_LOCKED_CHKBOX
            // 
            this.QUERY_READ_LOCKED_CHKBOX.AutoSize = true;
            this.QUERY_READ_LOCKED_CHKBOX.Location = new System.Drawing.Point(288, 126);
            this.QUERY_READ_LOCKED_CHKBOX.Name = "QUERY_READ_LOCKED_CHKBOX";
            this.QUERY_READ_LOCKED_CHKBOX.Size = new System.Drawing.Size(149, 17);
            this.QUERY_READ_LOCKED_CHKBOX.TabIndex = 1;
            this.QUERY_READ_LOCKED_CHKBOX.Text = "QUERY_READ_LOCKED";
            this.QUERY_READ_LOCKED_CHKBOX.UseVisualStyleBackColor = true;
            // 
            // QUERY_READ_UNWRITABLE_CHKBOX
            // 
            this.QUERY_READ_UNWRITABLE_CHKBOX.AutoSize = true;
            this.QUERY_READ_UNWRITABLE_CHKBOX.Location = new System.Drawing.Point(288, 149);
            this.QUERY_READ_UNWRITABLE_CHKBOX.Name = "QUERY_READ_UNWRITABLE_CHKBOX";
            this.QUERY_READ_UNWRITABLE_CHKBOX.Size = new System.Drawing.Size(178, 17);
            this.QUERY_READ_UNWRITABLE_CHKBOX.TabIndex = 1;
            this.QUERY_READ_UNWRITABLE_CHKBOX.Text = "QUERY_READ_UNWRITABLE";
            this.QUERY_READ_UNWRITABLE_CHKBOX.UseVisualStyleBackColor = true;
            // 
            // QUERY_RESOLVE_NAMES_CHKBOX
            // 
            this.QUERY_RESOLVE_NAMES_CHKBOX.AutoSize = true;
            this.QUERY_RESOLVE_NAMES_CHKBOX.Location = new System.Drawing.Point(288, 172);
            this.QUERY_RESOLVE_NAMES_CHKBOX.Name = "QUERY_RESOLVE_NAMES_CHKBOX";
            this.QUERY_RESOLVE_NAMES_CHKBOX.Size = new System.Drawing.Size(164, 17);
            this.QUERY_RESOLVE_NAMES_CHKBOX.TabIndex = 1;
            this.QUERY_RESOLVE_NAMES_CHKBOX.Text = "QUERY_RESOLVE_NAMES";
            this.QUERY_RESOLVE_NAMES_CHKBOX.UseVisualStyleBackColor = true;
            // 
            // dgQueueContents
            // 
            this.dgQueueContents.DataMember = "";
            this.dgQueueContents.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgQueueContents.Location = new System.Drawing.Point(31, 360);
            this.dgQueueContents.Name = "dgQueueContents";
            this.dgQueueContents.ReadOnly = true;
            this.dgQueueContents.Size = new System.Drawing.Size(588, 200);
            this.dgQueueContents.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 180);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Substitution Variables";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.lbSubVars);
            this.groupBox1.Controls.Add(this.comboBoxSubVarType);
            this.groupBox1.Controls.Add(this.txtBoxNewSubVar);
            this.groupBox1.Controls.Add(this.txtBoxMaxValue);
            this.groupBox1.Controls.Add(this.btnAddSubsVar);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtBoxMinValue);
            this.groupBox1.Controls.Add(this.btnGetXXXXElementsEx);
            this.groupBox1.Location = new System.Drawing.Point(-6, 74);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(709, 280);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "GetXXXXElementsExRequest Params";
            // 
            // btnAddSubsVar
            // 
            this.btnAddSubsVar.Location = new System.Drawing.Point(154, 196);
            this.btnAddSubsVar.Name = "btnAddSubsVar";
            this.btnAddSubsVar.Size = new System.Drawing.Size(75, 47);
            this.btnAddSubsVar.TabIndex = 17;
            this.btnAddSubsVar.Text = "Add";
            this.btnAddSubsVar.UseVisualStyleBackColor = true;
            this.btnAddSubsVar.Click += new System.EventHandler(this.btnAddSubsVar_Click);
            // 
            // txtBoxNewSubVar
            // 
            this.txtBoxNewSubVar.Location = new System.Drawing.Point(27, 196);
            this.txtBoxNewSubVar.Name = "txtBoxNewSubVar";
            this.txtBoxNewSubVar.Size = new System.Drawing.Size(121, 20);
            this.txtBoxNewSubVar.TabIndex = 18;
            this.txtBoxNewSubVar.TextChanged += new System.EventHandler(this.txtBoxNewSubVar_TextChanged);
            // 
            // comboBoxSubVarType
            // 
            this.comboBoxSubVarType.FormattingEnabled = true;
            this.comboBoxSubVarType.IntegralHeight = false;
            this.comboBoxSubVarType.Items.AddRange(new object[] {
            "boolean",
            "float",
            "int",
            "string",
            "time"});
            this.comboBoxSubVarType.Location = new System.Drawing.Point(27, 222);
            this.comboBoxSubVarType.Name = "comboBoxSubVarType";
            this.comboBoxSubVarType.Size = new System.Drawing.Size(121, 21);
            this.comboBoxSubVarType.TabIndex = 19;
            this.comboBoxSubVarType.Text = "string";
            this.comboBoxSubVarType.SelectedIndexChanged += new System.EventHandler(this.comboBoxSubVarType_SelectedIndexChanged);
            // 
            // lbSubVars
            // 
            this.lbSubVars.Enabled = false;
            this.lbSubVars.FormattingEnabled = true;
            this.lbSubVars.Location = new System.Drawing.Point(235, 199);
            this.lbSubVars.Name = "lbSubVars";
            this.lbSubVars.Size = new System.Drawing.Size(191, 56);
            this.lbSubVars.TabIndex = 20;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(29, 249);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 21;
            this.dateTimePicker1.Visible = false;
            // 
            // QueueQueryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(715, 572);
            this.Controls.Add(this.dgQueueContents);
            this.Controls.Add(this.txtBoxNtoReturn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.MinValueLabel);
            this.Controls.Add(this.MaxValueLabel);
            this.Controls.Add(this.rbQueue);
            this.Controls.Add(this.rbRoster);
            this.Controls.Add(this.txtBoxIndexName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtBoxFilterString);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbNames);
            this.Controls.Add(this.QUERY_RESOLVE_NAMES_CHKBOX);
            this.Controls.Add(this.QUERY_READ_UNWRITABLE_CHKBOX);
            this.Controls.Add(this.QUERY_READ_LOCKED_CHKBOX);
            this.Controls.Add(this.QUERY_READ_BOUND_CHKBOX);
            this.Controls.Add(this.QUERY_MIN_VALUES_INCLUSIVE_CHKBOX);
            this.Controls.Add(this.QUERY_MAX_VALUES_INCLUSIVE_CHKBOX);
            this.Controls.Add(this.QUERY_LOCK_OBJECT_CHKBOX);
            this.Controls.Add(this.QUERY_LITE_ELEMENTS_CHKBOX);
            this.Controls.Add(this.QUERY_GET_NO_TRANSLATED_SYSTEM_FIELDS_CHKBOX);
            this.Controls.Add(this.QUERY_GET_NO_SYSTEM_FIELDS_CHKBOX);
            this.Controls.Add(this.ckboxCheckSecurity);
            this.Controls.Add(this.btnGetXXXXWrapped);
            this.Controls.Add(this.groupBox1);
            this.Name = "QueueQueryForm";
            this.Text = "QueueQueryForm";
            ((System.ComponentModel.ISupportInitialize)(this.dgQueueContents)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

            //adding the default text.
            this.btnGetXXXXWrapped.Text = "GetQueuesWrapped";
            this.btnGetXXXXElementsEx.Text = "GetQueueElementsEx";
            this.btnGetXXXXElementsEx.Enabled = false;
        }

        #endregion

        private System.Windows.Forms.Button btnGetXXXXWrapped;
        private System.Windows.Forms.CheckBox ckboxCheckSecurity;
        private System.Windows.Forms.ListBox lbNames;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBoxFilterString;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBoxIndexName;
        private System.Windows.Forms.RadioButton rbRoster;
        private System.Windows.Forms.RadioButton rbQueue;
        private System.Windows.Forms.Label MaxValueLabel;
        private System.Windows.Forms.TextBox txtBoxMinValue;
        private System.Windows.Forms.Label MinValueLabel;
        private System.Windows.Forms.TextBox txtBoxMaxValue;
        private System.Windows.Forms.Button btnGetXXXXElementsEx;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBoxNtoReturn;
        private System.Windows.Forms.CheckBox QUERY_GET_NO_SYSTEM_FIELDS_CHKBOX;
        private System.Windows.Forms.CheckBox QUERY_GET_NO_TRANSLATED_SYSTEM_FIELDS_CHKBOX;
        private System.Windows.Forms.CheckBox QUERY_LITE_ELEMENTS_CHKBOX;
        private System.Windows.Forms.CheckBox QUERY_LOCK_OBJECT_CHKBOX;
        private System.Windows.Forms.CheckBox QUERY_MAX_VALUES_INCLUSIVE_CHKBOX;
        private System.Windows.Forms.CheckBox QUERY_MIN_VALUES_INCLUSIVE_CHKBOX;
        private System.Windows.Forms.CheckBox QUERY_READ_BOUND_CHKBOX;
        private System.Windows.Forms.CheckBox QUERY_READ_LOCKED_CHKBOX;
        private System.Windows.Forms.CheckBox QUERY_READ_UNWRITABLE_CHKBOX;
        private System.Windows.Forms.CheckBox QUERY_RESOLVE_NAMES_CHKBOX;
        internal System.Windows.Forms.DataGrid dgQueueContents;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBoxSubVarType;
        private System.Windows.Forms.TextBox txtBoxNewSubVar;
        private System.Windows.Forms.Button btnAddSubsVar;
        private System.Windows.Forms.ListBox lbSubVars;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}