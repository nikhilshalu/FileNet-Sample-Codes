//* DISCLAIMER OF WARRANTIES.  This is 
//* sample code created by IBM Corporation.  This sample code is
//* not part of any standard or IBM product and is provided to you
//* solely for the purpose of assisting you in the development of
//* your applications.  The code is provided "AS IS", without
//* warranty of any kind.  IBM shall not be liable for any damages
//* arising out of your use of the sample code, even if it has
//* been advised of the possibility of such damages
/*
 * 
 * IBM grants you a nonexclusive copyright license to use all programming
 * code examples from which you can generate similar function tailored 
 * to your own specific needs.
 * All sample code is provided by IBM for illustrative purposes only.
 * These examples have not been thoroughly tested under all conditions.
 * IBM, therefore cannot guarantee or imply reliability, serviceability, 
 * or function of these programs.
 * All Programs or code component contained herein are provided to you 
 * �AS IS � without any warranties of any kind.
 * The implied warranties of non-infringement, merchantability and fitness 
 * for a particular purpose are expressly disclaimed.

� Copyright IBM Corporation 2007, ALL RIGHTS RESERVED
*/
using System;
using System.Xml;
using PE_C_Sharp_solution.pewsWCF;

namespace PE_C_Sharp_solution
{


	/// <summary>
	/// This is a simple instantiatable class used to retain and reuse the 
    /// Process Engine session. Note that there is no explicit PE web service 
    /// logon call. The credentials are verified when functional operations 
    /// are attempted. The logon method of this class performs a redundant 
    /// getQueues call solely to discover whether the username and password 
	/// are valid.
	/// </summary>
	public class PESession
	{
		private String peUsername;
		private String pePassword;
		private String peRouter;
        private String theLocale;
        private String theUrl;
        private Boolean theCustomCredentialFlag;
        private Boolean theKerberosFlag;
        private String theSPN;

        private ProcessEngineServiceClient peWSClient;

        public void setPEServiceClient(ProcessEngineServiceClient client)
        {
            peWSClient = client;
        }

        public String spn
        {
            get
            {
                return theSPN;
            }

            set
            {
                theSPN = value;
            }
        }
        public String peLocale
        {
            get
            {
                return theLocale;
            }

            set
            {
                theLocale = value;
            }
        }
        public Boolean customCredential
        {
            get
            {
                return theCustomCredentialFlag;
            }
            set
            {
                theCustomCredentialFlag = value;
            }
        }
        public Boolean useKerberos
        {
            get
            {
                return theKerberosFlag;
            }
            set
            {
                theKerberosFlag = value;
            }
        }
        public String router
        {
            get
            {
                return peRouter;
            }
            set
            {
                peRouter = value;
            }
        }
        public String userName
        {
            get
            {
                return peUsername;
            }
            set
            {
                peUsername = value;
            }
        }
        public String password
        {
            get
            {
                return pePassword;
            }
            set
            {
                pePassword = value;
            }
        }

        public String wsUrl
        {
            get
            {
                return theUrl;
            }
            set
            {
                theUrl = value;
            }
        }

        /// <summary>
        /// Returns a Security Principal Name that can be used for Kerberos authentication.
        /// </summary>
        /// <param name="serverUrl">URL to the CE server</param>
        /// <returns>SPN string</returns>
        public static string GetKerberosSPN(string serverUrl)
        {
            const string prefixHTTPS = "https://";
            const string prefixHTTP = "http://";
            string urlPrefix = string.Empty;
            if (serverUrl.StartsWith(prefixHTTPS))
            {
                urlPrefix = prefixHTTPS;
            }
            else if (serverUrl.StartsWith(prefixHTTP))
            {
                urlPrefix = prefixHTTP;
            }

            string SPN = "FNCEWS/";

            int length = 0;
            int colon = serverUrl.IndexOf(":", urlPrefix.Length);
            int slash = serverUrl.IndexOf("/", urlPrefix.Length);

            if (colon < slash)
            {
                length = colon - urlPrefix.Length;
            }
            else
            {
                length = slash - urlPrefix.Length;
            }

            if (length >= 0)
            {
                SPN += serverUrl.Substring(urlPrefix.Length, length);
            }
            return SPN;
        }

		private void setPESessionProperties()
		{
            // nothing to set
            ;
		}

		// Logs in to a new PE session using the specified criteria.
		public  bool logon()
		{
			setPESessionProperties();
			try
			{
                peWSClient.getQueues();
			}
			catch (Exception e)
			{
				// if get queues fails, we should really indicate the logon failed
				System.Windows.Forms.MessageBox.Show("Failed to logon: "+e.Message);
				return false;
			}
			
			return true;
		}

       
		/*
         * Gets a PE session for the Process Engine Web Service.  This routine
         * set up the necessary data for the SOAP header.
         */
        public pewsWCF.ProcessEngineService getSession()
		{
			// make sure all the properties are set up..
			setPESessionProperties();
            return peWSClient;
		}


		public PESession()
		{
		}
	}
}


