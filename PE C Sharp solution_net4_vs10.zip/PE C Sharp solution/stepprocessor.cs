//* DISCLAIMER OF WARRANTIES.  This is 
//* sample code created by IBM Corporation.  This sample code is
//* not part of any standard or IBM product and is provided to you
//* solely for the purpose of assisting you in the development of
//* your applications.  The code is provided "AS IS", without
//* warranty of any kind.  IBM shall not be liable for any damages
//* arising out of your use of the sample code, even if it has
//* been advised of the possibility of such damages.

/*
 * 
 * IBM grants you a nonexclusive copyright license to use all programming
 * code examples from which you can generate similar function tailored 
 * to your own specific needs.
 * All sample code is provided by IBM for illustrative purposes only.
 * These examples have not been thoroughly tested under all conditions.
 * IBM, therefore cannot guarantee or imply reliability, serviceability, 
 * or function of these programs.
 * All Programs or code component contained herein are provided to you 
 * �AS IS � without any warranties of any kind.
 * The implied warranties of non-infringement, merchantability and fitness 
 * for a particular purpose are expressly disclaimed.

� Copyright IBM Corporation 2007, ALL RIGHTS RESERVED
*/


using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace PE_C_Sharp_solution
{
	/// <summary>
	/// The stepprocessor form is, in most aspects, identical to the worklaunchstep form. Exposed properties are shown in one 
	/// datagrid. Values are exposed in another. An apply button is provided if values are changed.	The execution of this form, 
	/// however, can be in one of two modes: view or process. Depending on which one is selected, the user will be able to view 
	/// or modify and dispatch the item of work they are presented with.
	/// </summary>
	public class stepprocessor : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.Button btClose;
		internal System.Windows.Forms.ListBox lbResponses;
		internal System.Windows.Forms.CheckBox cbWriteEnabled;
		internal System.Windows.Forms.DataGrid dgProperties;
		internal System.Windows.Forms.DataGrid dgProperty;
		internal System.Windows.Forms.Button btDispatch;
		internal System.Windows.Forms.Button btStepApply;
		internal System.Windows.Forms.Button btSaveUnlock;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public peFunctions mypeFunctions = new peFunctions();

		public stepprocessor()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

		}

		// Processes the selected step element.
		public void loadstep()
		{
			// Populate the datagrid with the step parameters
			mypeFunctions.selectedStepElementIntoDataGrid(dgProperties);
			mypeFunctions.gridApplyStyle(dgProperties);

			// Get the step responses. The try/catch is just in case there are no responses and we get a null back
			try
			{
				string[] responses = mypeFunctions.getStepResponses();
				
				foreach (string response in responses)
				{
					lbResponses.Items.Add(response);
				}
				int i=mypeFunctions.getSelectedResponseIndex();
				if (i!=-1)
					lbResponses.SelectedIndex = i;
				else
					lbResponses.SelectedIndex = 0;
			}
			catch(Exception e)
			{
				lbResponses.Visible = false;
			}

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btClose = new System.Windows.Forms.Button();
			this.lbResponses = new System.Windows.Forms.ListBox();
			this.cbWriteEnabled = new System.Windows.Forms.CheckBox();
			this.dgProperties = new System.Windows.Forms.DataGrid();
			this.dgProperty = new System.Windows.Forms.DataGrid();
			this.btDispatch = new System.Windows.Forms.Button();
			this.btStepApply = new System.Windows.Forms.Button();
			this.btSaveUnlock = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dgProperties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dgProperty)).BeginInit();
			this.SuspendLayout();
			// 
			// btClose
			// 
			this.btClose.Location = new System.Drawing.Point(664, 80);
			this.btClose.Name = "btClose";
			this.btClose.Size = new System.Drawing.Size(88, 24);
			this.btClose.TabIndex = 29;
			this.btClose.Text = "Close";
			// 
			// lbResponses
			// 
			this.lbResponses.Location = new System.Drawing.Point(408, 352);
			this.lbResponses.Name = "lbResponses";
			this.lbResponses.Size = new System.Drawing.Size(200, 108);
			this.lbResponses.TabIndex = 28;
			this.lbResponses.SelectedIndexChanged += new System.EventHandler(this.lbResponses_SelectedIndexChanged);
			// 
			// cbWriteEnabled
			// 
			this.cbWriteEnabled.Enabled = false;
			this.cbWriteEnabled.Location = new System.Drawing.Point(704, 8);
			this.cbWriteEnabled.Name = "cbWriteEnabled";
			this.cbWriteEnabled.Size = new System.Drawing.Size(112, 16);
			this.cbWriteEnabled.TabIndex = 27;
			this.cbWriteEnabled.Text = "Write Enabled";
			// 
			// dgProperties
			// 
			this.dgProperties.DataMember = "";
			this.dgProperties.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgProperties.Location = new System.Drawing.Point(16, 24);
			this.dgProperties.Name = "dgProperties";
			this.dgProperties.ReadOnly = true;
			this.dgProperties.Size = new System.Drawing.Size(384, 440);
			this.dgProperties.TabIndex = 22;
			this.dgProperties.Click += new System.EventHandler(this.dgProperties_Click);
			// 
			// dgProperty
			// 
			this.dgProperty.DataMember = "";
			this.dgProperty.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgProperty.Location = new System.Drawing.Point(408, 24);
			this.dgProperty.Name = "dgProperty";
			this.dgProperty.Size = new System.Drawing.Size(224, 160);
			this.dgProperty.TabIndex = 23;
			// 
			// btDispatch
			// 
			this.btDispatch.Location = new System.Drawing.Point(664, 112);
			this.btDispatch.Name = "btDispatch";
			this.btDispatch.Size = new System.Drawing.Size(88, 24);
			this.btDispatch.TabIndex = 26;
			this.btDispatch.Text = "Dispatch";
			this.btDispatch.Click += new System.EventHandler(this.btDispatch_Click);
			// 
			// btStepApply
			// 
			this.btStepApply.Location = new System.Drawing.Point(472, 208);
			this.btStepApply.Name = "btStepApply";
			this.btStepApply.Size = new System.Drawing.Size(88, 24);
			this.btStepApply.TabIndex = 25;
			this.btStepApply.Text = "Apply";
			this.btStepApply.Click += new System.EventHandler(this.btStepApply_Click);
			// 
			// btSaveUnlock
			// 
			this.btSaveUnlock.Location = new System.Drawing.Point(664, 48);
			this.btSaveUnlock.Name = "btSaveUnlock";
			this.btSaveUnlock.Size = new System.Drawing.Size(88, 24);
			this.btSaveUnlock.TabIndex = 24;
			this.btSaveUnlock.Text = "Save Unlock";
			this.btSaveUnlock.Click += new System.EventHandler(this.btSaveUnlock_Click);
			// 
			// stepprocessor
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(824, 478);
			this.Controls.Add(this.btClose);
			this.Controls.Add(this.lbResponses);
			this.Controls.Add(this.cbWriteEnabled);
			this.Controls.Add(this.dgProperties);
			this.Controls.Add(this.dgProperty);
			this.Controls.Add(this.btDispatch);
			this.Controls.Add(this.btStepApply);
			this.Controls.Add(this.btSaveUnlock);
			this.Name = "stepprocessor";
			this.Text = "stepprocessor";
			this.Load += new System.EventHandler(this.stepprocessor_Load);
			((System.ComponentModel.ISupportInitialize)(this.dgProperties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dgProperty)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		// Called by event handler to get the properties of a selected step element.
		private void dgProperties_Click(object sender, System.EventArgs ne)
		{
			DataGrid dgSender = (DataGrid)sender;
			int rowid = dgSender.CurrentRowIndex;
			DataView rdv = (DataView)dgSender.DataSource;
			DataTable rdt = rdv.Table;

			string propertyName = (string)rdt.Rows[rowid][rdt.Columns.IndexOf("Property Name")];
			mypeFunctions.selectedStepElementPropertyIntoDataGrid(propertyName, dgProperty);
			mypeFunctions.gridApplyStyle(dgProperty);
			// also check to see if the parameter is readonly to enable the apply button accordingly.
			pewsWCF.Parameter param = mypeFunctions.getParameter(propertyName, null);
			btStepApply.Enabled = (param!=null && param.Mode != pewsWCF.ModeTypeEnum.MODE_TYPE_IN);
		}

		// Called by event handler when Save Unlock button is clicked.
		private void btSaveUnlock_Click(object sender, System.EventArgs e)
		{
			mypeFunctions.saveunlockStepElement();
			this.Close();
		}

		// Called by event handler when Dispatch button is clicked.
		private void btDispatch_Click(object sender, System.EventArgs e)
		{
			mypeFunctions.dispatchStepElement();
			this.Close();
		}

		// Called by event handler when Apply button is clicked.
		private void btStepApply_Click(object sender, System.EventArgs e)
		{
			int rowid = dgProperties.CurrentRowIndex;
			DataView rdv = (DataView)dgProperties.DataSource;
			DataTable rdt = rdv.Table;
			string propertyName = (string)rdt.Rows[rowid][rdt.Columns.IndexOf("Property Name")];

			mypeFunctions.applyStepPropertyChanges(propertyName, dgProperty);
		}

		// Sets the step response string to the name of the selected step element.
		private void lbResponses_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			mypeFunctions.setStepResponse((string)lbResponses.SelectedItem);
		}

		private void stepprocessor_Load(object sender, System.EventArgs e)
		{
		
		}

	}
}
