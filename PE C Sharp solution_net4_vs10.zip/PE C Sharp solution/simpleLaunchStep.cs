//* DISCLAIMER OF WARRANTIES.  This is 
//* sample code created by IBM Corporation.  This sample code is
//* not part of any standard or IBM product and is provided to you
//* solely for the purpose of assisting you in the development of
//* your applications.  The code is provided "AS IS", without
//* warranty of any kind.  IBM shall not be liable for any damages
//* arising out of your use of the sample code, even if it has
//* been advised of the possibility of such damages.

/*
 * 
 * IBM grants you a nonexclusive copyright license to use all programming
 * code examples from which you can generate similar function tailored 
 * to your own specific needs.
 * All sample code is provided by IBM for illustrative purposes only.
 * These examples have not been thoroughly tested under all conditions.
 * IBM, therefore cannot guarantee or imply reliability, serviceability, 
 * or function of these programs.
 * All Programs or code component contained herein are provided to you 
 * �AS IS � without any warranties of any kind.
 * The implied warranties of non-infringement, merchantability and fitness 
 * for a particular purpose are expressly disclaimed.

� Copyright IBM Corporation 2007, ALL RIGHTS RESERVED
*/

using PE_C_Sharp_solution.pewsWCF;

namespace PE_C_Sharp_solution
{
	/// <summary>

	/// </summary>
	public class simpleLaunchStep 
	{
        /** just to show how to set attachments
         */
		public PESession myPESession;
        private ProcessEngineServiceClient peWSClient;

        public simpleLaunchStep(ProcessEngineServiceClient client)
		{
            peWSClient = client;
		}


        public static bool isEmpty(pewsWCF.Value[] values)
        {
            if (values.Length > 1)
                return false;
            // check for item..
            if (values[0].Item is pewsWCF.Attachment)
            {
                pewsWCF.Attachment att = (pewsWCF.Attachment)values[0].Item;
                if (att.Type == pewsWCF.AttachmentTypeEnum.ATTACHMENT_TYPE_UNDEFINED)
                    return true;
            }
            return values[0].Item == null;
        }
        public static string Values2String(pewsWCF.Value[] values)
        {
            //check for array...
            System.Text.StringBuilder buf = new System.Text.StringBuilder("Values..");
            if (isEmpty(values))
                buf.Append("Empty");
            else{
                int len = values.Length;
                for (int i=0; i<len; i++)
                {
                    buf.Append("\n").Append(i).Append("=").Append(values[i].Item);
                }
            }
            return buf.ToString();
        }
        public void launch(string workClassName)
        {
            pewsWCF.StepElement stepElement = peWSClient.createWorkflow(workClassName);
            // go through the parameter and initialized with at least F_Subject.
            // not sure about response..
            System.Text.StringBuilder status = new System.Text.StringBuilder("Status..");

			pewsWCF.Parameter[] parameters = stepElement.Parameters;
			
			//Responses as pewsWCF.ArrayOfResponse = stepElement.Responses
            // check to see if we need response
            if (stepElement.Responses != null && stepElement.Responses.Response != null &&
                    stepElement.Responses.Response.Length > 0)
            {
                // just pick the first one..
                stepElement.Responses.Selected = (string) stepElement.Responses.Response.GetValue(0);
                status.Append("\nSelected Response=").Append(stepElement.Responses.Selected);
            }
            foreach (pewsWCF.Parameter param in parameters)
            {
                status.Append("\n").Append(param.Name).Append(Values2String (param.Values));
                // check for F_Subject
                if (param.Name.Equals("F_Subject"))
                {
                    string curSubject = param.Values[0].Item + " Time=" + new System.DateTime();
                    status.Append("\n\t...Setting subject = ").Append(curSubject);
                    pewsWCF.Value val=new pewsWCF.Value();
                    val.ItemElementName = pewsWCF.ItemChoiceType.stringField;
                    val.Item = curSubject;
                    param.Values[0] = val;
                    param.Modified = true;  // don't forget to set this to true, otherwise, the new values won't be taken.
                    continue;
                }
                if (param.Mode == pewsWCF.ModeTypeEnum.MODE_TYPE_IN )
               
                {
                    status.Append("...Skipped ");
                    continue;
                }



                if (param.IsArray)
                    switch (param.Type)
                    {
                        case pewsWCF.FieldTypeEnum.FIELD_TYPE_ATTACHMENT:
                            param.Modified = true;  // don't forget to set this to true, otherwise, the new values won't be taken.

                            pewsWCF.Attachment att = new pewsWCF.Attachment();
                            att.LibraryType = pewsWCF.LibraryTypeEnum.LIBRARY_TYPE_CONTENT_ENGINE;
                            att.Type = pewsWCF.AttachmentTypeEnum.ATTACHMENT_TYPE_DOCUMENT;
                            att.Id = "{E73C797A-D72D-4E27-AB60-872E2CA05E91}";  // this is the Version Series id of the document
                            att.Version = "-1";      // this is for released version  
                            att.Library = "CEMPOS";
                            att.Name = "MYATT";
                            att.Description = "ARRAY ATTACHED from .NET";

                            pewsWCF.Attachment att2 = new pewsWCF.Attachment();
                            att2.LibraryType = pewsWCF.LibraryTypeEnum.LIBRARY_TYPE_CONTENT_ENGINE;
                            att2.Type = pewsWCF.AttachmentTypeEnum.ATTACHMENT_TYPE_DOCUMENT;
                            att2.Id = "{E73C797A-D72D-4E27-AB60-872E2CA05E91}";  // this is the Version Series Id of the document
                            att2.Version = null;     // this is for current version 
                            att2.Library = "CEMPOS";
                            att2.Name = "MYATT#2";
                            att2.Description = "ARRAY ATTACHED from .NET for arr#2";

                            param.Values = new PE_C_Sharp_solution.pewsWCF.Value[2];
                            pewsWCF.Value val = new pewsWCF.Value();
                            val.ItemElementName = pewsWCF.ItemChoiceType.attachmentField;
                            val.Item = att;

                            pewsWCF.Value val2 = new pewsWCF.Value();
                            val.ItemElementName = pewsWCF.ItemChoiceType.attachmentField;
                            val2.Item = att;

                            param.Values[0] = val;
                            param.Values[1] = val2;
                            break;
                        case pewsWCF.FieldTypeEnum.FIELD_TYPE_BOOLEAN:
                            break;
                        case pewsWCF.FieldTypeEnum.FIELD_TYPE_DOUBLE:
                            break;
                        case pewsWCF.FieldTypeEnum.FIELD_TYPE_INTEGER:
                            break;
                        case pewsWCF.FieldTypeEnum.FIELD_TYPE_PARTICIPANT:
                            break;
                        case pewsWCF.FieldTypeEnum.FIELD_TYPE_STRING:
                            break;
                        case pewsWCF.FieldTypeEnum.FIELD_TYPE_TIME:
                            break;

                    }
                else
                    switch (param.Type)
                    {
                        case pewsWCF.FieldTypeEnum.FIELD_TYPE_ATTACHMENT:
                            param.Modified = true;  // don't forget to set this to true, otherwise, the new values won't be taken.

                            pewsWCF.Attachment att = new pewsWCF.Attachment();
                            att.LibraryType = pewsWCF.LibraryTypeEnum.LIBRARY_TYPE_CONTENT_ENGINE;
                            att.Type = pewsWCF.AttachmentTypeEnum.ATTACHMENT_TYPE_DOCUMENT;
                            att.Id = "{E73C797A-D72D-4E27-AB60-872E2CA05E91}";  // this is the Version Series id of the document
                            att.Version = "-1";      // this is for released version  
                            att.Library = "CEMPOS";
                            att.Name = "MYATT";
                            att.Description = "SINGLE ATTACHED from .NET";


                            param.Values = new PE_C_Sharp_solution.pewsWCF.Value[1];
                            pewsWCF.Value val = new pewsWCF.Value();

                            val.ItemElementName = PE_C_Sharp_solution.pewsWCF.ItemChoiceType.attachmentField;
                            val.Item = att;
                            param.Values[0] = val;
                            break;
                        case pewsWCF.FieldTypeEnum.FIELD_TYPE_BOOLEAN:
                            break;
                        case pewsWCF.FieldTypeEnum.FIELD_TYPE_DOUBLE:
                            break;
                        case pewsWCF.FieldTypeEnum.FIELD_TYPE_INTEGER:
                            break;
                        case pewsWCF.FieldTypeEnum.FIELD_TYPE_PARTICIPANT:
                            break;
                        case pewsWCF.FieldTypeEnum.FIELD_TYPE_STRING:
                            break;
                        case pewsWCF.FieldTypeEnum.FIELD_TYPE_TIME:
                            break;

                    }
                    
                }

             System.Windows.Forms.MessageBox.Show(status.ToString());
           dispatchStepElement(stepElement);

        }

        // Unlocks and saves the work object associated with the step element, then advances the work 
        // object in the workflow. Used by both launch and stepprocessor form. 
        private void dispatchStepElement(pewsWCF.StepElement stepElement)
        {
            pewsWCF.UpdateStepRequest updStepRequest = new pewsWCF.UpdateStepRequest();
            pewsWCF.UpdateFlagEnum updFlagEnum = pewsWCF.UpdateFlagEnum.UPDATE_DISPATCH;
            updStepRequest.stepElement = stepElement;
            updStepRequest.updateFlag = updFlagEnum;
            peWSClient.updateStep(updStepRequest);
        }
	}
}
