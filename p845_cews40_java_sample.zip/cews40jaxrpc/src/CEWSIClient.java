/*
 * DISCLAIMER OF WARRANTIES
 * 
 * The accompanying code is sample code created by IBM Corporation. 
 * This sample code is not part of any standard or IBM product and 
 * is provided to you solely for the purpose of assisting you in the 
 * development of your applications. The code is provided "AS IS", 
 * without warranty of any kind. IBM shall not be liable for any 
 * damages arising out of your use of the sample code, even if they 
 * have been advised of the possibility of such damages.
 */
import javax.swing.*; 
import javax.swing.tree.*;
import javax.swing.event.*;

import javax.xml.namespace.QName;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.HandlerRegistry;

import java.io.*;
import java.util.Properties;

import com.filenet.www.cews.util.ServerConfig;
import com.filenet.www.cews.util.WSAHandler;
import com.filenet.www.ns.fnce._2006._11.ws.SOAP.wsdl.*;

import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class CEWSIClient {
	
	public static Object fnStub = null;
	
	public static String protocolValue = "HTTP";
	public static String serverName    = "localhost";
	public static String portValue     = "9080";
	public static String bindingName   = "SOAP";
	public static String serviceName   = "FNCEWS40" + "Inline" + "Port";
	public static String endPointName  = "FNCEWS40" + bindingName;
	
	private static boolean isSavedOnce = false;
	
	static JFrame frame = new JFrame("FileNet Content Engine Web Service Demo");
	static JTabbedPane tabbedPane = new JTabbedPane();
	
	//panels for tabedPane
	static JPanel serverConfigPane     = new JPanel();
	static JPanel documentPane         = new JPanel();
	static JPanel folderPane           = new JPanel();
	static JPanel propertyTemplatePane = new JPanel();
	static JPanel classPane            = new JPanel();
	static JPanel adhocQueryPane       = new JPanel();
	static JPanel folderContaineePane  = new JPanel();
	
	//Adhoc Query panel components
	static JLabel QueryPramLabel    = new JLabel("Query Parameters");	
	static JLabel selectLabel       = new JLabel("   SELECT: ");
	static JTextField selectText    = new JTextField("SymbolicName, Id, IsHidden, IsSystemOwned, This",35);
	static JLabel fromLabel         = new JLabel("   FROM: ");
	static JTextField fromText      = new JTextField("ClassDefinition",35);
	static JLabel whereLabel        = new JLabel("   WHERE: ");
	static JTextField whereText     = new JTextField("AllowsSubclasses=TRUE",35);
	static JLabel maxRowsLabel      = new JLabel("   Max Rows: ");
	static JTextField maxRowsText   = new JTextField("100",5);
	static JButton queryNowButton   = new JButton("Query Now");
	static JLabel queryResultsLabel = new JLabel("Query Results");
	static JScrollPane queryResultsScrollPane = null;
	static String[] listOfResults   = new String[]{""};
	static JList queryResultsList   = new JList(listOfResults);

	//Display Folder tree panel components
	static JTree folderTreeCtrl               = new JTree();
	static FolderNode selectedFolderNode      = null; 
	static DefaultMutableTreeNode currentNode = new DefaultMutableTreeNode();
	static JList containeesList               = new JList(new String[]{"                             "});
	static JButton findSubFoldersButton       = new JButton("Find Sub-Folders");
	static JButton getContaineesButton        = new JButton("Get Containees");
	
	//ClassDefinition panel components
	static JLabel classLabel                      = new JLabel("Specify Parent Class");
	static JLabel instructionsLabel               = new JLabel("   First use the Query now button to generate\n a list of sub-classable ClassDefinitions.");
	static JLabel instructionsLabel2              = new JLabel("   Then select the desired  Class Definition\n and use the CreateSubclass button to process.");
	static JLabel nameFilterLabel                 = new JLabel("   Name Filter: ");
	static JTextField nameFilterText              = new JTextField("",25);
	static JCheckBox includeSystemClassesCheckBox = new JCheckBox("Include System Classes");
	static JCheckBox includeHiddenClassesCheckBox = new JCheckBox("Include Hidden Classes");
	static JButton queryClassNowButton            = new JButton("Query Now");
	static JLabel queryClassResultsLabel          = new JLabel("ClassDefinition List:");
	static String[] listOfClasses                 = new String[]{"Query now for a list of ClassDefinitions !"};
	static JComboBox classList                    = new JComboBox(listOfClasses);
	static JLabel classParametersLabel            = new JLabel("Class Parameters");
	static JLabel symbolicNameLabel               = new JLabel("   Symbolic Name: ");
	static JTextField symbolicNameText            = new JTextField("NewClass",25);
	static JButton createClassButton              = new JButton("Create SubClass");

	//PropertyTemplate panel components
	static JLabel propertyLabel                 = new JLabel("Property Template Parameters");
	static JLabel symbolicNamePTLabel           = new JLabel("   Symbolic Name: ");
	static JTextField symbolicNamePTText        = new JTextField("NewPropertyTemplate",25);
	static JLabel dataTypeLabel                 = new JLabel("   Data Type: ");
	static String listOfDataType[]              = new String []{"Binary","Boolean","DateTime","Float","Id","Integer","Object","String"};
	static JComboBox dataTypeCombo              = new JComboBox(listOfDataType);
	static JButton createPropertyTemplateButton = new JButton("Create Property Template");
	static JPanel symbolicNamePanel             = new JPanel(new GridLayout(0,2));
	static JPanel dataTypePanel                 = new JPanel(new GridLayout(0,2));
	static JPanel buttonPanel                   = new JPanel(new GridLayout(0,3));
	static JPanel propertyTemplateCreatePanel   = new JPanel(new GridLayout(5,0));

	//Create Folder panel components
	static JLabel folderLabel                    = new JLabel("Folder Parameters");
	static JLabel folderNameLabel                = new JLabel("   Name: ");
	static JTextField folderNameText             = new JTextField("NewFolder",25);
	static JLabel parentLabel                    = new JLabel("   Parent: ");
	static JTextField parentText                 = new JTextField("/",25);
	static JLabel folderClassLabel               = new JLabel("   Folder Class: ");
	static JTextField folderClassText            = new JTextField("Folder",25);
	static JCheckBox propertyFilterDemoCheckBox  = new JCheckBox("Property Filter Demo");
	static JButton createFolderButton            = new JButton("Create Folder");

	//Create Document panel components
	static JLabel docLabel                      = new JLabel("Document Parameters");
	static JLabel titleLabel                    = new JLabel("   Title: ");
	static JTextField titleText                 = new JTextField("NewDocument",25);
	static JCheckBox includeContentFileCheckBox = new JCheckBox("Include content at location");
	static JTextField fileLocationText          = new JTextField("c:\\temp",25);
	static JCheckBox includeContentURLCheckBox  = new JCheckBox("Include content at URL");
	static JTextField urlLocationText           = new JTextField("http://www.filenet.com",25);
	static JLabel mimeTypeLabel                 = new JLabel("   Content MIME Type: ");
	static JTextField mimeTypeText              = new JTextField("text/plain",25);
	static JLabel docClassLabel                 = new JLabel("   Document Class: ");
	static JTextField docClassText              = new JTextField("Document",25);
	static JCheckBox fileInFolderCheckBox       = new JCheckBox("   File in folder: ");
	static JTextField fileInFolderText          = new JTextField("/",25);
	static JButton createDocButton              = new JButton("Create Document");

	//Server Config panel components (WSI info)
	static JLabel protocolLabel       = new JLabel("Protocol : ");
	static JTextField protocolText    = new JTextField(protocolValue,25);
	static JLabel serverNameLabel     = new JLabel("Server : ");
	static JTextField serverNameText  = new JTextField(serverName,25);
	static JLabel portLabel           = new JLabel("Port : ");
	static JTextField portText        = new JTextField(portValue,25);
	static JLabel serviceNameLabel    = new JLabel("Service : ");
	static JTextField serviceNameText = new JTextField(serviceName,25);
	static JLabel endPointLabel       = new JLabel("EndPoint : ");
	static JTextField endPointText    = new JTextField(endPointName,25);
	static JLabel bindingLabel        = new JLabel("Binding : ");
	static JTextField bindingText     = new JTextField(bindingName,25);

	//Server Config panel components (CE info)
	static JLabel userLabel            = new JLabel("User: ");
	static JTextField userText         = new JTextField("",25);
	static JLabel passwordLabel        = new JLabel("Password: ");
	static JPasswordField passwordText = new JPasswordField(25);
	static JLabel libraryLabel         = new JLabel("ObjectStore: ");
	static JTextField libraryText      = new JTextField("",25);
	static JLabel domainLabel          = new JLabel("Domain: ");    
	static JTextField domainText       = new JTextField("",25);
	static JButton saveButton          = new JButton("Save");

	static String saveMessage          = "You have not saved your Server configuration yet.";
	static String saveCaption          = "CE WSI";
	
	static FileInputStream propFile = null;
	static Properties propertiesCEWS40 = null;
	
	public static void main(String[] args) {
		
		
		try{
			System.out.println(System.getProperty("user.dir") + System.getProperty("file.separator") + "CEWS40.properties");
			propFile = new FileInputStream(System.getProperty("user.dir") + System.getProperty("file.separator") + "CEWS40.properties");
			propertiesCEWS40 = new Properties(System.getProperties());
			propertiesCEWS40.load(propFile);
		}catch(Exception e){
			System.out.println("Error in using properties file." + e.getMessage());
		}
		frame.getContentPane().setLayout(new BorderLayout());
        frame.getContentPane().add(TabbedPanel(),BorderLayout.CENTER);
          
        frame.setSize(820,600);
          
        frame.addWindowListener(new WindowAdapter() {
        	public void windowClosing(WindowEvent e) {
        		System.exit(0);
        	}
        });  
        frame.setVisible(true);
  	}

	private static String getUserPassword(char[] userPassword){
		String clearPassword = "";
		for(int indexOfChar = 0;indexOfChar < userPassword.length ;indexOfChar++){
			clearPassword = clearPassword + userPassword[indexOfChar];
		}
		return clearPassword;
	}
	
	//Generate a generic stub object with that uses the WSAHandler class for 
	//setting SOAP Headers for localization and Authentication
	private static Object getStub(String protocolValue, String serverName, String portValue, String serviceName, String endPointName,  String bindingName){
		
		com.ibm.ws.webservices.engine.client.Stub fnStub = null;
		
		try{
			String urlString = protocolValue + "://" + serverName + ":" +  portValue + "/wsi/" + endPointName + "/";
			java.net.URL myURL = new java.net.URL(urlString);
		
			if (bindingName.compareToIgnoreCase("SOAP") == 0){
				
				com.filenet.www.ns.fnce._2006._11.ws.SOAP.wsdl.FNCEWS40ServiceLocator serviceLocator = new com.filenet.www.ns.fnce._2006._11.ws.SOAP.wsdl.FNCEWS40ServiceLocator();
				HandlerRegistry hr=serviceLocator.getHandlerRegistry();
				QName portQName= new QName(protocolValue + "://" + serverName  + "/", serviceName);
				List hc=hr.getHandlerChain(portQName);
				HandlerInfo hInfo= new HandlerInfo(WSAHandler.class,null,null);
				hc.add(hInfo);
				
				fnStub =(FNCEWS40SoapBindingStub) serviceLocator.getFNCEWS40InlinePort(myURL);
				
			}else{
				throw new Error("Unable to locate a correct binding for stub creation.");		
			}
			
		}catch(Exception e){
			e.printStackTrace();
			throw new Error("Error creating Stub:" + e.getMessage() );
		}
		
		return fnStub;
	}

	//Methods for executing WSI calls and displaying results in GUI or message dialog boxes
	
	private static boolean createDocument(){
		String caption = "Create Document";
		
    	try{
    		
    		Object fnStub = getStub(protocolText.getText(),serverNameText.getText(),portText.getText(),serviceNameText.getText(),endPointText.getText(),bindingText.getText());
    		CreateDoc createADoc = new CreateDoc(); 
    		boolean returnValue = createADoc.create(fnStub,userText.getText(),getUserPassword(passwordText.getPassword()),libraryText.getText(),titleText.getText(),includeContentFileCheckBox.isSelected(),includeContentURLCheckBox.isSelected(),fileLocationText.getText(),urlLocationText.getText(),mimeTypeText.getText(), docClassText.getText(),fileInFolderCheckBox.isSelected(),fileInFolderText.getText());
    		
			JOptionPane.showMessageDialog(
		              frame,
		              createADoc.getMessageDisplay(),
		              caption,
		              JOptionPane.OK_OPTION);
    	}catch(Error e){
    		JOptionPane.showMessageDialog(
              frame,
              e.getMessage(),
              caption + " Error",
              JOptionPane.OK_OPTION);
    		e.getStackTrace();
    	}
    	return true;
    }
	
	private static boolean createFolder(){
		String caption = "Create Folder";
		
		try{
			CreateFolder createAFolder = new CreateFolder();
			boolean returnValue = createAFolder.create(fnStub,userText.getText(),getUserPassword(passwordText.getPassword()),libraryText.getText(),folderNameText.getText(),parentText.getText(),folderClassText.getText(),propertyFilterDemoCheckBox.isSelected());
			JOptionPane.showMessageDialog(
		              frame,
		              createAFolder.getMessageDisplay(),
		              caption,
		              JOptionPane.OK_OPTION);
			
		}catch(Error e){
    		JOptionPane.showMessageDialog(
              frame,
              e.getMessage(),
              caption + " Error",
              JOptionPane.OK_OPTION);
    	}
		return true;
    }
	
	private static boolean createPropertyTemplate(){
		String caption = "Create Property Template";
		
		try{
			CreatePropTemplate createAPropTemplate = new CreatePropTemplate();
			boolean returnValue = createAPropTemplate.create(fnStub,userText.getText(),getUserPassword(passwordText.getPassword()),libraryText.getText(),symbolicNamePTText.getText(),(String)dataTypeCombo.getSelectedItem());
			JOptionPane.showMessageDialog(
		              frame,
		              createAPropTemplate.getMessageDisplay(),
		              caption,
		              JOptionPane.OK_OPTION);
			
		}catch(Error e){
    		JOptionPane.showMessageDialog(
              frame,
              e.getMessage(),
              caption + " Error",
              JOptionPane.OK_OPTION);
    	}
		return true;
    	
    }
	
	private static boolean createClass(){
		String caption = "Create Class";
		try{
			
			CreateClassSelect createAClass = new CreateClassSelect();
			String parentClass = "";
			String parentId = "";
			String subStringParent;
			String fullParent = (String)classList.getSelectedItem();
			
			subStringParent = fullParent.substring(fullParent.indexOf(" ") + 1,fullParent.length());
			
			parentClass = subStringParent.substring(0,subStringParent.indexOf(" "));
			parentId = subStringParent.substring(subStringParent.indexOf(" ") + 1,subStringParent.length());
			
			JOptionPane.showMessageDialog(
		              frame,
		              parentClass + " : " +  parentId,
		              parentClass + " : " +  parentId,
		              JOptionPane.OK_OPTION);
			
			boolean returnValue = createAClass.createSubClass(fnStub,userText.getText(),getUserPassword(passwordText.getPassword()),libraryText.getText(),symbolicNameText.getText(),parentClass,parentId);
			JOptionPane.showMessageDialog(
		              frame,
		              createAClass.getMessageDisplay(),
		              caption,
		              JOptionPane.OK_OPTION);	
		}catch(Error e){
    		JOptionPane.showMessageDialog(
              frame,
              e.getMessage(),
              caption + " Error",
              JOptionPane.OK_OPTION);
    	}
		
    	return true;
    }
	
	private static boolean queryForClasses(){
		String caption = "Query for Classes";
		
		try{
			CreateClassSelect createAClass = new CreateClassSelect();
			String[] returnValue = createAClass.querySubClass(fnStub,userText.getText(),getUserPassword(passwordText.getPassword()),libraryText.getText(),nameFilterText.getText(),includeSystemClassesCheckBox.isSelected(),includeHiddenClassesCheckBox.isSelected());
			if(createAClass.getMessageDisplay().length() > 1){
				
			JOptionPane.showMessageDialog(
		              frame,
		              createAClass.getMessageDisplay(),
		              caption,
		              JOptionPane.OK_OPTION);
			}
			classList.removeAllItems();
			for(int indexOf = 0;indexOf < returnValue.length;indexOf++){
				classList.addItem((String)returnValue[indexOf]);
			}
			
		}catch(Error e){
    		JOptionPane.showMessageDialog(
              frame,
              e.getMessage(),
              caption + " Error",
              JOptionPane.OK_OPTION);
    	}
    	return true;
    }
	
	private static boolean adhocQuery(){
		String caption = "Adhoc Query";
		
		try{
			AdhocQuery runAdhocQuery = new AdhocQuery();
			
			String[] returnValue = runAdhocQuery.runAdhocQuery(fnStub,userText.getText(),getUserPassword(passwordText.getPassword()),libraryText.getText(), selectText.getText(), fromText.getText(), whereText.getText(), maxRowsText.getText());
			if(runAdhocQuery.getMessageDisplay().length() >1){
					JOptionPane.showMessageDialog(
		              frame,
		              runAdhocQuery.getMessageDisplay(),
		              caption,
		              JOptionPane.OK_OPTION);
			}
			queryResultsList.setListData(returnValue);
			queryResultsList.setAutoscrolls(true);
			
			
		}catch(Error e){
    		JOptionPane.showMessageDialog(
              frame,
              e.getMessage(),
              caption + " Error",
              JOptionPane.OK_OPTION);
    	}
    	
    	return true;
    }
	
	private static boolean findSubFolders(){
		String caption = "Folder Tree";
		try{
			
			FolderTree folderTree = new FolderTree();
			
			FolderNode[] listOfSubFolders = folderTree.findSubFolders(fnStub,userText.getText(),getUserPassword(passwordText.getPassword()),libraryText.getText(), selectedFolderNode);
			currentNode.setAllowsChildren(true);
			
			createNodes(currentNode,listOfSubFolders);
			folderTreeCtrl.updateUI();
			
		}catch(Error e){
    		JOptionPane.showMessageDialog(
              frame,
              e.getMessage(),
              caption + " Error",
              JOptionPane.OK_OPTION);
    	}

		return true;
	}
	
	private static boolean getContainees(){
		String caption = "Containees";
		try{
			
			FolderTree folderTree = new FolderTree();
			
			String[] returnValue = folderTree.getContainees(fnStub,userText.getText(),getUserPassword(passwordText.getPassword()),libraryText.getText(),  selectedFolderNode);
			
			if(folderTree.getMessageDisplay().length() >1){
				JOptionPane.showMessageDialog(
	              frame,
	              folderTree.getMessageDisplay(),
	              caption,
	              JOptionPane.OK_OPTION);
			}else{
			containeesList.setListData(returnValue);
			containeesList.setAutoscrolls(true);
			}	
		}catch(Error e){
    		JOptionPane.showMessageDialog(
              frame,
              e.getMessage(),
              caption + " Error",
              JOptionPane.OK_OPTION);
    	}
		return true;
	}
	
	//Setup GUI tabbed Panel
	private static JTabbedPane TabbedPanel(){
    	  
    	  serverConfigPane = createServerConfigPane();
    	  documentPane = createDocumentPane();
    	  folderPane = createFolderPane();
    	  propertyTemplatePane = createPropertyTemplatePane();
    	  classPane = createClassPane();
    	  adhocQueryPane = createAdhocQueryPane();
    	  folderContaineePane = createFolderContaineePane();
    	  
    	  tabbedPane.addTab ("Server Config",serverConfigPane);
    	  tabbedPane.addTab ("Create Document",documentPane);
    	  tabbedPane.addTab ("Create Folder",folderPane);
    	  tabbedPane.addTab ("Create Property Template",propertyTemplatePane);
    	  tabbedPane.addTab ("Create Class",classPane);
    	  tabbedPane.addTab ("Adhoc Query",adhocQueryPane);
    	  tabbedPane.addTab ("Folder Containee",folderContaineePane);
    	  tabbedPane.setSelectedIndex(0);
    	  tabbedPane.setMinimumSize(new Dimension(0,0));
    	  tabbedPane.setMaximumSize(new Dimension(20,20));
    	  
    	  return tabbedPane;
    	}

	private static void createNodes(DefaultMutableTreeNode top, FolderNode[] listOfFolders) {
        
    	DefaultMutableTreeNode category = null;
        
    	if(listOfFolders != null){
	        for(int indexOfNodes = 0; indexOfNodes < listOfFolders.length;indexOfNodes++){
	        	String nodeName = listOfFolders[indexOfNodes].getName();
	        	category = new DefaultMutableTreeNode(nodeName);
	        	FolderNode folderNode = listOfFolders[indexOfNodes];
	        	category.setUserObject(folderNode);
	        	top.add(category);
	        }
    	}
    }


	private static JPanel createFolderContaineePane(){
    	
		JPanel p = new JPanel(new BorderLayout());
    	
        JPanel buttonFolderPanel  = new JPanel(new GridLayout(0,2));       
        
        FolderNode rootFolderNode = new FolderNode();
        rootFolderNode.setExpanded(true);
        //default GUID for the root folder
        rootFolderNode.setId("{0F1E2D3C-4B5A-6978-8796-A5B4C3D2E1F0}");
        rootFolderNode.setName("/");
        rootFolderNode.setExpanded(false);
        
        
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("/");
        root.setUserObject(rootFolderNode);
        
        folderTreeCtrl = new JTree(root);

        folderTreeCtrl.addTreeExpansionListener(new TreeExpansionListener(){
            public void treeExpanded(TreeExpansionEvent e) {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode)folderTreeCtrl.getLastSelectedPathComponent();

                if (node == null) return;
                {
                //Object nodeInfo = node.getUserObject();
                	
                System.out.println("Tree expanded " + node.toString());
                }
            }
            public void treeCollapsed(TreeExpansionEvent e) {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode)folderTreeCtrl.getLastSelectedPathComponent();

                if (node == null) return;
                {
                //Object nodeInfo = node.getUserObject();
                }
            }
        });
        
        folderTreeCtrl.addTreeSelectionListener(new TreeSelectionListener() {
            public void valueChanged(TreeSelectionEvent e) {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode)folderTreeCtrl.getLastSelectedPathComponent();
                currentNode = node;
                if (node == null) return;
                {
                	Object nodeInfo = node.getUserObject();
                	if(nodeInfo instanceof FolderNode){
                		selectedFolderNode = (FolderNode)nodeInfo;
                	}
                }
            }
        });

        findSubFoldersButton.addActionListener(new ActionListener() {            
            public void actionPerformed(ActionEvent e) {
            	if(isSavedOnce){
            		findSubFolders();
            	}else{
            		JOptionPane.showMessageDialog(
            	              frame,
            	              saveMessage,
            	              saveCaption,
            	              JOptionPane.OK_OPTION);
            	}

            }
        });

        getContaineesButton.addActionListener(new ActionListener() {            
            public void actionPerformed(ActionEvent e) {
            	if(isSavedOnce){
            		getContainees();
            	}else{
            		JOptionPane.showMessageDialog(
            	              frame,
            	              saveMessage,
            	              saveCaption,
            	              JOptionPane.OK_OPTION);
            	}

            }
        });

        JScrollPane left = new JScrollPane(folderTreeCtrl);
		JScrollPane right = new JScrollPane(containeesList);
		left.setMaximumSize(new Dimension(0,0));
		right.setMaximumSize(new Dimension(0,0));
		JSplitPane pane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,left,right);
		pane.setOneTouchExpandable(true);
		pane.setDividerLocation(200);
		p.add(pane,BorderLayout.CENTER);
		
		buttonFolderPanel.add(findSubFoldersButton);
		buttonFolderPanel.add(getContaineesButton);
		p.add(buttonFolderPanel,BorderLayout.SOUTH);
		
    	return p;
    }
	
	private static JPanel createAdhocQueryPane() {
    
		selectText.setText(propertiesCEWS40.getProperty("CEWS40.select"));
		fromText.setText(propertiesCEWS40.getProperty("CEWS40.from"));
		whereText.setText(propertiesCEWS40.getProperty("CEWS40.where"));
		maxRowsText.setText(propertiesCEWS40.getProperty("CEWS40.maxRows"));
		
		
		JPanel p = new JPanel(new BorderLayout());
    
    	JPanel selectPanel       = new JPanel(new GridLayout(0,2));
        JPanel fromPanel         = new JPanel(new GridLayout(0,2));       
        JPanel wherePanel        = new JPanel(new GridLayout(0,2));
        JPanel maxRowsPanel      = new JPanel(new GridLayout(0,2));
        JPanel buttonPanel       = new JPanel(new GridLayout(0,2));
        JPanel queryResultsPanel = new JPanel(new GridLayout(2,0));
        JPanel adhocQueryPanel   = new JPanel(new GridLayout(9,0));
        
        
        selectPanel.add(selectLabel);
        selectPanel.add(selectText);
        
        fromPanel.add(fromLabel);
        fromPanel.add(fromText);
        
        wherePanel.add(whereLabel);
        wherePanel.add(whereText);
        
        maxRowsPanel.add(maxRowsLabel);
        maxRowsPanel.add(maxRowsText);
        
        buttonPanel.add(new JLabel("   "));
        buttonPanel.add(queryNowButton);
        
        queryResultsPanel.add(queryResultsLabel);
        queryResultsPanel.add(queryResultsList);
        
        adhocQueryPanel.add(QueryPramLabel);
        adhocQueryPanel.add(selectPanel);
        adhocQueryPanel.add(fromPanel);
        adhocQueryPanel.add(wherePanel);
        adhocQueryPanel.add(maxRowsPanel);
        adhocQueryPanel.add(new JLabel("   "));
        adhocQueryPanel.add(buttonPanel);
        adhocQueryPanel.add(new JLabel("   "));
        
        queryNowButton.addActionListener(new ActionListener() {            
            public void actionPerformed(ActionEvent e) {
            	if(isSavedOnce){
            		adhocQuery();
            	}else{
            		JOptionPane.showMessageDialog(
            	              frame,
            	              saveMessage,
            	              saveCaption,
            	              JOptionPane.OK_OPTION);
            	}

            }
        });

        
        JScrollPane left = new JScrollPane(adhocQueryPanel);
		JScrollPane right = new JScrollPane(queryResultsList);
		left.setMaximumSize(new Dimension(0,0));
		right.setMaximumSize(new Dimension(0,0));
		JSplitPane pane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,left,right);
		pane.setOneTouchExpandable(true);
		p.add(pane,BorderLayout.CENTER);
		

    	return p;
    }
	
	private static JPanel createClassPane() {
    	
		symbolicNameText.setText(propertiesCEWS40.getProperty("CEWS40.newClassSymbolicName"));
		
		
		JPanel p = new JPanel();
    	 
        JPanel queryPanel         = new JPanel(new GridLayout(3,2));
        JPanel queryInstPanel     = new JPanel(new GridLayout(4,0));
               
        JPanel queryResultsPanel  = new JPanel(new GridLayout(2,0));
        JPanel classParametsPanel = new JPanel(new GridLayout(5,2));
        JPanel classCreatePanel   = new JPanel(new GridLayout(6,0));
		
        
        queryInstPanel.add(classLabel);
        queryInstPanel.add(instructionsLabel);
        queryInstPanel.add(instructionsLabel2);
        queryInstPanel.add(new JLabel("          "));

        queryPanel.add(nameFilterLabel);
        queryPanel.add(nameFilterText);
        
        queryPanel.add(includeSystemClassesCheckBox);
        queryPanel.add(includeHiddenClassesCheckBox);
        
        queryPanel.add(new JLabel("          "));
        queryPanel.add(queryClassNowButton);
		
        queryResultsPanel.add(queryClassResultsLabel);
        queryResultsPanel.add(classList);
        
		
        classParametsPanel.add(new JLabel("          "));
        classParametsPanel.add(new JLabel("          "));
        classParametsPanel.add(classParametersLabel);
        classParametsPanel.add(new JLabel("          "));
        classParametsPanel.add(symbolicNameLabel);
        classParametsPanel.add(symbolicNameText);
        classParametsPanel.add(new JLabel("          "));
        classParametsPanel.add(new JLabel("          "));
        classParametsPanel.add(new JLabel("          "));
        classParametsPanel.add(createClassButton);
        
        
        classCreatePanel.add(queryInstPanel);
        classCreatePanel.add(queryPanel);
        classCreatePanel.add(queryResultsPanel);
        classCreatePanel.add(classParametsPanel);
		
        queryClassNowButton.addActionListener(new ActionListener() {            
            public void actionPerformed(ActionEvent e) {
            	if(isSavedOnce){
            		queryForClasses();
                }else{
            		JOptionPane.showMessageDialog(
            	              frame,
            	              saveMessage,
            	              saveCaption,
            	              JOptionPane.OK_OPTION);
            	}
            	
            }
        });
		
        createClassButton.addActionListener(new ActionListener() {            
            public void actionPerformed(ActionEvent e) {
            	if(isSavedOnce){
                	createClass();
                }else{
            		JOptionPane.showMessageDialog(
            	              frame,
            	              saveMessage,
            	              saveCaption,
            	              JOptionPane.OK_OPTION);
            	}
            }
        });

		p.add(classCreatePanel);
        
    	return p;
    }
    
	private static JPanel createPropertyTemplatePane() {
		
		symbolicNamePTText.setText(propertiesCEWS40.getProperty("CEWS40.newPropertyTemplateSymbolicName"));
		
		JPanel p = new JPanel();
 		
        symbolicNamePanel.add(symbolicNamePTLabel);
        symbolicNamePanel.add(symbolicNamePTText);
		
		dataTypePanel.add(dataTypeLabel);
		dataTypePanel.add(dataTypeCombo);

		
		buttonPanel.add(new JLabel("          "));
		buttonPanel.add(createPropertyTemplateButton);
		buttonPanel.add(new JLabel("          "));
		
		propertyTemplateCreatePanel.add(propertyLabel);
		propertyTemplateCreatePanel.add(symbolicNamePanel);
		propertyTemplateCreatePanel.add(dataTypePanel);
		propertyTemplateCreatePanel.add(dataTypePanel);
		propertyTemplateCreatePanel.add(new JLabel("          "));
		propertyTemplateCreatePanel.add(buttonPanel);
		
		createPropertyTemplateButton.addActionListener(new ActionListener() {            
            public void actionPerformed(ActionEvent e) {
            	if(isSavedOnce){
            		createPropertyTemplate();
                }else{
            		JOptionPane.showMessageDialog(
            	              frame,
            	              saveMessage,
            	              saveCaption,
            	              JOptionPane.OK_OPTION);
            	}
            	
            }
        });

		p.add(propertyTemplateCreatePanel);
        
    	return p;
    }

	private static JPanel createFolderPane() {
		
		folderNameText.setText(propertiesCEWS40.getProperty("CEWS40.newFolderName"));
		parentText.setText(propertiesCEWS40.getProperty("CEWS40.folderParent"));
		folderClassText.setText(propertiesCEWS40.getProperty("CEWS40.folderClass"));
		
		
		JPanel p = new JPanel();
         
        JPanel namePanel         = new JPanel(new GridLayout(0,2));
        JPanel parentPanel       = new JPanel(new GridLayout(0,2));
        JPanel folderClassPanel  = new JPanel(new GridLayout(0,2));
        JPanel propertyPanel     = new JPanel(new GridLayout(0,1));
        JPanel buttonPanel       = new JPanel(new GridLayout(0,3));
        JPanel folderCreatePanel = new JPanel(new GridLayout(7,0));
		
        namePanel.add(folderNameLabel);
		namePanel.add(folderNameText);
		
		parentPanel.add(parentLabel);
		parentPanel.add(parentText);

		folderClassPanel.add(folderClassLabel);
		folderClassPanel.add(folderClassText);
		
		propertyPanel.add(propertyFilterDemoCheckBox);
		
		buttonPanel.add(new JLabel("          "));
		buttonPanel.add(createFolderButton);
		buttonPanel.add(new JLabel("          "));
		
		folderCreatePanel.add(folderLabel);
		folderCreatePanel.add(namePanel);
		folderCreatePanel.add(parentPanel);
		folderCreatePanel.add(folderClassPanel);
		folderCreatePanel.add(propertyPanel);
		folderCreatePanel.add(new JLabel("          "));
		folderCreatePanel.add(buttonPanel);
		
		createFolderButton.addActionListener(new ActionListener() {            
            public void actionPerformed(ActionEvent e) {
            	if(isSavedOnce){
            		createFolder();
                }else{
            		JOptionPane.showMessageDialog(
            	              frame,
            	              saveMessage,
            	              saveCaption,
            	              JOptionPane.OK_OPTION);
            	}
            }
        });

		
		p.add(folderCreatePanel);
        
    	return p;
    }
    
	private static JPanel createDocumentPane() {
        
		titleText.setText(propertiesCEWS40.getProperty("CEWS40.newDocumentTitle"));
		fileLocationText.setText(propertiesCEWS40.getProperty("CEWS40.contentLocation"));
		mimeTypeText.setText(propertiesCEWS40.getProperty("CEWS40.contentMIMEType"));
		docClassText.setText(propertiesCEWS40.getProperty("CEWS40.documentClass"));
		fileInFolderText.setText(propertiesCEWS40.getProperty("CEWS40.fileInFolder"));
		
		JPanel p = new JPanel();
        
        JPanel titlePanel        = new JPanel(new GridLayout(0,2));
        JPanel includeFilePanel  = new JPanel(new GridLayout(0,2));
        JPanel includeURLPanel   = new JPanel(new GridLayout(0,2));
        JPanel mimePanel         = new JPanel(new GridLayout(0,2));
        JPanel docClassPanel     = new JPanel(new GridLayout(0,2));
        JPanel fileInFolderPanel = new JPanel(new GridLayout(0,2));
        JPanel buttonPanel       = new JPanel(new GridLayout(0,3));
        JPanel docCreatePanel    = new JPanel(new GridLayout(9,0));
		
        
        titlePanel.add(titleLabel);
		titlePanel.add(titleText);
		
		includeFilePanel.add(includeContentFileCheckBox);
		includeFilePanel.add(fileLocationText);

		includeURLPanel.add(includeContentURLCheckBox);
		includeURLPanel.add(urlLocationText);
		
		mimePanel.add(mimeTypeLabel);
		mimePanel.add(mimeTypeText);
		mimeTypeText.setEnabled(false);
		
		docClassPanel.add(docClassLabel);
		docClassPanel.add(docClassText);
		
		fileInFolderPanel.add(fileInFolderCheckBox);
		fileInFolderPanel.add(fileInFolderText);
		
		buttonPanel.add(new JLabel("          "));
		buttonPanel.add(createDocButton);
		buttonPanel.add(new JLabel("          "));
		
		docCreatePanel.add(docLabel);
		docCreatePanel.add(titlePanel);
		docCreatePanel.add(includeFilePanel);
		//docCreatePanel.add(includeURLPanel);
		docCreatePanel.add(mimePanel);
		docCreatePanel.add(docClassPanel);
		docCreatePanel.add(fileInFolderPanel);
		docCreatePanel.add(new JLabel("          "));
		docCreatePanel.add(buttonPanel);
		
		createDocButton.addActionListener(new ActionListener() {            
            public void actionPerformed(ActionEvent e) {
            	if(isSavedOnce){
            		createDocument();
            	}else{
            		JOptionPane.showMessageDialog(
            	              frame,
            	              saveMessage,
            	              saveCaption,
            	              JOptionPane.OK_OPTION);
            	}
            }
        });
		
		
		includeContentFileCheckBox.addActionListener(new ActionListener() {            
            public void actionPerformed(ActionEvent e) {
            	if(includeContentFileCheckBox.isSelected()){
            		mimeTypeText.setEnabled(true);
            	}else{
            		mimeTypeText.setEnabled(false);
            	}
            }
        });
		
		p.add(docCreatePanel);
		
		
        return p;
    }

    
	private static JPanel createServerConfigPane() {
		userText.setText(propertiesCEWS40.getProperty("CEWS40.user"));
		passwordText.setText(propertiesCEWS40.getProperty("CEWS40.password"));
		libraryText.setText(propertiesCEWS40.getProperty("CEWS40.objectStore"));
		protocolText.setText(propertiesCEWS40.getProperty("CEWS40.protocol"));
		serverNameText.setText(propertiesCEWS40.getProperty("CEWS40.server"));
		portText.setText(propertiesCEWS40.getProperty("CEWS40.port"));
		serviceNameText.setText(propertiesCEWS40.getProperty("CEWS40.service"));
		endPointText.setText(propertiesCEWS40.getProperty("CEWS40.endpoint"));
		bindingText.setText(propertiesCEWS40.getProperty("CEWS40.binding"));
		
		JPanel p = new JPanel();

        JPanel serverConfigPanel = new JPanel(new GridLayout(11,0));
        JPanel WSIUser = new JPanel(new GridLayout(0,2));
        //JPanel WSIDomain = new JPanel(new GridLayout(0,2));
        JPanel WSIPassword = new JPanel(new GridLayout(0,2));
        JPanel WSILibrary = new JPanel(new GridLayout(0,2));

        JPanel WSIProtocol = new JPanel(new GridLayout(0,2));
        JPanel WSIServer = new JPanel(new GridLayout(0,2));
        JPanel WSIPort = new JPanel(new GridLayout(0,2));
        JPanel WSIService = new JPanel(new GridLayout(0,2));
        JPanel WSIEndPoint = new JPanel(new GridLayout(0,2));
        JPanel WSIBinding = new JPanel(new GridLayout(0,2));
        
        JPanel WSISave = new JPanel(new GridLayout(0,3));
                
		WSIUser.add (userLabel);
		WSIUser.add (userText);
				
		WSIPassword.add (passwordLabel);
		WSIPassword.add (passwordText);
        
		WSILibrary.add (libraryLabel);
		WSILibrary.add (libraryText);
        
		WSIProtocol.add (protocolLabel);
		WSIProtocol.add (protocolText);
		
		WSIServer.add (serverNameLabel);
		WSIServer.add (serverNameText);
        
		WSIPort.add (portLabel);
		WSIPort.add (portText);
		
		WSIService.add (serviceNameLabel);
		WSIService.add (serviceNameText);

		WSIEndPoint.add (endPointLabel);
		WSIEndPoint.add (endPointText);

		WSIBinding.add (bindingLabel);
		WSIBinding.add (bindingText);

		JButton saveConfig = new JButton("Save");
		
		saveConfig.addActionListener(new ActionListener() {            
            public void actionPerformed(ActionEvent e) {
            	ServerConfig svrConf = ServerConfig.getServerConfigInstance();
            	svrConf.setUserName(userText.getText());
            	svrConf.setPassword(getUserPassword(passwordText.getPassword()));
            	
        		
            	try{
            		fnStub = getStub(protocolText.getText(),serverNameText.getText(),portText.getText(),serviceNameText.getText(),endPointText.getText(),bindingText.getText());
            		isSavedOnce = true;
                }catch(Error stubException){
            		JOptionPane.showMessageDialog(
            	              frame,
            	              stubException.getMessage(),
            	              "Stub Creation Exception",
            	              JOptionPane.OK_OPTION);

            	}
            }
        });
  
	      
		WSISave.add(new JLabel("          "));
		WSISave.add(saveConfig);
		WSISave.add(new JLabel("          "));
		
		
		serverConfigPanel.add(WSIUser);
		serverConfigPanel.add(WSIPassword);
		serverConfigPanel.add(WSILibrary);
		serverConfigPanel.add(WSIProtocol);
		serverConfigPanel.add(WSIServer);
		serverConfigPanel.add(WSIPort);
		serverConfigPanel.add(WSIService);
		serverConfigPanel.add(WSIEndPoint);
		serverConfigPanel.add(WSIBinding);
		
		serverConfigPanel.add(new JLabel("          "));
		serverConfigPanel.add(WSISave);
		
		p.add(serverConfigPanel);
		p.setVisible(true);
                 
        return p;
      }

    
	
    
}
