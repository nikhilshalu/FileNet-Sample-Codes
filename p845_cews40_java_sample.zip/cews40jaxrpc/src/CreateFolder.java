/*
 * DISCLAIMER OF WARRANTIES
 * 
 * The accompanying code is sample code created by IBM Corporation. 
 * This sample code is not part of any standard or IBM product and 
 * is provided to you solely for the purpose of assisting you in the 
 * development of your applications. The code is provided "AS IS", 
 * without warranty of any kind. IBM shall not be liable for any 
 * damages arising out of your use of the sample code, even if they 
 * have been advised of the possibility of such damages.
 */
import com.filenet.www.ns.fnce._2006._11.ws.SOAP.wsdl.*;
import com.filenet.www.ns.fnce._2006._11.ws.schema.*;

public class CreateFolder {
	
	String messageDisplay = "";
	public CreateFolder(){
	}
	
	public void setMessageDisplay(String messageTxt){
		messageDisplay = messageTxt;
	}
	public String getMessageDisplay(){
		return messageDisplay;
	}
	public boolean create(Object fnStub,String userAccount, String userPassword, String library, String folderName, String folderParent, String folderClass, boolean chkPropertyFilter){
		//		 Create the ChangeRequest
		ChangeRequestType objChange = new ChangeRequestType();
		CreateAction createVerb = new CreateAction();
		createVerb.setClassId(folderClass);
		objChange.setAction(new ActionType[1]);
		objChange.setAction(0,(ActionType)createVerb);
		objChange.setTargetSpecification(new ObjectReference());
		objChange.getTargetSpecification().setClassId("ObjectStore");
		objChange.getTargetSpecification().setObjectId(library);
		objChange.setId("1");

		ModifiablePropertyType[] objInputProps = new ModifiablePropertyType[2];
		objChange.setActionProperties(objInputProps);

		// Build a list of properties to set in the new folder (just the folder name and parent for now)
		//    -Folder name property
		SingletonString objString = new SingletonString();
		objString.setValue(folderName);
		objString.setPropertyId("FolderName");
		objInputProps[0] = objString;

		//    -Parent property
		ObjectSpecification objSpec = new ObjectSpecification();
		SingletonObject objObject = new SingletonObject();
		objSpec.setClassId("Folder");
		objSpec.setPath(folderParent);
		objSpec.setObjectStore(library);
		objObject.setPropertyId("Parent");
		objObject.setValue((ObjectEntryType)objSpec);
		objInputProps[1] = objObject;

		// Create a property filter
		objChange.setRefreshFilter(new PropertyFilterType());
		if( chkPropertyFilter)
		{
			// Get a smallish subset of properties
			objChange.getRefreshFilter().setIncludeProperties(new FilterElementType[5]);
			for(int i=0; i<5; i++){
				objChange.getRefreshFilter().setIncludeProperties(i,new FilterElementType());
			}
			objChange.getRefreshFilter().getIncludeProperties(0).set_value("FolderName");
			objChange.getRefreshFilter().getIncludeProperties(1).set_value("Creator");
			objChange.getRefreshFilter().getIncludeProperties(2).set_value("Id");
			objChange.getRefreshFilter().getIncludeProperties(3).set_value("Parent");
			objChange.getRefreshFilter().getIncludeProperties(4).set_value("SubFolders");
			
			
		}
		else
		{
			// Build a list of properties to exclude on the refreshed folder object that is returned
			String[] strExclude = new String[2];
			strExclude[0] = "DateCreated";
			strExclude[1] = "DateLastModified";
			objChange.getRefreshFilter().setExcludeProperties(strExclude);
		}

		// Send off the request
		ChangeResponseType[] objResponseArray = null;
		ExecuteChangesRequest objRequest = new ExecuteChangesRequest();
		objRequest.setRefresh(new Boolean(true));
		objRequest.setChangeRequest(new ChangeRequestType[1]);
		objRequest.setChangeRequest(0,objChange);
		try
		{
				if(fnStub instanceof FNCEWS40SoapBindingStub){
					FNCEWS40SoapBindingStub fnSoapStub = (FNCEWS40SoapBindingStub)fnStub;
					objResponseArray = fnSoapStub.executeChanges(objRequest);
				}else{
					throw new Error("Unable to locate a correct binding.");		
				}
			
		}
		catch(FaultStackType faultStackType){
			ErrorRecordType errorRecordType = faultStackType.getErrorRecord(0);
			throw new Error("A FaultStackType exception occurred while creating a folder: \n [Description: " + errorRecordType.getDescription() + "]");
		}
		catch(Exception ex)
		{
			setMessageDisplay("An exception occurred while creating a folder: [" + ex.getMessage() + "]");
			return false;
		}

		// Created a folder!  Sanity check the results
		String strObjectId = "";
		boolean bFound = false;

		if( objResponseArray == null )
		{
			setMessageDisplay("The change request was executed, but a valid object was not returned");
			return false;
		}
		ChangeResponseType objResponse = objResponseArray[0];
		for(int indexOfProps = 0;indexOfProps < objResponse.getProperty().length;indexOfProps++)
		{
			PropertyType objProp = objResponse.getProperty(indexOfProps);
			if (objProp.getPropertyId().compareToIgnoreCase("Id") == 0)
			{
				SingletonId sId = (SingletonId)objProp;
				strObjectId = sId.getValue(); 
					
				bFound = true;
				break;
			}
		}
		if( !bFound )
		{
			setMessageDisplay("The folder was created, but the results do not contain a folder ID!");
			return false;
		}
		setMessageDisplay("Successfully created a folder!  ID = [" + strObjectId + "]");
		return true;
	}

}
