/*
 * DISCLAIMER OF WARRANTIES
 * 
 * The accompanying code is sample code created by IBM Corporation. 
 * This sample code is not part of any standard or IBM product and 
 * is provided to you solely for the purpose of assisting you in the 
 * development of your applications. The code is provided "AS IS", 
 * without warranty of any kind. IBM shall not be liable for any 
 * damages arising out of your use of the sample code, even if they 
 * have been advised of the possibility of such damages.
 */
import com.filenet.www.ns.fnce._2006._11.ws.SOAP.wsdl.*;
import com.filenet.www.ns.fnce._2006._11.ws.schema.*;

import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeExpansionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.*;
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FolderTree extends JPanel{

	static JTree folderTreeCtrl          = new JTree();
	static FolderNode selectedFolderNode = null; 
	static DefaultMutableTreeNode currentNode = new DefaultMutableTreeNode();
	static JList containeesList          = new JList(new String[]{"                             "});
	static JButton findSubFoldersButton  = new JButton("Find Sub-Folders");
	static JButton getContaineesButton   = new JButton("Get Containees");
	static String userName = "";
	static String password = "";
	static String library = "";
	static Object fnStub = null;
	
	String messageDisplay = "";
	
	public FolderTree(){
	}

	public FolderTree(String uName, String uPassword,String uLibrary){
    	
        JPanel buttonFolderPanel  = new JPanel(new GridLayout(0,2));       
        JPanel folderTreePanel    = new JPanel(new BorderLayout());
        
        FolderNode rootFolderNode = new FolderNode();
        rootFolderNode.setExpanded(true);
        //default GUID for root
        rootFolderNode.setId("{0F1E2D3C-4B5A-6978-8796-A5B4C3D2E1F0}");
        rootFolderNode.setName("/");
        rootFolderNode.setExpanded(false);
        
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("/");
        root.setUserObject(rootFolderNode);
        
        folderTreeCtrl = new JTree(root);
        folderTreeCtrl.setScrollsOnExpand(true);
        folderTreeCtrl.setAutoscrolls(true);
        folderTreeCtrl.setMinimumSize(new Dimension(0,0));
        
        JScrollPane scrlFolder = new JScrollPane(folderTreeCtrl);
        
        folderTreeCtrl.addTreeExpansionListener(new TreeExpansionListener(){
            public void treeExpanded(TreeExpansionEvent e) {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode)folderTreeCtrl.getLastSelectedPathComponent();

                if (node == null) return;
                {
                }
            }
            public void treeCollapsed(TreeExpansionEvent e) {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode)folderTreeCtrl.getLastSelectedPathComponent();

                if (node == null) return;
                {
                }
            }
        });
        
        folderTreeCtrl.addTreeSelectionListener(new TreeSelectionListener() {
            public void valueChanged(TreeSelectionEvent e) {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode)folderTreeCtrl.getLastSelectedPathComponent();
                currentNode = node;
                if (node == null) return;
                {
                
                Object nodeInfo = node.getUserObject();
                if(nodeInfo instanceof FolderNode){
                	selectedFolderNode = (FolderNode)nodeInfo;
                }
                }
            }
        });

             
        buttonFolderPanel.add(findSubFoldersButton);
        buttonFolderPanel.add(getContaineesButton);
        findSubFoldersButton.addActionListener(new ActionListener() {            
            public void actionPerformed(ActionEvent e) {
            		findSubFolders();
            }
        });

        getContaineesButton.addActionListener(new ActionListener() {            
            public void actionPerformed(ActionEvent e) {
            		getContainees();
            }
        });
        
        containeesList.setMinimumSize(new Dimension(0,0));
        containeesList.setAutoscrolls(true);
        
        JScrollPane containeeScrollPane = new JScrollPane(containeesList);
        
             
        JSplitPane slitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,scrlFolder,containeeScrollPane);
        slitPane.setMaximumSize(new Dimension(10,10));
        slitPane.setMinimumSize(new Dimension(0,0));
        
        slitPane.setContinuousLayout(true);
        slitPane.setOneTouchExpandable(true);
        slitPane.setDividerLocation(0.5);
        
        folderTreePanel.add(slitPane,BorderLayout.CENTER);
        folderTreePanel.add(buttonFolderPanel,BorderLayout.NORTH);
        
        add(folderTreePanel);

	}
	
	public void setMessageDisplay(String messageTxt){
		messageDisplay = messageTxt;
	}
	public String getMessageDisplay(){
		return messageDisplay;
	}
	public static boolean getContainees(){
		try{
			
			FolderTree folderTree = new FolderTree();
			
			String[] returnValue = folderTree.getContainees(fnStub,userName,password,library,  selectedFolderNode);
			
			containeesList.setListData(returnValue);
			containeesList.setAutoscrolls(true);
		}catch(Error e){
    	}
		return true;
	}

	public static boolean findSubFolders(){
		try{
			
			FolderTree folderTree = new FolderTree();
			
			FolderNode[] listOfSubFolders = folderTree.findSubFolders(fnStub,userName,password,library, selectedFolderNode);
			currentNode.setAllowsChildren(true);
			
			createNodes(currentNode,listOfSubFolders);
			folderTreeCtrl.updateUI();
			
		}catch(Error e){
    	}

	return true;
	}

	private static void createNodes(DefaultMutableTreeNode top, FolderNode[] listOfFolders) {
        
    	
    	DefaultMutableTreeNode category = null;
        
    	if(listOfFolders != null){
	        for(int indexOfNodes = 0; indexOfNodes < listOfFolders.length;indexOfNodes++){
	        	
	        	String nodeName = listOfFolders[indexOfNodes].getName();
	        	
	        	category = new DefaultMutableTreeNode(nodeName);
	        	FolderNode fn = listOfFolders[indexOfNodes];
	        	
	        	category.setUserObject(fn);
	        	top.add(category);
	        }
    	}
    }

	public FolderNode[] findSubFolders(Object fnStub,String userAccount, String userPassword, String library, FolderNode fNode){
		FolderNode[] listOfSubFolders = null;
		int numSubfolders = 0;

		if( fNode == null )
		{
			setMessageDisplay("You must first select a folder node");
			return null;
		}
		// Don't waste time expanding the same node twice...
		if(fNode.getExpanded())
			return null;

		// Properties to exclude in the query results
		String strFolderId = fNode.getId();

		// Get the folder's Subfolders list object
		ObjectRequestType	objSubFoldersRequest = new ObjectRequestType();
		ObjectSpecification objSubFoldersSpec = new ObjectSpecification();
		objSubFoldersSpec.setClassId("Folder");
		objSubFoldersSpec.setObjectId(strFolderId);
		objSubFoldersSpec.setObjectStore(library);
		objSubFoldersSpec.setPropertyId("SubFolders");
		objSubFoldersSpec.setItemIndex(-1); // server treats value -1 same as null
		objSubFoldersRequest.setSourceSpecification(objSubFoldersSpec);
		objSubFoldersRequest.setId("1");
		objSubFoldersRequest.setPropertyFilter(new PropertyFilterType());
		String[] strExclude = new String[5];
		strExclude[0] = "DateCreated";
		strExclude[1] = "DateLastModified";
		strExclude[2] = "ObjectStore";
		strExclude[3] = "ClassDescription";
		strExclude[4] = "Parent";
		objSubFoldersRequest.getPropertyFilter().setExcludeProperties(strExclude);

		// Create the request array
		ObjectRequestType[] objRequestArray = new ObjectRequestType[1];
		objRequestArray[0] = objSubFoldersRequest;

			
		// Send off the request
		ObjectResponseType[] objResponses = null;
		try
		{
			if(fnStub instanceof FNCEWS40SoapBindingStub){
				FNCEWS40SoapBindingStub fnSoapStub = (FNCEWS40SoapBindingStub)fnStub;
				objResponses = fnSoapStub.getObjects(objRequestArray);
			}else{
				throw new Error("Unable to locate a correct binding.");		
			}
		}
		catch(FaultStackType faultStackType){
			ErrorRecordType errorRecordType = faultStackType.getErrorRecord(0);
			throw new Error("A FaultStackType exception occurred while querying for a folder: \n [Description: " + errorRecordType.getDescription() + "]");
		}
		catch(Exception ex)
		{
			setMessageDisplay("An exception occurred while querying for a folder: [" + ex.getMessage() + "]");
			return null;
		}

		// Get the nodes below the parent
		
		if (objResponses.length > 0 && objResponses[0].getId().compareToIgnoreCase("1") == 0)
		{
			
			if( objResponses[0] instanceof ErrorStackResponse )
			{
				ErrorStackResponse objErrorResponse = (ErrorStackResponse)objResponses[0];
				ErrorStackType objStack = objErrorResponse.getErrorStack();
				ErrorRecordType objErr = objStack.getErrorRecord(0);
				setMessageDisplay("Error [" + objErr.getDescription() + "] occurred. " +
					" Err source is [" + objErr.getSource() + "]");
				return null;
			}

			ObjectSetResponse objResp = (ObjectSetResponse)objResponses[0];
			
			ObjectSetType objSet = (ObjectSetType)objResp.getObjectSet();
			if( objSet.getObject() != null && objSet.getObject().length > 0 )
			{
				listOfSubFolders = new FolderNode[objSet.getObject().length];
				for(int indexOfObjects=0; indexOfObjects < objSet.getObject().length;indexOfObjects++)
				{
					
					ObjectValue objValue = objSet.getObject(indexOfObjects);
					numSubfolders += 1;
					DefaultMutableTreeNode objNode = new DefaultMutableTreeNode();
					FolderNode newNode = new FolderNode();
					
					for(int indexOfProperties = 0;indexOfProperties < objValue.getProperty().length; indexOfProperties++)
					{
						PropertyType objProp = objValue.getProperty(indexOfProperties);
						if( objProp.getPropertyId().compareToIgnoreCase("FolderName") ==0 )
						{
							SingletonString ssName = (SingletonString)objProp;
							newNode.setName(ssName.getValue());
						}
						if( objProp.getPropertyId().compareToIgnoreCase("Id") == 0 )
						{
							SingletonId ssId = (SingletonId)objProp;
							newNode.setId(ssId.getValue());
						}
						
					}
					newNode.setExpanded(false);
					listOfSubFolders[indexOfObjects] = newNode;
				}
				
			}
		}
		fNode.setExpanded(true);
		return listOfSubFolders;
		
	}

	
	public String[] getContainees(Object fnStub,String userAccount, String userPassword, String library,FolderNode fNode){
		String[] returnListOfContainees = null;
		
		// Get the ID of the folder we are to search for containees
		if( fNode == null )
		{
			setMessageDisplay("You must first select a folder node");
			return null;
		}
		String strFolderId = fNode.getId();

		// Properties to exclude in the query results
		String[] strExclude = new String[2];
		strExclude[0] = "DateCreated";
		strExclude[1] = "DateLastModified";

		// Get the folder's Containees list object
		ObjectRequestType objContaineesRequest = new ObjectRequestType();
		ObjectSpecification objContaineesSpec = new ObjectSpecification();
		objContaineesSpec.setClassId("Folder");
		objContaineesSpec.setObjectId(strFolderId);
		objContaineesSpec.setObjectStore(library);
		objContaineesSpec.setPropertyId("Containees");
		objContaineesSpec.setItemIndex(-1); // server treats value -1 same as null

		objContaineesRequest.setSourceSpecification(objContaineesSpec);
		objContaineesRequest.setId("1");

		// Make sure to ask for the Head property of the RCR
		objContaineesRequest.setPropertyFilter(new PropertyFilterType());
		FilterElementType filterHead = new FilterElementType();
		FilterElementType filterCName = new FilterElementType();
		FilterElementType filterId = new FilterElementType();
		FilterElementType filterCreator = new FilterElementType();
		FilterElementType filterContentSize = new FilterElementType();
		FilterElementType filterTitle = new FilterElementType();

		filterHead.set_value("Head");
		filterHead.setMaxRecursion(1);
		filterCName.set_value("ContainmentName");
		filterCName.setMaxRecursion(1);
		filterId.set_value("Id");
		filterId.setMaxRecursion(1);
		filterCreator.set_value("Creator");
		filterCreator.setMaxRecursion(1);
		filterContentSize.set_value("ContentSize");
		filterContentSize.setMaxRecursion(1);
		filterTitle.set_value("DocumentTitle");
		filterTitle.setMaxRecursion(1);

		objContaineesRequest.getPropertyFilter().setIncludeProperties(new FilterElementType[6]);
		objContaineesRequest.getPropertyFilter().setIncludeProperties(0,filterHead);
		objContaineesRequest.getPropertyFilter().setIncludeProperties(1,filterCName);
		objContaineesRequest.getPropertyFilter().setIncludeProperties(2,filterId);
		objContaineesRequest.getPropertyFilter().setIncludeProperties(3,filterCreator);
		objContaineesRequest.getPropertyFilter().setIncludeProperties(4,filterContentSize);
		objContaineesRequest.getPropertyFilter().setIncludeProperties(5,filterTitle);
		objContaineesRequest.getPropertyFilter().setExcludeProperties(strExclude);
		
		// Create the request array
		ObjectRequestType[] objRequestArray = new ObjectRequestType[1];
		objRequestArray[0] = objContaineesRequest;

		
		// Send off the request
		ObjectResponseType[] objResponses = null;
		try
		{
			if(fnStub instanceof FNCEWS40SoapBindingStub){
				FNCEWS40SoapBindingStub fnSoapStub = (FNCEWS40SoapBindingStub)fnStub;
				objResponses = fnSoapStub.getObjects(objRequestArray);
			}else{
				throw new Error("Unable to locate a correct binding.");		
			}
		}
		catch(FaultStackType faultStackType){
			ErrorRecordType errorRecordType = faultStackType.getErrorRecord(0);
			throw new Error("A FaultStackType exception occurred while querying for containees: \n [Description: " + errorRecordType.getDescription() + "]");
		}
		catch( Exception ex)
		{
			setMessageDisplay("An exception occurred while querying for containees: [" + ex.getMessage() + "]");
			return null;
		}
		if( objResponses[0] instanceof ErrorStackResponse )
		{
			ErrorStackResponse objErrorResponse = (ErrorStackResponse)objResponses[0];
			ErrorStackType objStack = objErrorResponse.getErrorStack();
			ErrorRecordType objErr = objStack.getErrorRecord(0);
			setMessageDisplay("Error [" + objErr.getDescription() + "] occurred. " +
				" Err source is [" + objErr.getSource() + "]");
			return null;
		}

		ObjectSetResponse objSetResp = (ObjectSetResponse)objResponses[0];
		
		ObjectSetType objResults = (ObjectSetType)objSetResp.getObjectSet();
		
		if( objResults.getObject() != null && objResults.getObject().length > 0 )
		{
	
		// Query was successful; display a list of result rows
		// First create a data table that has our columns in it
		// For each containee, make an entry in our data table
		ObjectValue objHead = null;
		returnListOfContainees = new String[objResults.getObject().length];
		for(int indexOf = 0;indexOf < objResults.getObject().length ;indexOf++)
		{
			String newListBoxItem = "";
			ObjectValue currentContainee = objResults.getObject(indexOf);
			for (int indexOfPropCont = 0;indexOfPropCont< currentContainee.getProperty().length;indexOfPropCont++)
			{
				PropertyType objProp = currentContainee.getProperty(indexOfPropCont);
				
				if( objProp.getPropertyId().compareToIgnoreCase( "ContainmentName" ) == 0)
				{  
					SingletonString sProp = (SingletonString)objProp;
					newListBoxItem  = newListBoxItem + " | " + sProp.getValue();
				}
				
				 
				if( objProp.getPropertyId().compareToIgnoreCase( "Id") == 0 )
				{ 
					SingletonId sProp = (SingletonId)objProp;
					newListBoxItem  = newListBoxItem + " | " + sProp.getValue();
				}

				if(objProp.getPropertyId().compareToIgnoreCase( "Head") == 0 )
				{
					SingletonObject sObj = (SingletonObject)objProp;
					objHead = (ObjectValue)sObj.getValue();
					
					newListBoxItem  = newListBoxItem + " | " + objHead.getClassId().toString();
					for(int indexOfProp = 0;indexOfProp< objHead.getProperty().length;indexOfProp++)
					{
						PropertyType objHeadProp = objHead.getProperty(indexOfProp); 
						if( objHeadProp.getPropertyId().compareToIgnoreCase( "Id") == 0 )
						{  
							SingletonId sProp = (SingletonId)objHeadProp;
							newListBoxItem  = newListBoxItem + " | " + sProp.getValue();}
						if( objHeadProp.getPropertyId().compareToIgnoreCase("Creator")==0 )
						{  
							SingletonString sProp = (SingletonString)objHeadProp;
							newListBoxItem  = newListBoxItem + " | " + sProp.getValue();
							
						}
						if( objHeadProp.getPropertyId().compareToIgnoreCase("ContentSize")==0 )
						{  
							
							SingletonFloat64 sProp = (SingletonFloat64)objHeadProp;
							newListBoxItem  = newListBoxItem + " | " + sProp.getValue();
						}
						if( objHeadProp.getPropertyId().compareToIgnoreCase("DocumentTitle")==0 )
						{  
							SingletonString sProp = (SingletonString)objHeadProp;
							newListBoxItem  = newListBoxItem + " | " + sProp.getValue();
						}
					}
				}
			}
			returnListOfContainees[indexOf] = newListBoxItem; 
		
			
		}
		}else{
			returnListOfContainees = new String[1];
			returnListOfContainees[0] = "No Containees";
	}
		return returnListOfContainees;
	}
	

}
