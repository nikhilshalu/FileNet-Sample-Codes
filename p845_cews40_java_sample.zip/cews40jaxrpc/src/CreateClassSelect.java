/*
 * DISCLAIMER OF WARRANTIES
 * 
 * The accompanying code is sample code created by IBM Corporation. 
 * This sample code is not part of any standard or IBM product and 
 * is provided to you solely for the purpose of assisting you in the 
 * development of your applications. The code is provided "AS IS", 
 * without warranty of any kind. IBM shall not be liable for any 
 * damages arising out of your use of the sample code, even if they 
 * have been advised of the possibility of such damages.
 */
import com.filenet.www.ns.fnce._2006._11.ws.SOAP.wsdl.*;
import com.filenet.www.ns.fnce._2006._11.ws.schema.*;

public class CreateClassSelect {
	
	String messageDisplay = "";
	
	public CreateClassSelect(){
	}
	
	public void setMessageDisplay(String messageTxt){
		messageDisplay = messageTxt;
	}
	public String getMessageDisplay(){
		return messageDisplay;
	}
	
	public String[] querySubClass(Object fnStub,String userAccount, String userPassword, String library, String txtName, boolean chkIncludeSystem, boolean chkIncludeHidden){
		ObjectSetType objResponse = null;

		// Perform the requested query
		try
		{
		
			// Create a search object
			// Set up the scope for the query
			// Set up the SQL for the search
			RepositorySearch objSearch = new RepositorySearch();
			ObjectStoreScope objSearchScope = new ObjectStoreScope();
			objSearchScope.setObjectStore(library);
			objSearch.setSearchScope(objSearchScope);
			objSearch.setSearchSQL("SELECT SymbolicName, Id, IsHidden, IsSystemOwned, This FROM ClassDefinition ");
			objSearch.setSearchSQL(objSearch.getSearchSQL() + " WHERE AllowsSubclasses=TRUE");

			if( txtName.length() != 0 )
				objSearch.setSearchSQL(objSearch.getSearchSQL() + " AND SymbolicName LIKE '" + txtName + "%'");
			if( !chkIncludeSystem)
				objSearch.setSearchSQL(objSearch.getSearchSQL() + " AND IsSystemOwned=FALSE");
			if( !chkIncludeHidden)
				objSearch.setSearchSQL(objSearch.getSearchSQL() + " AND IsHidden=FALSE");

			// Execute the search

			if(fnStub instanceof FNCEWS40SoapBindingStub){
				FNCEWS40SoapBindingStub fnSoapStub = (FNCEWS40SoapBindingStub)fnStub;
				objResponse = fnSoapStub.executeSearch(objSearch);
			}else{
				throw new Error("Unable to locate a correct binding.");		
			}
		}
		catch(FaultStackType faultStackType){
			ErrorRecordType errorRecordType = faultStackType.getErrorRecord(0);
			throw new Error("A FaultStackType exception occurred while querying: \n [Description: " + errorRecordType.getDescription() + "]");
		}
		catch(Exception ex)
		{
			throw new Error("An exception occurred while querying: [" + ex.getMessage() + "]");
		}

		// Sanity check the results data
		long lColumnCount = 0;
		if( objResponse==null || objResponse.getObject() == null )
		{
			throw new Error("The query completed successfully but the results were null!");
			
		}
		if( objResponse.getObject().length < 1 )
		{
			throw new Error("No results were found for this query.");
			
		}
		lColumnCount = objResponse.getObject(0).getProperty().length;
		if( lColumnCount < 5 )
		{
			throw new Error("The query succeeded, but the results are missing requested data");
			
		}

		// Populate the rows
		ObjectValue[] g_Classes = objResponse.getObject();
		String[] returnClasses = new String[g_Classes.length];
		ObjectReference objRef;
		
		for(int index=0; index < g_Classes.length; index++){
			ObjectValue objClass = g_Classes[index];
			PropertyType[] pts = objClass.getProperty();
			for(int indexOfProp=0; indexOfProp < pts.length; indexOfProp++){
				PropertyType pt = pts[indexOfProp];
				
				if(pt.getPropertyId().compareToIgnoreCase("SymbolicName") ==0){
					SingletonString ss = (SingletonString)pt;	
					returnClasses[index] = ss.getValue();
				}
				if(pt.getPropertyId().compareToIgnoreCase("this") ==0){
					SingletonObject objSO = (SingletonObject)pt;
					objRef = (ObjectReference)((SingletonObject)pt).getValue();
					try
					{
						objRef = (ObjectReference)objSO.getValue();
						String strParentClassName = objRef.getClassId();
						String strParentClassId = objRef.getObjectId();
				        returnClasses[index] = returnClasses[index]  + " " +  strParentClassName + " " + strParentClassId;
					}
					catch (Exception e1)
					{
						//if used this needs added error handling
					}
				}
			}
		}
		setMessageDisplay("");
		return returnClasses;
	}
	public boolean createSubClass(Object fnStub,String userAccount, String userPassword, String library, String symbolicName, String parentClassName, String parentClassId){
		
		// Create a Create verb, populate it
		CreateAction createVerb = new CreateAction();
		createVerb.setClassId(parentClassName);

		ChangeRequestType objChange = new ChangeRequestType();
		objChange.setAction(new ActionType[1]);
		objChange.setTargetSpecification(new ObjectReference());
		objChange.getTargetSpecification().setClassId(parentClassName);
		objChange.getTargetSpecification().setObjectId(parentClassId);
		objChange.getTargetSpecification().setObjectStore(library);
		objChange.setId("1");

		// Build a list of properties to set in the new property template
		// The following meta-properties will be set:
		//   SymbolicName		String
		//   DisplayNames		ListOfObject
		ModifiablePropertyType[] objInputProps = new ModifiablePropertyType[2];

		// Symbolic name
		SingletonString objSymName = new SingletonString();
		objSymName.setValue(symbolicName);
		objSymName.setPropertyId("SymbolicName");
		objInputProps[0] = objSymName;

		// Set up the DisplayNames property
		//  DisplayNames is a dependent object that has the following properties:
		//    LocaleName		String
		//    LocalizedText		String
		ListOfObject objNameList = new ListOfObject();
		objNameList.setPropertyId("DisplayNames");
		DependentObjectType[] theNames = new DependentObjectType[1];
		DependentObjectType dispName = new DependentObjectType();
		theNames[0] = dispName;
		objNameList.setValue(theNames);

		dispName.setDependentAction(DependentAction.Insert);
		dispName.setClassId("LocalizedString");

		PropertyType[] nameProps = new PropertyType[2];
		SingletonString objLocale = new SingletonString();
		objLocale.setPropertyId("LocaleName");
		objLocale.setValue("en-us");
		nameProps[0] = objLocale;

		SingletonString objText = new SingletonString();
		objText.setPropertyId("LocalizedText");
		objText.setValue(symbolicName);
		nameProps[1] = objText;
		dispName.setProperty(nameProps);

		objInputProps[1] = objNameList;
		objChange.setActionProperties(objInputProps);
		objChange.setAction(0,(ActionType)createVerb);

		
		// Send off the request
		ChangeResponseType[] objResponseArray = null;
		ExecuteChangesRequest objRequest = new ExecuteChangesRequest();
		objRequest.setRefresh(new Boolean(true));
		objRequest.setChangeRequest(new ChangeRequestType[1]);
		objRequest.setChangeRequest(0,objChange);
		try
		{
			if(fnStub instanceof FNCEWS40SoapBindingStub){
				FNCEWS40SoapBindingStub fnSoapStub = (FNCEWS40SoapBindingStub)fnStub;
				objResponseArray = fnSoapStub.executeChanges(objRequest);
			}else{
				throw new Error("Unable to locate a correct binding.");		
			}
			
		}
		catch(FaultStackType faultStackType){
			ErrorRecordType errorRecordType = faultStackType.getErrorRecord(0);
			throw new Error("A FaultStackType exception occurred while creating a new class: \n [Description: " + errorRecordType.getDescription() + "]");
		}
		catch(Exception ex)
		{
			throw new Error("An exception occurred while creating a new class: [" + ex.getMessage() + "]");
			
		}

		// Created a class!  Sanity check the results
		String strObjectId = "";
		boolean bFound = false;

		if( objResponseArray==null || objResponseArray.length < 1 )
		{
			setMessageDisplay("The change request was executed, but a valid object was not returned");
			return true;
		}
		ChangeResponseType objResponse = objResponseArray[0];
		for(int indexOfProp = 0;indexOfProp < objResponse.getProperty().length;indexOfProp++){
			
		PropertyType objProp = objResponse.getProperty(indexOfProp);
			if (objProp.getPropertyId().compareToIgnoreCase("Id") == 0)
			{
				SingletonId ss = (SingletonId)objProp;
			
				strObjectId = ss.getValue();
				bFound = true;
				break;
			}
		}
		if( !bFound )
		{
			setMessageDisplay("The class was created, but the results do not contain an ID!");
			return true;
		}
		setMessageDisplay("Successfully created a new class!  ID = [" + strObjectId + "]");
		return true;
		
	}
}