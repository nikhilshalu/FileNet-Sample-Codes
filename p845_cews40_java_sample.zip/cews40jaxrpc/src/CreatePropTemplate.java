/*
 * DISCLAIMER OF WARRANTIES
 * 
 * The accompanying code is sample code created by IBM Corporation. 
 * This sample code is not part of any standard or IBM product and 
 * is provided to you solely for the purpose of assisting you in the 
 * development of your applications. The code is provided "AS IS", 
 * without warranty of any kind. IBM shall not be liable for any 
 * damages arising out of your use of the sample code, even if they 
 * have been advised of the possibility of such damages.
 */
import com.filenet.www.ns.fnce._2006._11.ws.SOAP.wsdl.*;
import com.filenet.www.ns.fnce._2006._11.ws.schema.*;

public class CreatePropTemplate {
	
	String messageDisplay = "";
	
	public CreatePropTemplate(){
	}
	
	public void setMessageDisplay(String messageTxt){
		messageDisplay = messageTxt;
	}
	public String getMessageDisplay(){
		return messageDisplay;
	}
	
	public boolean create(Object fnStub,String userAccount, String userPassword, String library, String symbolicName, String dataType){
		//	 We first need to create a Create verb, populate it
		CreateAction createVerb = new CreateAction();
	
		ChangeRequestType objChange = new ChangeRequestType();
		objChange.setAction(new ActionType[1]);
		objChange.setTargetSpecification(new ObjectReference());
		objChange.getTargetSpecification().setClassId("ObjectStore");
		objChange.getTargetSpecification().setObjectId(library);
		objChange.setId("1");
	
		// Build a list of properties to set in the new property template
		// The following meta-properties will be set:
		//   SymbolicName		String
		//   IsNameProperty		Boolean
		//   Cardinality		Integer
		//   IsPersistent		Boolean
		//   DisplayNames		ListOfObject
		ModifiablePropertyType[] objInputProps = new ModifiablePropertyType[4];
	
		// Symbolic name
		SingletonString objSymName = new SingletonString();
		objSymName.setValue(symbolicName);
		objSymName.setPropertyId("SymbolicName");
		objInputProps[0] = objSymName;
	
		// Hardcode the Cardinality for now
		SingletonInteger32 objCardinality = new SingletonInteger32();
		objCardinality.setValue(new Integer(0));
		objCardinality.setPropertyId("Cardinality");
		objInputProps[1] = objCardinality;
	
		// Hardcode the IsPersistent property for now
		SingletonBoolean objIsPersistent = new SingletonBoolean();
		objIsPersistent.setValue(new Boolean(true));
		objIsPersistent.setPropertyId("IsPersistent");
		objInputProps[2] = objIsPersistent;
	
		// Set up the DisplayNames property
		//  DisplayNames is a dependent object that has the following properties:
		//    LocaleName		String
		//    LocalizedText		String
		ListOfObject objNameList = new ListOfObject();
		objNameList.setPropertyId("DisplayNames");
		DependentObjectType[] theNames = new DependentObjectType[1];
		DependentObjectType dispName = new DependentObjectType();
		theNames[0] = dispName;
		objNameList.setValue(theNames);
	
		dispName.setDependentAction(DependentAction.Insert);
		dispName.setClassId("LocalizedString");
	
		PropertyType[] nameProps = new PropertyType[2];
		SingletonString objLocale = new SingletonString();
		objLocale.setPropertyId("LocaleName");
		objLocale.setValue("en-us");
		nameProps[0] = objLocale;
	
		SingletonString objText = new SingletonString();
		objText.setPropertyId("LocalizedText");
		objText.setValue(symbolicName);
		nameProps[1] = objText;
		dispName.setProperty(nameProps);
	
		objInputProps[3] = objNameList;
	
		// Set the class of the new template according to the data type
		
			if(dataType.compareToIgnoreCase("String") == 0){
				createVerb.setClassId("PropertyTemplateString");
			}else if(dataType.compareToIgnoreCase("Boolean") == 0){
				createVerb.setClassId("PropertyTemplateBoolean");
			}else if(dataType.compareToIgnoreCase("Float") == 0){
				createVerb.setClassId("PropertyTemplateFloat64");
			}else if(dataType.compareToIgnoreCase("Integer") == 0){
				createVerb.setClassId("PropertyTemplateInteger32");
			}else if(dataType.compareToIgnoreCase("ID") == 0){	
				createVerb.setClassId("PropertyTemplateId");
			}else if(dataType.compareToIgnoreCase("Object") == 0){				
				createVerb.setClassId("PropertyTemplateObject");
			}else if(dataType.compareToIgnoreCase("Binary") == 0){	
				createVerb.setClassId("PropertyTemplateBinary");
			}else if(dataType.compareToIgnoreCase("DateTime") == 0){
				createVerb.setClassId("PropertyTemplateDateTime");
			}else{
				setMessageDisplay("Invalid property type selected!");
				return false;
			}
		objChange.setActionProperties(objInputProps);
		objChange.setAction(0,(ActionType)createVerb);
	
			
		// Send off the request
		ChangeResponseType[] objResponseArray = null;
		ExecuteChangesRequest objRequest = new ExecuteChangesRequest();
		objRequest.setRefresh(new Boolean(true));
		objRequest.setChangeRequest(new ChangeRequestType[1]);
		objRequest.setChangeRequest(0,objChange);
		try
		{
			if(fnStub instanceof FNCEWS40SoapBindingStub){
				FNCEWS40SoapBindingStub fnSoapStub = (FNCEWS40SoapBindingStub)fnStub;
				objResponseArray = fnSoapStub.executeChanges(objRequest);
			}else{
				throw new Error("Unable to locate a correct binding.");		
			}
		}
		catch(FaultStackType faultStackType){
			ErrorRecordType errorRecordType = faultStackType.getErrorRecord(0);
			throw new Error("A FaultStackType exception occurred while creating a property template: \n [Description: " + errorRecordType.getDescription() + "]");
		}
		catch(Exception ex)
		{
			setMessageDisplay("An exception occurred while creating a property template: [" + ex.getMessage() + "]");
			return false;
		}
	
		// Created a template!  Sanity check the results
		String strObjectId = "";
		boolean bFound = false;
	
		if( objResponseArray==null || objResponseArray.length < 1 )
		{
			setMessageDisplay("The change request was executed, but a valid object was not returned");
			return false;
		}
		ChangeResponseType objResponse = objResponseArray[0];
		for(int indexOfProps = 0;indexOfProps < objResponse.getProperty().length;indexOfProps++)
			{
				PropertyType objProp = objResponse.getProperty(indexOfProps);
				if (objProp.getPropertyId().compareToIgnoreCase("Id") == 0)
				{
					SingletonId sId = (SingletonId)objProp;
					strObjectId = sId.getValue(); 
						
					bFound = true;
					break;
				}
			}
					if( !bFound )
		{
			setMessageDisplay("The property template was created, but the results do not contain an ID!");
			return false;
		}
		setMessageDisplay("Successfully created a property template!  ID = [" + strObjectId + "]");
		return true;
	}


}
