/*
 * DISCLAIMER OF WARRANTIES
 * 
 * The accompanying code is sample code created by IBM Corporation. 
 * This sample code is not part of any standard or IBM product and 
 * is provided to you solely for the purpose of assisting you in the 
 * development of your applications. The code is provided "AS IS", 
 * without warranty of any kind. IBM shall not be liable for any 
 * damages arising out of your use of the sample code, even if they 
 * have been advised of the possibility of such damages.
 */
package com.filenet.www.cews.util;
import java.util.Locale;
import java.util.TimeZone;


public class ServerConfig {
	
	
	private String username = null;
	private String password = null;
	private TimeZone timeZone = TimeZone.getDefault();
	private Locale locale = Locale.getDefault();
	private static ServerConfig instanceObj = new ServerConfig();
	private ServerConfig(){
		
	}
	
	public static ServerConfig getServerConfigInstance(){
		return instanceObj;
	}
	
	
	public void setUserName(String usrname)
	{
		username=usrname;
	}
	
	public String getUserName()
	{
		return username;
	}
	public void setPassword(String pwd)
	{
		password=pwd;
	}
	
	public String getPassword()
	{
		return password;
	}
	
	public Locale getLocale()
	{
		return locale;	
	}
	
	public TimeZone getTimeZone()
	{
		return timeZone;	
	}



}