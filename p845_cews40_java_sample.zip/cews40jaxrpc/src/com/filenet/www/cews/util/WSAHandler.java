/*
 * DISCLAIMER OF WARRANTIES
 * 
 * The accompanying code is sample code created by IBM Corporation. 
 * This sample code is not part of any standard or IBM product and 
 * is provided to you solely for the purpose of assisting you in the 
 * development of your applications. The code is provided "AS IS", 
 * without warranty of any kind. IBM shall not be liable for any 
 * damages arising out of your use of the sample code, even if they 
 * have been advised of the possibility of such damages.
 */
package com.filenet.www.cews.util;


import java.util.Locale;

import javax.xml.namespace.QName;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.GenericHandler;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import com.filenet.www.cews.util.ServerConfig;

public class WSAHandler extends GenericHandler {
	
	private static final QName AUTH_HEADER = new QName("http://schemas.xmlsoap.org/ws/2002/12/secext", "Security");
	private static final QName USERNAME_TOKEN = new QName("http://schemas.xmlsoap.org/ws/2002/12/secext", "UsernameToken");
	private static final QName USER_NAME   = new QName("http://schemas.xmlsoap.org/ws/2002/12/secext", "Username");
	private static final QName PASSWORD    = new QName("http://schemas.xmlsoap.org/ws/2002/12/secext", "Password");
	
	private static final QName LOCALE_HEADER = new QName("http://schemas.xmlsoap.org/ws/2002/12/secext", "Localization");
	private static final QName LOCALE = new QName("http://schemas.xmlsoap.org/ws/2002/12/secext", "Locale");

	/* (non-Javadoc)
	 * @see javax.xml.rpc.handler.Handler#getHeaders()
	 */
	public QName[] getHeaders() {
		return new QName[0];
	}
	public boolean handleRequest(MessageContext context) {
		try{	
			ServerConfig svrConf = ServerConfig.getServerConfigInstance();
			String userName=svrConf.getUserName();
			String password=svrConf.getPassword();
			String locale = "";
			String timeZone = "";
			
			//test if userName and password exist
			 if(userName == null || password == null) {
				 throw new JAXRPCException("username or password null");
			 }
			
			 Locale localeObj=svrConf.getLocale();
			 if(localeObj != null) {
				locale = localeObj.toString();
				//test if locale is not set
				 if(locale == null) {
					//Not required by the server at this time except for localization
					 locale = "en_US";
				 }
			}
			
			SOAPMessageContext messageContext = (SOAPMessageContext) context;
			
			SOAPFactory factory = SOAPFactory.newInstance();
			//SOAPConstants.SOAP_1_2_PROTOCOL
			// gets the SOAP header
			
			SOAPHeader header = messageContext.getMessage().getSOAPPart().getEnvelope().getHeader();

			// adds the authentication header
			Name name = factory.createName(AUTH_HEADER.getLocalPart(), null, AUTH_HEADER.getNamespaceURI());
			SOAPHeaderElement element = header.addHeaderElement(name);
			
			SOAPElement usernameTokenElement = element.addChildElement(USERNAME_TOKEN.getLocalPart(), "hd", USERNAME_TOKEN.getNamespaceURI());
			
			SOAPElement userNameElement = usernameTokenElement.addChildElement(USER_NAME.getLocalPart(), "hd", USER_NAME.getNamespaceURI());
			userNameElement.addTextNode(userName);
			SOAPElement passwordElement = usernameTokenElement.addChildElement(PASSWORD.getLocalPart(), "hd", PASSWORD.getNamespaceURI());
			passwordElement.addTextNode(password);
			
			
			// adds the Localization header
			Name nameLocale = factory.createName(LOCALE_HEADER.getLocalPart(), null, LOCALE_HEADER.getNamespaceURI());
			SOAPHeaderElement localizationElement = header.addHeaderElement(nameLocale);
			
			SOAPElement localeElement = localizationElement.addChildElement(LOCALE.getLocalPart(), "hd", LOCALE.getNamespaceURI());
			localeElement.addTextNode(locale);
		} catch (Exception e) {
						e.printStackTrace();
						throw new JAXRPCException(e);
		}

		return true;

	}

}
