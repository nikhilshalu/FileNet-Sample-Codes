/**
 * ErrorRecordType.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class ErrorRecordType  {
    private java.lang.String source;
    private java.lang.String description;
    private com.filenet.www.ns.fnce._2006._11.ws.schema.DiagnosticType[] diagnostic;

    public ErrorRecordType() {
    }

    public java.lang.String getSource() {
        return source;
    }

    public void setSource(java.lang.String source) {
        this.source = source;
    }

    public java.lang.String getDescription() {
        return description;
    }

    public void setDescription(java.lang.String description) {
        this.description = description;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.DiagnosticType[] getDiagnostic() {
        return diagnostic;
    }

    public void setDiagnostic(com.filenet.www.ns.fnce._2006._11.ws.schema.DiagnosticType[] diagnostic) {
        this.diagnostic = diagnostic;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.DiagnosticType getDiagnostic(int i) {
        return this.diagnostic[i];
    }

    public void setDiagnostic(int i, com.filenet.www.ns.fnce._2006._11.ws.schema.DiagnosticType value) {
        this.diagnostic[i] = value;
    }

}
