/**
 * ListOfInteger32.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class ListOfInteger32  extends com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType  {
    private int[] value;

    public ListOfInteger32() {
    }

    public int[] getValue() {
        return value;
    }

    public void setValue(int[] value) {
        this.value = value;
    }

    public int getValue(int i) {
        return this.value[i];
    }

    public void setValue(int i, int value) {
        this.value[i] = value;
    }

}
