/**
 * LifecycleAction.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class LifecycleAction  {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected LifecycleAction(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    };

    public static final java.lang.String _Reset = "Reset";
    public static final java.lang.String _Promote = "Promote";
    public static final java.lang.String _Demote = "Demote";
    public static final java.lang.String _SetException = "SetException";
    public static final java.lang.String _ClearException = "ClearException";
    public static final LifecycleAction Reset = new LifecycleAction(_Reset);
    public static final LifecycleAction Promote = new LifecycleAction(_Promote);
    public static final LifecycleAction Demote = new LifecycleAction(_Demote);
    public static final LifecycleAction SetException = new LifecycleAction(_SetException);
    public static final LifecycleAction ClearException = new LifecycleAction(_ClearException);
    public java.lang.String getValue() { return _value_;}
    public static LifecycleAction fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        LifecycleAction enumeration = (LifecycleAction)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static LifecycleAction fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}

}
