/**
 * Localization.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class Localization  {
    private java.lang.String locale;
    private java.lang.String timezone;

    public Localization() {
    }

    public java.lang.String getLocale() {
        return locale;
    }

    public void setLocale(java.lang.String locale) {
        this.locale = locale;
    }

    public java.lang.String getTimezone() {
        return timezone;
    }

    public void setTimezone(java.lang.String timezone) {
        this.timezone = timezone;
    }

}
