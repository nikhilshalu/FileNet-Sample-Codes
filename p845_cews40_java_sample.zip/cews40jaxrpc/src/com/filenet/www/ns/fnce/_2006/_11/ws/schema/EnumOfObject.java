/**
 * EnumOfObject.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class EnumOfObject  extends com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyType  {
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectValue[] value;
    private com.filenet.www.ns.fnce._2006._11.ws.schema.CollectionTerminatorType collectionTerminator;
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference parentReference;

    public EnumOfObject() {
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectValue[] getValue() {
        return value;
    }

    public void setValue(com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectValue[] value) {
        this.value = value;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectValue getValue(int i) {
        return this.value[i];
    }

    public void setValue(int i, com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectValue value) {
        this.value[i] = value;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.CollectionTerminatorType getCollectionTerminator() {
        return collectionTerminator;
    }

    public void setCollectionTerminator(com.filenet.www.ns.fnce._2006._11.ws.schema.CollectionTerminatorType collectionTerminator) {
        this.collectionTerminator = collectionTerminator;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference getParentReference() {
        return parentReference;
    }

    public void setParentReference(com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference parentReference) {
        this.parentReference = parentReference;
    }

}
