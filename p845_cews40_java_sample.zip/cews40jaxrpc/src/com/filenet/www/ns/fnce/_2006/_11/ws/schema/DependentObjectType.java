/**
 * DependentObjectType.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class DependentObjectType  extends com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectValue  {
    private int originalIndex;  // attribute
    private int newIndex;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.DependentAction dependentAction;  // attribute

    public DependentObjectType() {
    }

    public int getOriginalIndex() {
        return originalIndex;
    }

    public void setOriginalIndex(int originalIndex) {
        this.originalIndex = originalIndex;
    }

    public int getNewIndex() {
        return newIndex;
    }

    public void setNewIndex(int newIndex) {
        this.newIndex = newIndex;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.DependentAction getDependentAction() {
        return dependentAction;
    }

    public void setDependentAction(com.filenet.www.ns.fnce._2006._11.ws.schema.DependentAction dependentAction) {
        this.dependentAction = dependentAction;
    }

}
