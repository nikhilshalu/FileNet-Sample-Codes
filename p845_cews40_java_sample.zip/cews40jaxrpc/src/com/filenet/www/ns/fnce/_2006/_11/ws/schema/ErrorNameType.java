/**
 * ErrorNameType.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class ErrorNameType  {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected ErrorNameType(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    };

    public static final java.lang.String _SERVER_ERROR = "SERVER_ERROR";
    public static final java.lang.String _HEAP_FAILURE = "HEAP_FAILURE";
    public static final java.lang.String _DEADLOCK_ERROR = "DEADLOCK_ERROR";
    public static final java.lang.String _DATABASE_ERROR = "DATABASE_ERROR";
    public static final java.lang.String _DATABASE_FULL = "DATABASE_FULL";
    public static final java.lang.String _TRANSACTION_TIMEOUT = "TRANSACTION_TIMEOUT";
    public static final java.lang.String _AUTHENTICATION_FAILURE = "AUTHENTICATION_FAILURE";
    public static final java.lang.String _NOT_SUPPORTED = "NOT_SUPPORTED";
    public static final java.lang.String _BAD_CLASSID = "BAD_CLASSID";
    public static final java.lang.String _BAD_PROPERTYID = "BAD_PROPERTYID";
    public static final java.lang.String _BAD_INDEX = "BAD_INDEX";
    public static final java.lang.String _BAD_OBJECT = "BAD_OBJECT";
    public static final java.lang.String _INVALID_REQUEST = "INVALID_REQUEST";
    public static final java.lang.String _REQUIRED_VALUE_ABSENT = "REQUIRED_VALUE_ABSENT";
    public static final java.lang.String _OBJECT_NOT_FOUND = "OBJECT_NOT_FOUND";
    public static final java.lang.String _OBJECT_DELETED = "OBJECT_DELETED";
    public static final java.lang.String _BAD_VALUE = "BAD_VALUE";
    public static final java.lang.String _DATATYPE_MISMATCH = "DATATYPE_MISMATCH";
    public static final java.lang.String _ACCESS_DENIED = "ACCESS_DENIED";
    public static final java.lang.String _CONSTRAINT_VIOLATED = "CONSTRAINT_VIOLATED";
    public static final java.lang.String _NOT_UNIQUE = "NOT_UNIQUE";
    public static final java.lang.String _OBJECT_MODIFIED = "OBJECT_MODIFIED";
    public static final java.lang.String _OBJECT_REFERENCED = "OBJECT_REFERENCED";
    public static final java.lang.String _OBJECT_REFERENCES_OTHERS = "OBJECT_REFERENCES_OTHERS";
    public static final java.lang.String _OBJECT_LOCKED = "OBJECT_LOCKED";
    public static final java.lang.String _OBJECT_NOT_LOCKED = "OBJECT_NOT_LOCKED";
    public static final java.lang.String _RESERVATION_EXISTS = "RESERVATION_EXISTS";
    public static final ErrorNameType SERVER_ERROR = new ErrorNameType(_SERVER_ERROR);
    public static final ErrorNameType HEAP_FAILURE = new ErrorNameType(_HEAP_FAILURE);
    public static final ErrorNameType DEADLOCK_ERROR = new ErrorNameType(_DEADLOCK_ERROR);
    public static final ErrorNameType DATABASE_ERROR = new ErrorNameType(_DATABASE_ERROR);
    public static final ErrorNameType DATABASE_FULL = new ErrorNameType(_DATABASE_FULL);
    public static final ErrorNameType TRANSACTION_TIMEOUT = new ErrorNameType(_TRANSACTION_TIMEOUT);
    public static final ErrorNameType AUTHENTICATION_FAILURE = new ErrorNameType(_AUTHENTICATION_FAILURE);
    public static final ErrorNameType NOT_SUPPORTED = new ErrorNameType(_NOT_SUPPORTED);
    public static final ErrorNameType BAD_CLASSID = new ErrorNameType(_BAD_CLASSID);
    public static final ErrorNameType BAD_PROPERTYID = new ErrorNameType(_BAD_PROPERTYID);
    public static final ErrorNameType BAD_INDEX = new ErrorNameType(_BAD_INDEX);
    public static final ErrorNameType BAD_OBJECT = new ErrorNameType(_BAD_OBJECT);
    public static final ErrorNameType INVALID_REQUEST = new ErrorNameType(_INVALID_REQUEST);
    public static final ErrorNameType REQUIRED_VALUE_ABSENT = new ErrorNameType(_REQUIRED_VALUE_ABSENT);
    public static final ErrorNameType OBJECT_NOT_FOUND = new ErrorNameType(_OBJECT_NOT_FOUND);
    public static final ErrorNameType OBJECT_DELETED = new ErrorNameType(_OBJECT_DELETED);
    public static final ErrorNameType BAD_VALUE = new ErrorNameType(_BAD_VALUE);
    public static final ErrorNameType DATATYPE_MISMATCH = new ErrorNameType(_DATATYPE_MISMATCH);
    public static final ErrorNameType ACCESS_DENIED = new ErrorNameType(_ACCESS_DENIED);
    public static final ErrorNameType CONSTRAINT_VIOLATED = new ErrorNameType(_CONSTRAINT_VIOLATED);
    public static final ErrorNameType NOT_UNIQUE = new ErrorNameType(_NOT_UNIQUE);
    public static final ErrorNameType OBJECT_MODIFIED = new ErrorNameType(_OBJECT_MODIFIED);
    public static final ErrorNameType OBJECT_REFERENCED = new ErrorNameType(_OBJECT_REFERENCED);
    public static final ErrorNameType OBJECT_REFERENCES_OTHERS = new ErrorNameType(_OBJECT_REFERENCES_OTHERS);
    public static final ErrorNameType OBJECT_LOCKED = new ErrorNameType(_OBJECT_LOCKED);
    public static final ErrorNameType OBJECT_NOT_LOCKED = new ErrorNameType(_OBJECT_NOT_LOCKED);
    public static final ErrorNameType RESERVATION_EXISTS = new ErrorNameType(_RESERVATION_EXISTS);
    public java.lang.String getValue() { return _value_;}
    public static ErrorNameType fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        ErrorNameType enumeration = (ErrorNameType)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static ErrorNameType fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}

}
