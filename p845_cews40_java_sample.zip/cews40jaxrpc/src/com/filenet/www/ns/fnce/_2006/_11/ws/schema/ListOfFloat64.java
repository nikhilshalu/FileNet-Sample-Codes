/**
 * ListOfFloat64.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class ListOfFloat64  extends com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType  {
    private double[] value;

    public ListOfFloat64() {
    }

    public double[] getValue() {
        return value;
    }

    public void setValue(double[] value) {
        this.value = value;
    }

    public double getValue(int i) {
        return this.value[i];
    }

    public void setValue(int i, double value) {
        this.value[i] = value;
    }

}
