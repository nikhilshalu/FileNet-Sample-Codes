/**
 * CheckoutAction.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class CheckoutAction  extends com.filenet.www.ns.fnce._2006._11.ws.schema.ActionType  {
    private java.lang.String reservationId;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ReservationType reservationType;  // attribute
    private java.lang.String reservationClass;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType[] reservationProperties;

    public CheckoutAction() {
    }

    public java.lang.String getReservationId() {
        return reservationId;
    }

    public void setReservationId(java.lang.String reservationId) {
        this.reservationId = reservationId;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ReservationType getReservationType() {
        return reservationType;
    }

    public void setReservationType(com.filenet.www.ns.fnce._2006._11.ws.schema.ReservationType reservationType) {
        this.reservationType = reservationType;
    }

    public java.lang.String getReservationClass() {
        return reservationClass;
    }

    public void setReservationClass(java.lang.String reservationClass) {
        this.reservationClass = reservationClass;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType[] getReservationProperties() {
        return reservationProperties;
    }

    public void setReservationProperties(com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType[] reservationProperties) {
        this.reservationProperties = reservationProperties;
    }

}
