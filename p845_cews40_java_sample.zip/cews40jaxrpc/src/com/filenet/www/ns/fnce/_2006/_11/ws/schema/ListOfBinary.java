/**
 * ListOfBinary.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class ListOfBinary  extends com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType  {
    private byte[][] value;

    public ListOfBinary() {
    }

    public byte[][] getValue() {
        return value;
    }

    public void setValue(byte[][] value) {
        this.value = value;
    }

    public byte[] getValue(int i) {
        return this.value[i];
    }

    public void setValue(int i, byte[] value) {
        this.value[i] = value;
    }

}
