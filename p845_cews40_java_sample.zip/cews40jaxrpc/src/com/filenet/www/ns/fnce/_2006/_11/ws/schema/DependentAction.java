/**
 * DependentAction.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class DependentAction  {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected DependentAction(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    };

    public static final java.lang.String _Update = "Update";
    public static final java.lang.String _Move = "Move";
    public static final java.lang.String _Insert = "Insert";
    public static final java.lang.String _Delete = "Delete";
    public static final DependentAction Update = new DependentAction(_Update);
    public static final DependentAction Move = new DependentAction(_Move);
    public static final DependentAction Insert = new DependentAction(_Insert);
    public static final DependentAction Delete = new DependentAction(_Delete);
    public java.lang.String getValue() { return _value_;}
    public static DependentAction fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        DependentAction enumeration = (DependentAction)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static DependentAction fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}

}
