/**
 * FNCEWS40SoapBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.SOAP.wsdl;

public class FNCEWS40SoapBindingStub extends com.ibm.ws.webservices.engine.client.Stub implements com.filenet.www.ns.fnce._2006._11.ws.wsdl.FNCEWS40PortType {
    public FNCEWS40SoapBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws com.ibm.ws.webservices.engine.WebServicesFault {
        if (service == null) {
            super.service = new com.ibm.ws.webservices.engine.client.Service();
        }
        else {
            super.service = service;
        }
        super.engine = ((com.ibm.ws.webservices.engine.client.Service) super.service).getEngine();
        initTypeMapping();
        super.cachedEndpoint = endpointURL;
        super.connection = ((com.ibm.ws.webservices.engine.client.Service) super.service).getConnection(endpointURL);
        super.messageContexts = new com.ibm.ws.webservices.engine.MessageContext[5];
    }

    private void initTypeMapping() {
        javax.xml.rpc.encoding.TypeMapping tm = super.getTypeMapping(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
        java.lang.Class javaType = null;
        javax.xml.namespace.QName xmlType = null;
        javax.xml.namespace.QName compQName = null;
        javax.xml.namespace.QName compTypeQName = null;
        com.ibm.ws.webservices.engine.encoding.SerializerFactory sf = null;
        com.ibm.ws.webservices.engine.encoding.DeserializerFactory df = null;
        javaType = java.lang.String.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "GuidType");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.SimpleSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "PropertyType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.CollectionType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "CollectionType");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.StringEncodingType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "StringEncodingType");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.UnevaluatedCollection.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "UnevaluatedCollection");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectReference");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ModifiablePropertyType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.SingletonBoolean.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SingletonBoolean");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.SingletonBinary.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SingletonBinary");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.SingletonDateTime.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SingletonDateTime");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.SingletonFloat64.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SingletonFloat64");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.SingletonId.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SingletonId");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.SingletonInteger32.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SingletonInteger32");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.SingletonObject.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SingletonObject");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectEntryType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectEntryType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.SingletonString.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SingletonString");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ListOfBoolean.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ListOfBoolean");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ListOfBinary.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ListOfBinary");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ListOfDateTime.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ListOfDateTime");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ListOfFloat64.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ListOfFloat64");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ListOfId.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ListOfId");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ListOfInteger32.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ListOfInteger32");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ListOfObject.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ListOfObject");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.DependentObjectType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "DependentObjectType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ListMode.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">ListOfObject>listMode");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ListOfString.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ListOfString");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.EnumOfObject.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "EnumOfObject");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectValue.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectValue");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.CollectionTerminatorType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "CollectionTerminatorType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ContentData.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ContentData");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ContentType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ContentType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.WithObjectIdentityType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "WithObjectIdentityType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = java.lang.String[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">ObjectValue>superClasses");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ListSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ListDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.RetrievalError.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "RetrievalError");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ErrorStackType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ErrorStackType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.Unevaluated.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "Unevaluated");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectSpecification.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectSpecification");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.DependentAction.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">DependentObjectType>dependentAction");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectSetType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectSetType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.EndOfCollection.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "EndOfCollection");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.EndOfPage.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "EndOfPage");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.TraversalError.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "TraversalError");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.InlineContent.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "InlineContent");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.FilterElementType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FilterElementType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.SimpleBeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.SimpleBeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyFilterType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "PropertyFilterType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ModifiedPropertiesType");
        compQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "Property");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ModifiablePropertyType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArraySerializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArrayDeserializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ActionType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ActionType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ReservationType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ReservationType");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.CreateAction.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "CreateAction");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.UpdateAction.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "UpdateAction");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.DeleteAction.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "DeleteAction");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.CheckoutAction.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "CheckoutAction");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.CheckinAction.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "CheckinAction");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.FreezeAction.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FreezeAction");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeStateAction.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ChangeStateAction");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.LifecycleAction.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">ChangeStateAction>lifecycleAction");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeClassAction.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ChangeClassAction");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.MoveContentAction.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "MoveContentAction");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.LockAction.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "LockAction");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.UnlockAction.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "UnlockAction");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.PromoteVersionAction.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "PromoteVersionAction");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.DemoteVersionAction.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "DemoteVersionAction");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ApplySecurityTemplateAction.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ApplySecurityTemplateAction");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.RaiseEventAction.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "RaiseEventAction");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.InstallAddOnAction.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "InstallAddOnAction");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.TakeFederatedOwnershipAction.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "TakeFederatedOwnershipAction");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.Localization.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">Localization");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ErrorNameType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ErrorNameType");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.DiagnosticType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "DiagnosticType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.SimpleBeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.SimpleBeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ErrorRecordType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ErrorRecordType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.SearchScopeType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SearchScopeType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectStoreScope.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectStoreScope");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.MergedScope.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "MergedScope");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.MergeMode.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">MergedScope>mergeMode");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.RepositorySearchModeType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "RepositorySearchModeType");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.SearchRequestType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SearchRequestType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.RepositorySearch.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "RepositorySearch");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.PrincipalSearch.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "PrincipalSearch");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.PrincipalSearchType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">PrincipalSearch>principalSearchType");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.PrincipalSearchAttribute.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">PrincipalSearch>principalSearchAttribute");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.PrincipalSort.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">PrincipalSearch>principalSort");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumSerializerFactory.class, javaType, xmlType, null, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.EnumDeserializerFactory.class, javaType, xmlType, null, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.StoredSearch.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "StoredSearch");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ExecuteXML.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">StoredSearch>ExecuteXML");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectRequestType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectRequestType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectRequestType[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetObjectsRequest");
        compQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectRequest");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectRequestType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArraySerializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArrayDeserializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectResponseType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectResponseType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.SingleObjectResponse.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SingleObjectResponse");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectSetResponse.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectSetResponse");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ErrorStackResponse.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ErrorStackResponse");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectResponseType[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetObjectsResponse");
        compQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectResponse");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectResponseType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArraySerializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArrayDeserializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeRequestType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ChangeRequestType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ExecuteChangesRequest.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">ExecuteChangesRequest");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeResponseType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ChangeResponseType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeResponseType[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">ExecuteChangesResponse");
        compQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ChangeResponse");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ChangeResponseType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArraySerializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArrayDeserializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.GetSearchMetadataRequest.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetSearchMetadataRequest");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.GetSearchMetadataResponse.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetSearchMetadataResponse");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ElementSpecificationType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ElementSpecificationType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ContentRequestType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ContentRequestType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ContentResponseType.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ContentResponseType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ContentElementResponse.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ContentElementResponse");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ContentErrorResponse.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ContentErrorResponse");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.GetContentRequest.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetContentRequest");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

        javaType = com.filenet.www.ns.fnce._2006._11.ws.schema.ContentResponseType[].class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetContentResponse");
        compQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ContentResponse");
        compTypeQName = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ContentResponseType");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArraySerializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.ArrayDeserializerFactory.class, javaType, xmlType, compQName, compTypeQName);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _getObjectsOperation0 = null;
    private static com.ibm.ws.webservices.engine.description.OperationDesc _getgetObjectsOperation0() {
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "GetObjectsRequest"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetObjectsRequest"), com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectRequestType[].class, false, false, false, false, true, false), 
          };
        _params0[0].setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}GetObjectsRequest");
        _params0[0].setOption("partName","GetObjectsRequest");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "GetObjectsResponse"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetObjectsResponse"), com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectResponseType[].class, true, false, false, false, true, false); 
        _returnDesc0.setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}GetObjectsResponse");
        _returnDesc0.setOption("partName","GetObjectsResponse");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
         new com.ibm.ws.webservices.engine.description.FaultDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FaultResponse"), "com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ErrorStack"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType")), 
          };
        _getObjectsOperation0 = new com.ibm.ws.webservices.engine.description.OperationDesc("getObjects", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "GetObjects"), _params0, _returnDesc0, _faults0, "http://www.filenet.com/ns/fnce/2006/11/ws/SOAP#GetObjects");
        _getObjectsOperation0.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FNCEWS40PortType"));
        _getObjectsOperation0.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "GetObjectsResponse"));
        _getObjectsOperation0.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl", "FNCEWS40Service"));
        _getObjectsOperation0.setOption("buildNum","q0834.18");
        _getObjectsOperation0.setOption("targetNamespace","http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl");
        _getObjectsOperation0.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "GetObjectsRequest"));
        _getObjectsOperation0.setUse(com.ibm.ws.webservices.engine.enumtype.Use.LITERAL);
        _getObjectsOperation0.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.DOCUMENT);
        return _getObjectsOperation0;

    }

    private int _getObjectsIndex0 = 0;
    private synchronized com.ibm.ws.webservices.engine.client.Stub.Invoke _getgetObjectsInvoke0(Object[] parameters) throws com.ibm.ws.webservices.engine.WebServicesFault  {
        com.ibm.ws.webservices.engine.MessageContext mc = super.messageContexts[_getObjectsIndex0];
        if (mc == null) {
            mc = new com.ibm.ws.webservices.engine.MessageContext(super.engine);
            mc.setOperation(FNCEWS40SoapBindingStub._getObjectsOperation0);
            mc.setUseSOAPAction(true);
            mc.setSOAPActionURI("http://www.filenet.com/ns/fnce/2006/11/ws/SOAP#GetObjects");
            mc.setEncodingStyle(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.SEND_TYPE_ATTR_PROPERTY, Boolean.FALSE);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.ENGINE_DO_MULTI_REFS_PROPERTY, Boolean.FALSE);
            super.primeMessageContext(mc);
            super.messageContexts[_getObjectsIndex0] = mc;
        }
        try {
            mc = (com.ibm.ws.webservices.engine.MessageContext) mc.clone();
        }
        catch (CloneNotSupportedException cnse) {
            throw com.ibm.ws.webservices.engine.WebServicesFault.makeFault(cnse);
        }
        return new com.ibm.ws.webservices.engine.client.Stub.Invoke(connection, mc, parameters);
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectResponseType[] getObjects(com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectRequestType[] request) throws java.rmi.RemoteException, com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType {
        if (super.cachedEndpoint == null) {
            throw new com.ibm.ws.webservices.engine.NoEndPointException();
        }
        java.util.Vector _resp = null;
        try {
            _resp = _getgetObjectsInvoke0(new java.lang.Object[] {request}).invoke();

        } catch (com.ibm.ws.webservices.engine.WebServicesFault wsf) {
            Exception e = wsf.getUserException();
            if (e != null) {
                if (e instanceof com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType) {
                    throw (com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType) e;
                }
            }
            throw wsf;
        } 
        try {
            return (com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectResponseType[]) ((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue();
        } catch (java.lang.Exception _exception) {
            return (com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectResponseType[]) super.convert(((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue(), com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectResponseType[].class);
        }
    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _executeChangesOperation1 = null;
    private static com.ibm.ws.webservices.engine.description.OperationDesc _getexecuteChangesOperation1() {
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params1 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ExecuteChangesRequest"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">ExecuteChangesRequest"), com.filenet.www.ns.fnce._2006._11.ws.schema.ExecuteChangesRequest.class, false, false, false, false, true, false), 
          };
        _params1[0].setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}ExecuteChangesRequest");
        _params1[0].setOption("partName","ExecuteChangesRequest");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc1 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ExecuteChangesResponse"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">ExecuteChangesResponse"), com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeResponseType[].class, true, false, false, false, true, false); 
        _returnDesc1.setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}ExecuteChangesResponse");
        _returnDesc1.setOption("partName","ExecuteChangesResponse");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults1 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
         new com.ibm.ws.webservices.engine.description.FaultDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FaultResponse"), "com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ErrorStack"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType")), 
          };
        _executeChangesOperation1 = new com.ibm.ws.webservices.engine.description.OperationDesc("executeChanges", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "ExecuteChanges"), _params1, _returnDesc1, _faults1, "http://www.filenet.com/ns/fnce/2006/11/ws/SOAP#ExecuteChanges");
        _executeChangesOperation1.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FNCEWS40PortType"));
        _executeChangesOperation1.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "ExecuteChangesResponse"));
        _executeChangesOperation1.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl", "FNCEWS40Service"));
        _executeChangesOperation1.setOption("buildNum","q0834.18");
        _executeChangesOperation1.setOption("targetNamespace","http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl");
        _executeChangesOperation1.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "ExecuteChangesRequest"));
        _executeChangesOperation1.setUse(com.ibm.ws.webservices.engine.enumtype.Use.LITERAL);
        _executeChangesOperation1.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.DOCUMENT);
        return _executeChangesOperation1;

    }

    private int _executeChangesIndex1 = 1;
    private synchronized com.ibm.ws.webservices.engine.client.Stub.Invoke _getexecuteChangesInvoke1(Object[] parameters) throws com.ibm.ws.webservices.engine.WebServicesFault  {
        com.ibm.ws.webservices.engine.MessageContext mc = super.messageContexts[_executeChangesIndex1];
        if (mc == null) {
            mc = new com.ibm.ws.webservices.engine.MessageContext(super.engine);
            mc.setOperation(FNCEWS40SoapBindingStub._executeChangesOperation1);
            mc.setUseSOAPAction(true);
            mc.setSOAPActionURI("http://www.filenet.com/ns/fnce/2006/11/ws/SOAP#ExecuteChanges");
            mc.setEncodingStyle(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.SEND_TYPE_ATTR_PROPERTY, Boolean.FALSE);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.ENGINE_DO_MULTI_REFS_PROPERTY, Boolean.FALSE);
            super.primeMessageContext(mc);
            super.messageContexts[_executeChangesIndex1] = mc;
        }
        try {
            mc = (com.ibm.ws.webservices.engine.MessageContext) mc.clone();
        }
        catch (CloneNotSupportedException cnse) {
            throw com.ibm.ws.webservices.engine.WebServicesFault.makeFault(cnse);
        }
        return new com.ibm.ws.webservices.engine.client.Stub.Invoke(connection, mc, parameters);
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeResponseType[] executeChanges(com.filenet.www.ns.fnce._2006._11.ws.schema.ExecuteChangesRequest request) throws java.rmi.RemoteException, com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType {
        if (super.cachedEndpoint == null) {
            throw new com.ibm.ws.webservices.engine.NoEndPointException();
        }
        java.util.Vector _resp = null;
        try {
            _resp = _getexecuteChangesInvoke1(new java.lang.Object[] {request}).invoke();

        } catch (com.ibm.ws.webservices.engine.WebServicesFault wsf) {
            Exception e = wsf.getUserException();
            if (e != null) {
                if (e instanceof com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType) {
                    throw (com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType) e;
                }
            }
            throw wsf;
        } 
        try {
            return (com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeResponseType[]) ((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue();
        } catch (java.lang.Exception _exception) {
            return (com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeResponseType[]) super.convert(((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue(), com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeResponseType[].class);
        }
    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _executeSearchOperation2 = null;
    private static com.ibm.ws.webservices.engine.description.OperationDesc _getexecuteSearchOperation2() {
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params2 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ExecuteSearchRequest"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SearchRequestType"), com.filenet.www.ns.fnce._2006._11.ws.schema.SearchRequestType.class, false, false, false, false, true, false), 
          };
        _params2[0].setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}ExecuteSearchRequest");
        _params2[0].setOption("partName","ExecuteSearchRequest");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc2 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ExecuteSearchResponse"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectSetType"), com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectSetType.class, true, false, false, false, true, false); 
        _returnDesc2.setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}ExecuteSearchResponse");
        _returnDesc2.setOption("partName","ExecuteSearchResponse");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults2 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
         new com.ibm.ws.webservices.engine.description.FaultDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FaultResponse"), "com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ErrorStack"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType")), 
          };
        _executeSearchOperation2 = new com.ibm.ws.webservices.engine.description.OperationDesc("executeSearch", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "ExecuteSearch"), _params2, _returnDesc2, _faults2, "http://www.filenet.com/ns/fnce/2006/11/ws/SOAP#ExecuteSearch");
        _executeSearchOperation2.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FNCEWS40PortType"));
        _executeSearchOperation2.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "ExecuteSearchResponse"));
        _executeSearchOperation2.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl", "FNCEWS40Service"));
        _executeSearchOperation2.setOption("buildNum","q0834.18");
        _executeSearchOperation2.setOption("targetNamespace","http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl");
        _executeSearchOperation2.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "ExecuteSearchRequest"));
        _executeSearchOperation2.setUse(com.ibm.ws.webservices.engine.enumtype.Use.LITERAL);
        _executeSearchOperation2.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.DOCUMENT);
        return _executeSearchOperation2;

    }

    private int _executeSearchIndex2 = 2;
    private synchronized com.ibm.ws.webservices.engine.client.Stub.Invoke _getexecuteSearchInvoke2(Object[] parameters) throws com.ibm.ws.webservices.engine.WebServicesFault  {
        com.ibm.ws.webservices.engine.MessageContext mc = super.messageContexts[_executeSearchIndex2];
        if (mc == null) {
            mc = new com.ibm.ws.webservices.engine.MessageContext(super.engine);
            mc.setOperation(FNCEWS40SoapBindingStub._executeSearchOperation2);
            mc.setUseSOAPAction(true);
            mc.setSOAPActionURI("http://www.filenet.com/ns/fnce/2006/11/ws/SOAP#ExecuteSearch");
            mc.setEncodingStyle(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.SEND_TYPE_ATTR_PROPERTY, Boolean.FALSE);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.ENGINE_DO_MULTI_REFS_PROPERTY, Boolean.FALSE);
            super.primeMessageContext(mc);
            super.messageContexts[_executeSearchIndex2] = mc;
        }
        try {
            mc = (com.ibm.ws.webservices.engine.MessageContext) mc.clone();
        }
        catch (CloneNotSupportedException cnse) {
            throw com.ibm.ws.webservices.engine.WebServicesFault.makeFault(cnse);
        }
        return new com.ibm.ws.webservices.engine.client.Stub.Invoke(connection, mc, parameters);
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectSetType executeSearch(com.filenet.www.ns.fnce._2006._11.ws.schema.SearchRequestType request) throws java.rmi.RemoteException, com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType {
        if (super.cachedEndpoint == null) {
            throw new com.ibm.ws.webservices.engine.NoEndPointException();
        }
        java.util.Vector _resp = null;
        try {
            _resp = _getexecuteSearchInvoke2(new java.lang.Object[] {request}).invoke();

        } catch (com.ibm.ws.webservices.engine.WebServicesFault wsf) {
            Exception e = wsf.getUserException();
            if (e != null) {
                if (e instanceof com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType) {
                    throw (com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType) e;
                }
            }
            throw wsf;
        } 
        try {
            return (com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectSetType) ((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue();
        } catch (java.lang.Exception _exception) {
            return (com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectSetType) super.convert(((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue(), com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectSetType.class);
        }
    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _getSearchMetadataOperation3 = null;
    private static com.ibm.ws.webservices.engine.description.OperationDesc _getgetSearchMetadataOperation3() {
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params3 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "GetSearchMetadataRequest"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetSearchMetadataRequest"), com.filenet.www.ns.fnce._2006._11.ws.schema.GetSearchMetadataRequest.class, false, false, false, false, true, false), 
          };
        _params3[0].setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}GetSearchMetadataRequest");
        _params3[0].setOption("partName","GetSearchMetadataRequest");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc3 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "GetSearchMetadataResponse"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetSearchMetadataResponse"), com.filenet.www.ns.fnce._2006._11.ws.schema.GetSearchMetadataResponse.class, true, false, false, false, true, false); 
        _returnDesc3.setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}GetSearchMetadataResponse");
        _returnDesc3.setOption("partName","GetSearchMetadataResponse");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults3 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
         new com.ibm.ws.webservices.engine.description.FaultDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FaultResponse"), "com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ErrorStack"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType")), 
          };
        _getSearchMetadataOperation3 = new com.ibm.ws.webservices.engine.description.OperationDesc("getSearchMetadata", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "GetSearchMetadata"), _params3, _returnDesc3, _faults3, "http://www.filenet.com/ns/fnce/2006/11/ws/SOAP#GetSearchMetadata");
        _getSearchMetadataOperation3.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FNCEWS40PortType"));
        _getSearchMetadataOperation3.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "GetSearchMetadataResponse"));
        _getSearchMetadataOperation3.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl", "FNCEWS40Service"));
        _getSearchMetadataOperation3.setOption("buildNum","q0834.18");
        _getSearchMetadataOperation3.setOption("targetNamespace","http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl");
        _getSearchMetadataOperation3.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "GetSearchMetadataRequest"));
        _getSearchMetadataOperation3.setUse(com.ibm.ws.webservices.engine.enumtype.Use.LITERAL);
        _getSearchMetadataOperation3.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.DOCUMENT);
        return _getSearchMetadataOperation3;

    }

    private int _getSearchMetadataIndex3 = 3;
    private synchronized com.ibm.ws.webservices.engine.client.Stub.Invoke _getgetSearchMetadataInvoke3(Object[] parameters) throws com.ibm.ws.webservices.engine.WebServicesFault  {
        com.ibm.ws.webservices.engine.MessageContext mc = super.messageContexts[_getSearchMetadataIndex3];
        if (mc == null) {
            mc = new com.ibm.ws.webservices.engine.MessageContext(super.engine);
            mc.setOperation(FNCEWS40SoapBindingStub._getSearchMetadataOperation3);
            mc.setUseSOAPAction(true);
            mc.setSOAPActionURI("http://www.filenet.com/ns/fnce/2006/11/ws/SOAP#GetSearchMetadata");
            mc.setEncodingStyle(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.SEND_TYPE_ATTR_PROPERTY, Boolean.FALSE);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.ENGINE_DO_MULTI_REFS_PROPERTY, Boolean.FALSE);
            super.primeMessageContext(mc);
            super.messageContexts[_getSearchMetadataIndex3] = mc;
        }
        try {
            mc = (com.ibm.ws.webservices.engine.MessageContext) mc.clone();
        }
        catch (CloneNotSupportedException cnse) {
            throw com.ibm.ws.webservices.engine.WebServicesFault.makeFault(cnse);
        }
        return new com.ibm.ws.webservices.engine.client.Stub.Invoke(connection, mc, parameters);
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.GetSearchMetadataResponse getSearchMetadata(com.filenet.www.ns.fnce._2006._11.ws.schema.GetSearchMetadataRequest request) throws java.rmi.RemoteException, com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType {
        if (super.cachedEndpoint == null) {
            throw new com.ibm.ws.webservices.engine.NoEndPointException();
        }
        java.util.Vector _resp = null;
        try {
            _resp = _getgetSearchMetadataInvoke3(new java.lang.Object[] {request}).invoke();

        } catch (com.ibm.ws.webservices.engine.WebServicesFault wsf) {
            Exception e = wsf.getUserException();
            if (e != null) {
                if (e instanceof com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType) {
                    throw (com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType) e;
                }
            }
            throw wsf;
        } 
        try {
            return (com.filenet.www.ns.fnce._2006._11.ws.schema.GetSearchMetadataResponse) ((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue();
        } catch (java.lang.Exception _exception) {
            return (com.filenet.www.ns.fnce._2006._11.ws.schema.GetSearchMetadataResponse) super.convert(((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue(), com.filenet.www.ns.fnce._2006._11.ws.schema.GetSearchMetadataResponse.class);
        }
    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _getContentOperation4 = null;
    private static com.ibm.ws.webservices.engine.description.OperationDesc _getgetContentOperation4() {
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params4 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "GetContentRequest"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetContentRequest"), com.filenet.www.ns.fnce._2006._11.ws.schema.GetContentRequest.class, false, false, false, false, true, false), 
          };
        _params4[0].setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}GetContentRequest");
        _params4[0].setOption("partName","GetContentRequest");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc4 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "GetContentResponse"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetContentResponse"), com.filenet.www.ns.fnce._2006._11.ws.schema.ContentResponseType[].class, true, false, false, false, true, false); 
        _returnDesc4.setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}GetContentResponse");
        _returnDesc4.setOption("partName","GetContentResponse");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults4 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
         new com.ibm.ws.webservices.engine.description.FaultDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FaultResponse"), "com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ErrorStack"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType")), 
          };
        _getContentOperation4 = new com.ibm.ws.webservices.engine.description.OperationDesc("getContent", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "GetContent"), _params4, _returnDesc4, _faults4, "http://www.filenet.com/ns/fnce/2006/11/ws/SOAP#GetContent");
        _getContentOperation4.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FNCEWS40PortType"));
        _getContentOperation4.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "GetContentResponse"));
        _getContentOperation4.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl", "FNCEWS40Service"));
        _getContentOperation4.setOption("buildNum","q0834.18");
        _getContentOperation4.setOption("targetNamespace","http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl");
        _getContentOperation4.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "GetContentRequest"));
        _getContentOperation4.setUse(com.ibm.ws.webservices.engine.enumtype.Use.LITERAL);
        _getContentOperation4.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.DOCUMENT);
        return _getContentOperation4;

    }

    private int _getContentIndex4 = 4;
    private synchronized com.ibm.ws.webservices.engine.client.Stub.Invoke _getgetContentInvoke4(Object[] parameters) throws com.ibm.ws.webservices.engine.WebServicesFault  {
        com.ibm.ws.webservices.engine.MessageContext mc = super.messageContexts[_getContentIndex4];
        if (mc == null) {
            mc = new com.ibm.ws.webservices.engine.MessageContext(super.engine);
            mc.setOperation(FNCEWS40SoapBindingStub._getContentOperation4);
            mc.setUseSOAPAction(true);
            mc.setSOAPActionURI("http://www.filenet.com/ns/fnce/2006/11/ws/SOAP#GetContent");
            mc.setEncodingStyle(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.SEND_TYPE_ATTR_PROPERTY, Boolean.FALSE);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.ENGINE_DO_MULTI_REFS_PROPERTY, Boolean.FALSE);
            super.primeMessageContext(mc);
            super.messageContexts[_getContentIndex4] = mc;
        }
        try {
            mc = (com.ibm.ws.webservices.engine.MessageContext) mc.clone();
        }
        catch (CloneNotSupportedException cnse) {
            throw com.ibm.ws.webservices.engine.WebServicesFault.makeFault(cnse);
        }
        return new com.ibm.ws.webservices.engine.client.Stub.Invoke(connection, mc, parameters);
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ContentResponseType[] getContent(com.filenet.www.ns.fnce._2006._11.ws.schema.GetContentRequest request) throws java.rmi.RemoteException, com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType {
        if (super.cachedEndpoint == null) {
            throw new com.ibm.ws.webservices.engine.NoEndPointException();
        }
        java.util.Vector _resp = null;
        try {
            _resp = _getgetContentInvoke4(new java.lang.Object[] {request}).invoke();

        } catch (com.ibm.ws.webservices.engine.WebServicesFault wsf) {
            Exception e = wsf.getUserException();
            if (e != null) {
                if (e instanceof com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType) {
                    throw (com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType) e;
                }
            }
            throw wsf;
        } 
        try {
            return (com.filenet.www.ns.fnce._2006._11.ws.schema.ContentResponseType[]) ((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue();
        } catch (java.lang.Exception _exception) {
            return (com.filenet.www.ns.fnce._2006._11.ws.schema.ContentResponseType[]) super.convert(((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue(), com.filenet.www.ns.fnce._2006._11.ws.schema.ContentResponseType[].class);
        }
    }

    private static void _staticInit() {
        _getObjectsOperation0 = _getgetObjectsOperation0();
        _executeChangesOperation1 = _getexecuteChangesOperation1();
        _executeSearchOperation2 = _getexecuteSearchOperation2();
        _getSearchMetadataOperation3 = _getgetSearchMetadataOperation3();
        _getContentOperation4 = _getgetContentOperation4();
    }

    static {
       _staticInit();
    }
}
