/**
 * RepositorySearchModeType.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class RepositorySearchModeType  {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected RepositorySearchModeType(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    };

    public static final java.lang.String _Rows = "Rows";
    public static final java.lang.String _Objects = "Objects";
    public static final RepositorySearchModeType Rows = new RepositorySearchModeType(_Rows);
    public static final RepositorySearchModeType Objects = new RepositorySearchModeType(_Objects);
    public java.lang.String getValue() { return _value_;}
    public static RepositorySearchModeType fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        RepositorySearchModeType enumeration = (RepositorySearchModeType)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static RepositorySearchModeType fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}

}
