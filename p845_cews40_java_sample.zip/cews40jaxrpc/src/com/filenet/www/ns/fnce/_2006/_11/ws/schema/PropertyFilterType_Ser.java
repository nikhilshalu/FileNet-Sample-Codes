/**
 * PropertyFilterType_Ser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class PropertyFilterType_Ser extends com.ibm.ws.webservices.engine.encoding.ser.BeanSerializer {
    /**
     * Constructor
     */
    public PropertyFilterType_Ser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    public void serialize(
        javax.xml.namespace.QName name,
        org.xml.sax.Attributes attributes,
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        context.startElement(name, addAttributes(attributes, value, context));
        addElements(value, context);
        context.endElement();
    }
    protected org.xml.sax.Attributes addAttributes(
        org.xml.sax.Attributes attributes,
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        PropertyFilterType bean = (PropertyFilterType) value;
        java.lang.Object propValue;
        org.xml.sax.helpers.AttributesImpl attrs;
        if (attributes==null || attributes.getLength() == 0) {
          attrs = new org.xml.sax.helpers.AttributesImpl();
        } else {
          attrs = new org.xml.sax.helpers.AttributesImpl(attributes);
        }
        {
          javax.xml.namespace.QName attrQName;
          javax.xml.namespace.QName attrTypeQName;
          propValue = new java.lang.Integer(bean.getMaxRecursion());
          if (propValue != null) {        
            attrQName = QName_0_53;
            attrTypeQName = QName_1_13;
            attrs.addAttribute(
              "",
              "maxRecursion",
              context.qName2String(attrQName, true),
              "CDATA",
              context.getValueAsString(propValue, attrTypeQName));
          }
          propValue = bean.getMaxSize();
          if (propValue != null) {        
            attrQName = QName_0_54;
            attrTypeQName = QName_1_35;
            attrs.addAttribute(
              "",
              "maxSize",
              context.qName2String(attrQName, true),
              "CDATA",
              context.getValueAsString(propValue, attrTypeQName));
          }
          propValue = new java.lang.Integer(bean.getMaxElements());
          if (propValue != null) {        
            attrQName = QName_0_55;
            attrTypeQName = QName_1_13;
            attrs.addAttribute(
              "",
              "maxElements",
              context.qName2String(attrQName, true),
              "CDATA",
              context.getValueAsString(propValue, attrTypeQName));
          }
          propValue = new java.lang.Boolean(bean.isLevelDependents());
          if (propValue != null) {        
            attrQName = QName_0_56;
            attrTypeQName = QName_1_3;
            attrs.addAttribute(
              "",
              "levelDependents",
              context.qName2String(attrQName, true),
              "CDATA",
              context.getValueAsString(propValue, attrTypeQName));
          }
        }
        attributes = attrs;
           javax.xml.namespace.QName
           elemQName = QName_2_58;
           context.qName2String(elemQName, true);
           elemQName = QName_2_59;
           context.qName2String(elemQName, true);
           elemQName = QName_2_60;
           context.qName2String(elemQName, true);
        return attributes;
    }
    protected void addElements(
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        PropertyFilterType bean = (PropertyFilterType) value;
        java.lang.Object propValue;
        javax.xml.namespace.QName propQName;
        {
          propQName = QName_2_58;
          {
            propValue = bean.getIncludeProperties();
            if (propValue != null) {
              for (int i=0; i<java.lang.reflect.Array.getLength(propValue); i++) {
                serializeChild(propQName, null, 
                    java.lang.reflect.Array.get(propValue, i), 
                    QName_2_61,
                    true,null,context);
              }
            }
          }
          propQName = QName_2_59;
          {
            propValue = bean.getIncludeTypes();
            if (propValue != null) {
              for (int i=0; i<java.lang.reflect.Array.getLength(propValue); i++) {
                serializeChild(propQName, null, 
                    java.lang.reflect.Array.get(propValue, i), 
                    QName_2_61,
                    true,null,context);
              }
            }
          }
          propQName = QName_2_60;
          {
            propValue = bean.getExcludeProperties();
            if (propValue != null) {
              for (int i=0; i<java.lang.reflect.Array.getLength(propValue); i++) {
                if (java.lang.reflect.Array.get(propValue, i) != null && !context.shouldSendXSIType()) {
                  context.simpleElement(propQName, null, java.lang.reflect.Array.get(propValue, i).toString()); 
                } else {
                  serializeChild(propQName, null, 
                    java.lang.reflect.Array.get(propValue, i), 
                    QName_1_1,
                    true,null,context);
                }
              }
            }
          }
        }
    }
    private final static javax.xml.namespace.QName QName_0_55 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "",
                  "maxElements");
    private final static javax.xml.namespace.QName QName_2_58 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.filenet.com/ns/fnce/2006/11/ws/schema",
                  "IncludeProperties");
    private final static javax.xml.namespace.QName QName_0_56 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "",
                  "levelDependents");
    private final static javax.xml.namespace.QName QName_1_35 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "unsignedLong");
    private final static javax.xml.namespace.QName QName_1_3 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "boolean");
    private final static javax.xml.namespace.QName QName_2_61 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.filenet.com/ns/fnce/2006/11/ws/schema",
                  "FilterElementType");
    private final static javax.xml.namespace.QName QName_1_13 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "int");
    private final static javax.xml.namespace.QName QName_1_1 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "string");
    private final static javax.xml.namespace.QName QName_2_60 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.filenet.com/ns/fnce/2006/11/ws/schema",
                  "ExcludeProperties");
    private final static javax.xml.namespace.QName QName_0_53 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "",
                  "maxRecursion");
    private final static javax.xml.namespace.QName QName_2_59 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.filenet.com/ns/fnce/2006/11/ws/schema",
                  "IncludeTypes");
    private final static javax.xml.namespace.QName QName_0_54 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "",
                  "maxSize");
}
