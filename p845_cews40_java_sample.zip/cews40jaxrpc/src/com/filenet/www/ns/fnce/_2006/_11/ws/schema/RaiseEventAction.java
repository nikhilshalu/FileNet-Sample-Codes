/**
 * RaiseEventAction.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class RaiseEventAction  extends com.filenet.www.ns.fnce._2006._11.ws.schema.ActionType  {
    private java.lang.String classId;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType[] eventProperties;

    public RaiseEventAction() {
    }

    public java.lang.String getClassId() {
        return classId;
    }

    public void setClassId(java.lang.String classId) {
        this.classId = classId;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType[] getEventProperties() {
        return eventProperties;
    }

    public void setEventProperties(com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType[] eventProperties) {
        this.eventProperties = eventProperties;
    }

}
