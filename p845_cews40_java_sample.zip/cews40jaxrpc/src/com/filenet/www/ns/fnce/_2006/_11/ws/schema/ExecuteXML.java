/**
 * ExecuteXML.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class ExecuteXML  {
    private javax.xml.soap.SOAPElement _any;

    public ExecuteXML() {
    }

    public javax.xml.soap.SOAPElement get_any() {
        return _any;
    }

    public void set_any(javax.xml.soap.SOAPElement _any) {
        this._any = _any;
    }

}
