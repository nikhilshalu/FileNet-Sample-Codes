/**
 * MergedScope.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class MergedScope  extends com.filenet.www.ns.fnce._2006._11.ws.schema.SearchScopeType  {
    private com.filenet.www.ns.fnce._2006._11.ws.schema.MergeMode mergeMode;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.SearchScopeType[] componentScope;

    public MergedScope() {
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.MergeMode getMergeMode() {
        return mergeMode;
    }

    public void setMergeMode(com.filenet.www.ns.fnce._2006._11.ws.schema.MergeMode mergeMode) {
        this.mergeMode = mergeMode;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.SearchScopeType[] getComponentScope() {
        return componentScope;
    }

    public void setComponentScope(com.filenet.www.ns.fnce._2006._11.ws.schema.SearchScopeType[] componentScope) {
        this.componentScope = componentScope;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.SearchScopeType getComponentScope(int i) {
        return this.componentScope[i];
    }

    public void setComponentScope(int i, com.filenet.www.ns.fnce._2006._11.ws.schema.SearchScopeType value) {
        this.componentScope[i] = value;
    }

}
