/**
 * ObjectValue.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class ObjectValue  extends com.filenet.www.ns.fnce._2006._11.ws.schema.WithObjectIdentityType  {
    private int updateSequenceNumber;  // attribute
    private int accessAllowed;  // attribute
    private java.lang.String[] superClasses;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyType[] property;

    public ObjectValue() {
    }

    public int getUpdateSequenceNumber() {
        return updateSequenceNumber;
    }

    public void setUpdateSequenceNumber(int updateSequenceNumber) {
        this.updateSequenceNumber = updateSequenceNumber;
    }

    public int getAccessAllowed() {
        return accessAllowed;
    }

    public void setAccessAllowed(int accessAllowed) {
        this.accessAllowed = accessAllowed;
    }

    public java.lang.String[] getSuperClasses() {
        return superClasses;
    }

    public void setSuperClasses(java.lang.String[] superClasses) {
        this.superClasses = superClasses;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyType[] getProperty() {
        return property;
    }

    public void setProperty(com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyType[] property) {
        this.property = property;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyType getProperty(int i) {
        return this.property[i];
    }

    public void setProperty(int i, com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyType value) {
        this.property[i] = value;
    }

}
