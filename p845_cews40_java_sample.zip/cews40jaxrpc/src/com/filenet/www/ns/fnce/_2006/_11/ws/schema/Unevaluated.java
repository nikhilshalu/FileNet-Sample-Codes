/**
 * Unevaluated.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class Unevaluated  extends com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectEntryType  {
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference parentReference;

    public Unevaluated() {
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference getParentReference() {
        return parentReference;
    }

    public void setParentReference(com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference parentReference) {
        this.parentReference = parentReference;
    }

}
