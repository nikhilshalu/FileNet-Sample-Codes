/**
 * FaultStackType_DeserProxy.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class FaultStackType_DeserProxy  extends java.lang.Exception  {
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ErrorNameType errorName;
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ErrorRecordType[] errorRecord;

    public FaultStackType_DeserProxy() {
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ErrorNameType getErrorName() {
        return errorName;
    }

    public void setErrorName(com.filenet.www.ns.fnce._2006._11.ws.schema.ErrorNameType errorName) {
        this.errorName = errorName;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ErrorRecordType[] getErrorRecord() {
        return errorRecord;
    }

    public void setErrorRecord(com.filenet.www.ns.fnce._2006._11.ws.schema.ErrorRecordType[] errorRecord) {
        this.errorRecord = errorRecord;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ErrorRecordType getErrorRecord(int i) {
        return this.errorRecord[i];
    }

    public void setErrorRecord(int i, com.filenet.www.ns.fnce._2006._11.ws.schema.ErrorRecordType value) {
        this.errorRecord[i] = value;
    }

    public java.lang.Object convert() {
      com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType _e;
      _e = new com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType(
        getErrorName(),
        getErrorRecord());
      return _e;
    }
}
