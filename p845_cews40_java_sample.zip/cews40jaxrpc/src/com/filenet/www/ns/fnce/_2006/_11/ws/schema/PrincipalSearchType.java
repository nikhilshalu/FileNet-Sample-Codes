/**
 * PrincipalSearchType.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class PrincipalSearchType  {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected PrincipalSearchType(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    };

    public static final java.lang.String _Custom = "Custom";
    public static final java.lang.String _PrefixMatch = "PrefixMatch";
    public static final java.lang.String _SuffixMatch = "SuffixMatch";
    public static final java.lang.String _Contains = "Contains";
    public static final java.lang.String _Exact = "Exact";
    public static final PrincipalSearchType Custom = new PrincipalSearchType(_Custom);
    public static final PrincipalSearchType PrefixMatch = new PrincipalSearchType(_PrefixMatch);
    public static final PrincipalSearchType SuffixMatch = new PrincipalSearchType(_SuffixMatch);
    public static final PrincipalSearchType Contains = new PrincipalSearchType(_Contains);
    public static final PrincipalSearchType Exact = new PrincipalSearchType(_Exact);
    public java.lang.String getValue() { return _value_;}
    public static PrincipalSearchType fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        PrincipalSearchType enumeration = (PrincipalSearchType)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static PrincipalSearchType fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}

}
