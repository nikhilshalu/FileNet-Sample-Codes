/**
 * FilterElementType.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class FilterElementType  {
    private int maxRecursion;  // attribute
    private java.math.BigInteger maxSize;  // attribute
    private int maxElements;  // attribute
    private boolean levelDependents;  // attribute
    private java.lang.String _value;

    public FilterElementType() {
    }

    public int getMaxRecursion() {
        return maxRecursion;
    }

    public void setMaxRecursion(int maxRecursion) {
        this.maxRecursion = maxRecursion;
    }

    public java.math.BigInteger getMaxSize() {
        return maxSize;
    }

    public void setMaxSize(java.math.BigInteger maxSize) {
        this.maxSize = maxSize;
    }

    public int getMaxElements() {
        return maxElements;
    }

    public void setMaxElements(int maxElements) {
        this.maxElements = maxElements;
    }

    public boolean isLevelDependents() {
        return levelDependents;
    }

    public void setLevelDependents(boolean levelDependents) {
        this.levelDependents = levelDependents;
    }

    public java.lang.String get_value() {
        return _value;
    }

    public void set_value(java.lang.String _value) {
        this._value = _value;
    }

}
