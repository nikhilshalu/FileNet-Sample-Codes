/**
 * ExecuteChangesRequest.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class ExecuteChangesRequest  {
    private boolean refresh;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeRequestType[] changeRequest;

    public ExecuteChangesRequest() {
    }

    public boolean isRefresh() {
        return refresh;
    }

    public void setRefresh(boolean refresh) {
        this.refresh = refresh;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeRequestType[] getChangeRequest() {
        return changeRequest;
    }

    public void setChangeRequest(com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeRequestType[] changeRequest) {
        this.changeRequest = changeRequest;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeRequestType getChangeRequest(int i) {
        return this.changeRequest[i];
    }

    public void setChangeRequest(int i, com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeRequestType value) {
        this.changeRequest[i] = value;
    }

}
