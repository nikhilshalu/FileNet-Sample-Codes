/**
 * ReservationType.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class ReservationType  {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected ReservationType(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    };

    public static final java.lang.String _Collaborative = "Collaborative";
    public static final java.lang.String _Exclusive = "Exclusive";
    public static final ReservationType Collaborative = new ReservationType(_Collaborative);
    public static final ReservationType Exclusive = new ReservationType(_Exclusive);
    public java.lang.String getValue() { return _value_;}
    public static ReservationType fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        ReservationType enumeration = (ReservationType)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static ReservationType fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}

}
