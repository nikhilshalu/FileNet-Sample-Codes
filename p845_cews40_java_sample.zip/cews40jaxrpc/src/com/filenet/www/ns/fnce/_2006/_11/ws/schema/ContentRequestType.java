/**
 * ContentRequestType.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class ContentRequestType  {
    private java.lang.String id;  // attribute
    private boolean cacheAllowed;  // attribute
    private java.lang.String continueFrom;  // attribute
    private java.math.BigInteger startOffset;  // attribute
    private int maxBytes;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference sourceSpecification;
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ElementSpecificationType elementSpecification;

    public ContentRequestType() {
    }

    public java.lang.String getId() {
        return id;
    }

    public void setId(java.lang.String id) {
        this.id = id;
    }

    public boolean isCacheAllowed() {
        return cacheAllowed;
    }

    public void setCacheAllowed(boolean cacheAllowed) {
        this.cacheAllowed = cacheAllowed;
    }

    public java.lang.String getContinueFrom() {
        return continueFrom;
    }

    public void setContinueFrom(java.lang.String continueFrom) {
        this.continueFrom = continueFrom;
    }

    public java.math.BigInteger getStartOffset() {
        return startOffset;
    }

    public void setStartOffset(java.math.BigInteger startOffset) {
        this.startOffset = startOffset;
    }

    public int getMaxBytes() {
        return maxBytes;
    }

    public void setMaxBytes(int maxBytes) {
        this.maxBytes = maxBytes;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference getSourceSpecification() {
        return sourceSpecification;
    }

    public void setSourceSpecification(com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference sourceSpecification) {
        this.sourceSpecification = sourceSpecification;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ElementSpecificationType getElementSpecification() {
        return elementSpecification;
    }

    public void setElementSpecification(com.filenet.www.ns.fnce._2006._11.ws.schema.ElementSpecificationType elementSpecification) {
        this.elementSpecification = elementSpecification;
    }

}
