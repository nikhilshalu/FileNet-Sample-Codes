/**
 * CheckinAction.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class CheckinAction  extends com.filenet.www.ns.fnce._2006._11.ws.schema.ActionType  {
    private boolean autoClassify;  // attribute
    private boolean checkinMinorVersion;  // attribute

    public CheckinAction() {
    }

    public boolean isAutoClassify() {
        return autoClassify;
    }

    public void setAutoClassify(boolean autoClassify) {
        this.autoClassify = autoClassify;
    }

    public boolean isCheckinMinorVersion() {
        return checkinMinorVersion;
    }

    public void setCheckinMinorVersion(boolean checkinMinorVersion) {
        this.checkinMinorVersion = checkinMinorVersion;
    }

}
