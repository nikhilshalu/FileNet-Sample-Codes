/**
 * EndOfCollection.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class EndOfCollection  extends com.filenet.www.ns.fnce._2006._11.ws.schema.CollectionTerminatorType  {

    public EndOfCollection() {
    }

}
