/**
 * SearchRequestType.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public abstract class SearchRequestType  {
    private int maxElements;  // attribute
    private java.lang.String continueFrom;  // attribute
    private boolean continuable;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyFilterType selectionFilter;

    public SearchRequestType() {
    }

    public int getMaxElements() {
        return maxElements;
    }

    public void setMaxElements(int maxElements) {
        this.maxElements = maxElements;
    }

    public java.lang.String getContinueFrom() {
        return continueFrom;
    }

    public void setContinueFrom(java.lang.String continueFrom) {
        this.continueFrom = continueFrom;
    }

    public boolean isContinuable() {
        return continuable;
    }

    public void setContinuable(boolean continuable) {
        this.continuable = continuable;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyFilterType getSelectionFilter() {
        return selectionFilter;
    }

    public void setSelectionFilter(com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyFilterType selectionFilter) {
        this.selectionFilter = selectionFilter;
    }

}
