/**
 * InstallAddOnAction.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class InstallAddOnAction  extends com.filenet.www.ns.fnce._2006._11.ws.schema.ActionType  {
    private java.lang.String addOnId;  // attribute

    public InstallAddOnAction() {
    }

    public java.lang.String getAddOnId() {
        return addOnId;
    }

    public void setAddOnId(java.lang.String addOnId) {
        this.addOnId = addOnId;
    }

}
