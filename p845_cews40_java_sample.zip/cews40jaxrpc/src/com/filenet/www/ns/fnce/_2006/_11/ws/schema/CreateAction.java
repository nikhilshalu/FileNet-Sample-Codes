/**
 * CreateAction.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class CreateAction  extends com.filenet.www.ns.fnce._2006._11.ws.schema.ActionType  {
    private java.lang.String classId;  // attribute
    private java.lang.String objectId;  // attribute
    private boolean autoUniqueContainmentName;  // attribute
    private boolean defineSecurityParentage;  // attribute
    private java.lang.String versionSeriesId;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ReservationType reservationType;  // attribute

    public CreateAction() {
    }

    public java.lang.String getClassId() {
        return classId;
    }

    public void setClassId(java.lang.String classId) {
        this.classId = classId;
    }

    public java.lang.String getObjectId() {
        return objectId;
    }

    public void setObjectId(java.lang.String objectId) {
        this.objectId = objectId;
    }

    public boolean isAutoUniqueContainmentName() {
        return autoUniqueContainmentName;
    }

    public void setAutoUniqueContainmentName(boolean autoUniqueContainmentName) {
        this.autoUniqueContainmentName = autoUniqueContainmentName;
    }

    public boolean isDefineSecurityParentage() {
        return defineSecurityParentage;
    }

    public void setDefineSecurityParentage(boolean defineSecurityParentage) {
        this.defineSecurityParentage = defineSecurityParentage;
    }

    public java.lang.String getVersionSeriesId() {
        return versionSeriesId;
    }

    public void setVersionSeriesId(java.lang.String versionSeriesId) {
        this.versionSeriesId = versionSeriesId;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ReservationType getReservationType() {
        return reservationType;
    }

    public void setReservationType(com.filenet.www.ns.fnce._2006._11.ws.schema.ReservationType reservationType) {
        this.reservationType = reservationType;
    }

}
