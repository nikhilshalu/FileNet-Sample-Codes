/**
 * PropertyFilterType.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class PropertyFilterType  {
    private int maxRecursion;  // attribute
    private java.math.BigInteger maxSize;  // attribute
    private int maxElements;  // attribute
    private boolean levelDependents;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.FilterElementType[] includeProperties;
    private com.filenet.www.ns.fnce._2006._11.ws.schema.FilterElementType[] includeTypes;
    private java.lang.String[] excludeProperties;

    public PropertyFilterType() {
    }

    public int getMaxRecursion() {
        return maxRecursion;
    }

    public void setMaxRecursion(int maxRecursion) {
        this.maxRecursion = maxRecursion;
    }

    public java.math.BigInteger getMaxSize() {
        return maxSize;
    }

    public void setMaxSize(java.math.BigInteger maxSize) {
        this.maxSize = maxSize;
    }

    public int getMaxElements() {
        return maxElements;
    }

    public void setMaxElements(int maxElements) {
        this.maxElements = maxElements;
    }

    public boolean isLevelDependents() {
        return levelDependents;
    }

    public void setLevelDependents(boolean levelDependents) {
        this.levelDependents = levelDependents;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.FilterElementType[] getIncludeProperties() {
        return includeProperties;
    }

    public void setIncludeProperties(com.filenet.www.ns.fnce._2006._11.ws.schema.FilterElementType[] includeProperties) {
        this.includeProperties = includeProperties;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.FilterElementType getIncludeProperties(int i) {
        return this.includeProperties[i];
    }

    public void setIncludeProperties(int i, com.filenet.www.ns.fnce._2006._11.ws.schema.FilterElementType value) {
        this.includeProperties[i] = value;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.FilterElementType[] getIncludeTypes() {
        return includeTypes;
    }

    public void setIncludeTypes(com.filenet.www.ns.fnce._2006._11.ws.schema.FilterElementType[] includeTypes) {
        this.includeTypes = includeTypes;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.FilterElementType getIncludeTypes(int i) {
        return this.includeTypes[i];
    }

    public void setIncludeTypes(int i, com.filenet.www.ns.fnce._2006._11.ws.schema.FilterElementType value) {
        this.includeTypes[i] = value;
    }

    public java.lang.String[] getExcludeProperties() {
        return excludeProperties;
    }

    public void setExcludeProperties(java.lang.String[] excludeProperties) {
        this.excludeProperties = excludeProperties;
    }

    public java.lang.String getExcludeProperties(int i) {
        return this.excludeProperties[i];
    }

    public void setExcludeProperties(int i, java.lang.String value) {
        this.excludeProperties[i] = value;
    }

}
