/**
 * GetSearchMetadataRequest_Ser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class GetSearchMetadataRequest_Ser extends com.ibm.ws.webservices.engine.encoding.ser.BeanSerializer {
    /**
     * Constructor
     */
    public GetSearchMetadataRequest_Ser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    public void serialize(
        javax.xml.namespace.QName name,
        org.xml.sax.Attributes attributes,
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        context.startElement(name, addAttributes(attributes, value, context));
        addElements(value, context);
        context.endElement();
    }
    protected org.xml.sax.Attributes addAttributes(
        org.xml.sax.Attributes attributes,
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
           javax.xml.namespace.QName
           elemQName = QName_2_100;
           context.qName2String(elemQName, true);
           elemQName = QName_2_131;
           context.qName2String(elemQName, true);
           elemQName = QName_2_120;
           context.qName2String(elemQName, true);
        return attributes;
    }
    protected void addElements(
        java.lang.Object value,
        com.ibm.ws.webservices.engine.encoding.SerializationContext context)
        throws java.io.IOException
    {
        GetSearchMetadataRequest bean = (GetSearchMetadataRequest) value;
        java.lang.Object propValue;
        javax.xml.namespace.QName propQName;
        {
          propQName = QName_2_100;
          propValue = bean.getSearchScope();
          serializeChild(propQName, null, 
              propValue, 
              QName_2_94,
              true,null,context);
          propQName = QName_2_131;
          propValue = bean.getClassFilter();
          if (propValue != null && !context.shouldSendXSIType()) {
            context.simpleElement(propQName, null, propValue.toString()); 
          } else {
            serializeChild(propQName, null, 
              propValue, 
              QName_1_1,
              false,null,context);
          }
          propQName = QName_2_120;
          propValue = bean.getPropertyFilter();
          serializeChild(propQName, null, 
              propValue, 
              QName_2_97,
              false,null,context);
        }
    }
    private final static javax.xml.namespace.QName QName_2_94 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.filenet.com/ns/fnce/2006/11/ws/schema",
                  "SearchScopeType");
    private final static javax.xml.namespace.QName QName_2_131 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.filenet.com/ns/fnce/2006/11/ws/schema",
                  "ClassFilter");
    private final static javax.xml.namespace.QName QName_2_97 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.filenet.com/ns/fnce/2006/11/ws/schema",
                  "PropertyFilterType");
    private final static javax.xml.namespace.QName QName_2_120 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.filenet.com/ns/fnce/2006/11/ws/schema",
                  "PropertyFilter");
    private final static javax.xml.namespace.QName QName_1_1 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "string");
    private final static javax.xml.namespace.QName QName_2_100 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.filenet.com/ns/fnce/2006/11/ws/schema",
                  "SearchScope");
}
