/**
 * ListOfDateTime.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class ListOfDateTime  extends com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType  {
    private java.util.Calendar[] value;

    public ListOfDateTime() {
    }

    public java.util.Calendar[] getValue() {
        return value;
    }

    public void setValue(java.util.Calendar[] value) {
        this.value = value;
    }

    public java.util.Calendar getValue(int i) {
        return this.value[i];
    }

    public void setValue(int i, java.util.Calendar value) {
        this.value[i] = value;
    }

}
