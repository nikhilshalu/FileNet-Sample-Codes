/**
 * PropertyType.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public abstract class PropertyType  {
    private java.lang.String propertyId;  // attribute
    private boolean settable;  // attribute

    public PropertyType() {
    }

    public java.lang.String getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(java.lang.String propertyId) {
        this.propertyId = propertyId;
    }

    public boolean isSettable() {
        return settable;
    }

    public void setSettable(boolean settable) {
        this.settable = settable;
    }

}
