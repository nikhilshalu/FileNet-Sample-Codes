/**
 * FNCEWS40Service.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.SOAP.wsdl;

public interface FNCEWS40Service extends javax.xml.rpc.Service {

     // FileNET P8 Content Engine Web Service
    public com.filenet.www.ns.fnce._2006._11.ws.wsdl.FNCEWS40PortType getFNCEWS40InlinePort() throws javax.xml.rpc.ServiceException;

    public java.lang.String getFNCEWS40InlinePortAddress();

    public com.filenet.www.ns.fnce._2006._11.ws.wsdl.FNCEWS40PortType getFNCEWS40InlinePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
