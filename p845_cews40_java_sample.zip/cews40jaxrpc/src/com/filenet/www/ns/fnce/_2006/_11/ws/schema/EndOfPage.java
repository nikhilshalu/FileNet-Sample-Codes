/**
 * EndOfPage.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class EndOfPage  extends com.filenet.www.ns.fnce._2006._11.ws.schema.CollectionTerminatorType  {
    private java.lang.String continueFrom;  // attribute

    public EndOfPage() {
    }

    public java.lang.String getContinueFrom() {
        return continueFrom;
    }

    public void setContinueFrom(java.lang.String continueFrom) {
        this.continueFrom = continueFrom;
    }

}
