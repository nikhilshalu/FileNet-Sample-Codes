/**
 * ContentElementResponse.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class ContentElementResponse  extends com.filenet.www.ns.fnce._2006._11.ws.schema.ContentResponseType  {
    private java.lang.String continueFrom;  // attribute
    private java.lang.String retrievalName;  // attribute
    private java.math.BigInteger totalSize;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference sourceSpecification;
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ElementSpecificationType elementSpecification;
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ContentType content;

    public ContentElementResponse() {
    }

    public java.lang.String getContinueFrom() {
        return continueFrom;
    }

    public void setContinueFrom(java.lang.String continueFrom) {
        this.continueFrom = continueFrom;
    }

    public java.lang.String getRetrievalName() {
        return retrievalName;
    }

    public void setRetrievalName(java.lang.String retrievalName) {
        this.retrievalName = retrievalName;
    }

    public java.math.BigInteger getTotalSize() {
        return totalSize;
    }

    public void setTotalSize(java.math.BigInteger totalSize) {
        this.totalSize = totalSize;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference getSourceSpecification() {
        return sourceSpecification;
    }

    public void setSourceSpecification(com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference sourceSpecification) {
        this.sourceSpecification = sourceSpecification;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ElementSpecificationType getElementSpecification() {
        return elementSpecification;
    }

    public void setElementSpecification(com.filenet.www.ns.fnce._2006._11.ws.schema.ElementSpecificationType elementSpecification) {
        this.elementSpecification = elementSpecification;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ContentType getContent() {
        return content;
    }

    public void setContent(com.filenet.www.ns.fnce._2006._11.ws.schema.ContentType content) {
        this.content = content;
    }

}
