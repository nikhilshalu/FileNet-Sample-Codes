/**
 * WithObjectIdentityType.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public abstract class WithObjectIdentityType  extends com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectEntryType  {
    private java.lang.String classId;  // attribute
    private java.lang.String objectId;  // attribute
    private java.lang.String objectStore;  // attribute
    private boolean serializationDuplicate;  // attribute

    public WithObjectIdentityType() {
    }

    public java.lang.String getClassId() {
        return classId;
    }

    public void setClassId(java.lang.String classId) {
        this.classId = classId;
    }

    public java.lang.String getObjectId() {
        return objectId;
    }

    public void setObjectId(java.lang.String objectId) {
        this.objectId = objectId;
    }

    public java.lang.String getObjectStore() {
        return objectStore;
    }

    public void setObjectStore(java.lang.String objectStore) {
        this.objectStore = objectStore;
    }

    public boolean isSerializationDuplicate() {
        return serializationDuplicate;
    }

    public void setSerializationDuplicate(boolean serializationDuplicate) {
        this.serializationDuplicate = serializationDuplicate;
    }

}
