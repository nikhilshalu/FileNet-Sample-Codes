/**
 * ObjectStoreScope.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class ObjectStoreScope  extends com.filenet.www.ns.fnce._2006._11.ws.schema.SearchScopeType  {
    private java.lang.String objectStore;  // attribute

    public ObjectStoreScope() {
    }

    public java.lang.String getObjectStore() {
        return objectStore;
    }

    public void setObjectStore(java.lang.String objectStore) {
        this.objectStore = objectStore;
    }

}
