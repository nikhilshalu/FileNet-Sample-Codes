/**
 * RepositorySearch.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class RepositorySearch  extends com.filenet.www.ns.fnce._2006._11.ws.schema.SearchRequestType  {
    private com.filenet.www.ns.fnce._2006._11.ws.schema.RepositorySearchModeType repositorySearchMode;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.SearchScopeType searchScope;
    private java.lang.String searchSQL;

    public RepositorySearch() {
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.RepositorySearchModeType getRepositorySearchMode() {
        return repositorySearchMode;
    }

    public void setRepositorySearchMode(com.filenet.www.ns.fnce._2006._11.ws.schema.RepositorySearchModeType repositorySearchMode) {
        this.repositorySearchMode = repositorySearchMode;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.SearchScopeType getSearchScope() {
        return searchScope;
    }

    public void setSearchScope(com.filenet.www.ns.fnce._2006._11.ws.schema.SearchScopeType searchScope) {
        this.searchScope = searchScope;
    }

    public java.lang.String getSearchSQL() {
        return searchSQL;
    }

    public void setSearchSQL(java.lang.String searchSQL) {
        this.searchSQL = searchSQL;
    }

}
