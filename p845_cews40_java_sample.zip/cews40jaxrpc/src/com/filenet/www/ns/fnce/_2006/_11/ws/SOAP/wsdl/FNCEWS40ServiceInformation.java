/**
 * FNCEWS40ServiceInformation.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.SOAP.wsdl;

public class FNCEWS40ServiceInformation implements com.ibm.ws.webservices.multiprotocol.ServiceInformation {

     // FileNET P8 Content Engine Web Service

    private static java.util.Map operationDescriptions;
    private static java.util.Map typeMappings;

    static {
         initOperationDescriptions();
         initTypeMappings();
    }

    private static void initOperationDescriptions() { 
        operationDescriptions = new java.util.HashMap();

        java.util.Map inner0 = new java.util.HashMap();

        java.util.List list0 = new java.util.ArrayList();
        inner0.put("executeChanges", list0);

        com.ibm.ws.webservices.engine.description.OperationDesc executeChanges0Op = _executeChanges0Op();
        list0.add(executeChanges0Op);

        java.util.List list1 = new java.util.ArrayList();
        inner0.put("executeSearch", list1);

        com.ibm.ws.webservices.engine.description.OperationDesc executeSearch1Op = _executeSearch1Op();
        list1.add(executeSearch1Op);

        java.util.List list2 = new java.util.ArrayList();
        inner0.put("getContent", list2);

        com.ibm.ws.webservices.engine.description.OperationDesc getContent2Op = _getContent2Op();
        list2.add(getContent2Op);

        java.util.List list3 = new java.util.ArrayList();
        inner0.put("getObjects", list3);

        com.ibm.ws.webservices.engine.description.OperationDesc getObjects3Op = _getObjects3Op();
        list3.add(getObjects3Op);

        java.util.List list4 = new java.util.ArrayList();
        inner0.put("getSearchMetadata", list4);

        com.ibm.ws.webservices.engine.description.OperationDesc getSearchMetadata4Op = _getSearchMetadata4Op();
        list4.add(getSearchMetadata4Op);

        operationDescriptions.put("FNCEWS40InlinePort",inner0);
        operationDescriptions = java.util.Collections.unmodifiableMap(operationDescriptions);
    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _executeChanges0Op() {
        com.ibm.ws.webservices.engine.description.OperationDesc executeChanges0Op = null;
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ExecuteChangesRequest"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">ExecuteChangesRequest"), com.filenet.www.ns.fnce._2006._11.ws.schema.ExecuteChangesRequest.class, false, false, false, false, true, false), 
          };
        _params0[0].setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}ExecuteChangesRequest");
        _params0[0].setOption("partName","ExecuteChangesRequest");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ExecuteChangesResponse"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">ExecuteChangesResponse"), com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeResponseType[].class, true, false, false, false, true, false); 
        _returnDesc0.setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}ExecuteChangesResponse");
        _returnDesc0.setOption("partName","ExecuteChangesResponse");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
         new com.ibm.ws.webservices.engine.description.FaultDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FaultResponse"), "com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ErrorStack"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType")), 
          };
        executeChanges0Op = new com.ibm.ws.webservices.engine.description.OperationDesc("executeChanges", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "ExecuteChanges"), _params0, _returnDesc0, _faults0, null);
        executeChanges0Op.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FNCEWS40PortType"));
        executeChanges0Op.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "ExecuteChangesResponse"));
        executeChanges0Op.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl", "FNCEWS40Service"));
        executeChanges0Op.setOption("buildNum","q0834.18");
        executeChanges0Op.setOption("targetNamespace","http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl");
        executeChanges0Op.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "ExecuteChangesRequest"));
        executeChanges0Op.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.DOCUMENT);
        return executeChanges0Op;

    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _executeSearch1Op() {
        com.ibm.ws.webservices.engine.description.OperationDesc executeSearch1Op = null;
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ExecuteSearchRequest"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SearchRequestType"), com.filenet.www.ns.fnce._2006._11.ws.schema.SearchRequestType.class, false, false, false, false, true, false), 
          };
        _params0[0].setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}ExecuteSearchRequest");
        _params0[0].setOption("partName","ExecuteSearchRequest");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ExecuteSearchResponse"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectSetType"), com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectSetType.class, true, false, false, false, true, false); 
        _returnDesc0.setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}ExecuteSearchResponse");
        _returnDesc0.setOption("partName","ExecuteSearchResponse");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
         new com.ibm.ws.webservices.engine.description.FaultDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FaultResponse"), "com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ErrorStack"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType")), 
          };
        executeSearch1Op = new com.ibm.ws.webservices.engine.description.OperationDesc("executeSearch", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "ExecuteSearch"), _params0, _returnDesc0, _faults0, null);
        executeSearch1Op.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FNCEWS40PortType"));
        executeSearch1Op.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "ExecuteSearchResponse"));
        executeSearch1Op.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl", "FNCEWS40Service"));
        executeSearch1Op.setOption("buildNum","q0834.18");
        executeSearch1Op.setOption("targetNamespace","http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl");
        executeSearch1Op.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "ExecuteSearchRequest"));
        executeSearch1Op.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.DOCUMENT);
        return executeSearch1Op;

    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _getContent2Op() {
        com.ibm.ws.webservices.engine.description.OperationDesc getContent2Op = null;
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "GetContentRequest"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetContentRequest"), com.filenet.www.ns.fnce._2006._11.ws.schema.GetContentRequest.class, false, false, false, false, true, false), 
          };
        _params0[0].setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}GetContentRequest");
        _params0[0].setOption("partName","GetContentRequest");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "GetContentResponse"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetContentResponse"), com.filenet.www.ns.fnce._2006._11.ws.schema.ContentResponseType[].class, true, false, false, false, true, false); 
        _returnDesc0.setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}GetContentResponse");
        _returnDesc0.setOption("partName","GetContentResponse");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
         new com.ibm.ws.webservices.engine.description.FaultDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FaultResponse"), "com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ErrorStack"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType")), 
          };
        getContent2Op = new com.ibm.ws.webservices.engine.description.OperationDesc("getContent", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "GetContent"), _params0, _returnDesc0, _faults0, null);
        getContent2Op.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FNCEWS40PortType"));
        getContent2Op.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "GetContentResponse"));
        getContent2Op.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl", "FNCEWS40Service"));
        getContent2Op.setOption("buildNum","q0834.18");
        getContent2Op.setOption("targetNamespace","http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl");
        getContent2Op.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "GetContentRequest"));
        getContent2Op.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.DOCUMENT);
        return getContent2Op;

    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _getObjects3Op() {
        com.ibm.ws.webservices.engine.description.OperationDesc getObjects3Op = null;
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "GetObjectsRequest"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetObjectsRequest"), com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectRequestType[].class, false, false, false, false, true, false), 
          };
        _params0[0].setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}GetObjectsRequest");
        _params0[0].setOption("partName","GetObjectsRequest");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "GetObjectsResponse"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetObjectsResponse"), com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectResponseType[].class, true, false, false, false, true, false); 
        _returnDesc0.setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}GetObjectsResponse");
        _returnDesc0.setOption("partName","GetObjectsResponse");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
         new com.ibm.ws.webservices.engine.description.FaultDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FaultResponse"), "com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ErrorStack"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType")), 
          };
        getObjects3Op = new com.ibm.ws.webservices.engine.description.OperationDesc("getObjects", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "GetObjects"), _params0, _returnDesc0, _faults0, null);
        getObjects3Op.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FNCEWS40PortType"));
        getObjects3Op.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "GetObjectsResponse"));
        getObjects3Op.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl", "FNCEWS40Service"));
        getObjects3Op.setOption("buildNum","q0834.18");
        getObjects3Op.setOption("targetNamespace","http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl");
        getObjects3Op.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "GetObjectsRequest"));
        getObjects3Op.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.DOCUMENT);
        return getObjects3Op;

    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _getSearchMetadata4Op() {
        com.ibm.ws.webservices.engine.description.OperationDesc getSearchMetadata4Op = null;
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "GetSearchMetadataRequest"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetSearchMetadataRequest"), com.filenet.www.ns.fnce._2006._11.ws.schema.GetSearchMetadataRequest.class, false, false, false, false, true, false), 
          };
        _params0[0].setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}GetSearchMetadataRequest");
        _params0[0].setOption("partName","GetSearchMetadataRequest");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "GetSearchMetadataResponse"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetSearchMetadataResponse"), com.filenet.www.ns.fnce._2006._11.ws.schema.GetSearchMetadataResponse.class, true, false, false, false, true, false); 
        _returnDesc0.setOption("partQNameString","{http://www.filenet.com/ns/fnce/2006/11/ws/schema}GetSearchMetadataResponse");
        _returnDesc0.setOption("partName","GetSearchMetadataResponse");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
         new com.ibm.ws.webservices.engine.description.FaultDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FaultResponse"), "com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ErrorStack"), com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType")), 
          };
        getSearchMetadata4Op = new com.ibm.ws.webservices.engine.description.OperationDesc("getSearchMetadata", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "GetSearchMetadata"), _params0, _returnDesc0, _faults0, null);
        getSearchMetadata4Op.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "FNCEWS40PortType"));
        getSearchMetadata4Op.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "GetSearchMetadataResponse"));
        getSearchMetadata4Op.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl", "FNCEWS40Service"));
        getSearchMetadata4Op.setOption("buildNum","q0834.18");
        getSearchMetadata4Op.setOption("targetNamespace","http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl");
        getSearchMetadata4Op.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/wsdl", "GetSearchMetadataRequest"));
        getSearchMetadata4Op.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.DOCUMENT);
        return getSearchMetadata4Op;

    }


    private static void initTypeMappings() {
        typeMappings = new java.util.HashMap();
        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "GuidType"),
                         java.lang.String.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "PropertyType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "CollectionType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.CollectionType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "StringEncodingType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.StringEncodingType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "UnevaluatedCollection"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.UnevaluatedCollection.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectReference"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ModifiablePropertyType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SingletonBoolean"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.SingletonBoolean.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SingletonBinary"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.SingletonBinary.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SingletonDateTime"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.SingletonDateTime.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SingletonFloat64"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.SingletonFloat64.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SingletonId"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.SingletonId.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SingletonInteger32"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.SingletonInteger32.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SingletonObject"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.SingletonObject.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectEntryType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectEntryType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SingletonString"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.SingletonString.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ListOfBoolean"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ListOfBoolean.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ListOfBinary"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ListOfBinary.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ListOfDateTime"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ListOfDateTime.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ListOfFloat64"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ListOfFloat64.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ListOfId"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ListOfId.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ListOfInteger32"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ListOfInteger32.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ListOfObject"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ListOfObject.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "DependentObjectType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.DependentObjectType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">ListOfObject>listMode"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ListMode.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ListOfString"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ListOfString.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "EnumOfObject"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.EnumOfObject.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectValue"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectValue.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "CollectionTerminatorType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.CollectionTerminatorType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ContentData"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ContentData.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ContentType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ContentType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "WithObjectIdentityType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.WithObjectIdentityType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">ObjectValue>superClasses"),
                         java.lang.String[].class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "RetrievalError"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.RetrievalError.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ErrorStackType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ErrorStackType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "Unevaluated"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.Unevaluated.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectSpecification"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectSpecification.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">DependentObjectType>dependentAction"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.DependentAction.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectSetType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectSetType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "EndOfCollection"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.EndOfCollection.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "EndOfPage"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.EndOfPage.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "TraversalError"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.TraversalError.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "InlineContent"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.InlineContent.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FilterElementType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.FilterElementType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "PropertyFilterType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyFilterType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ModifiedPropertiesType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType[].class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ActionType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ActionType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ReservationType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ReservationType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "CreateAction"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.CreateAction.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "UpdateAction"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.UpdateAction.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "DeleteAction"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.DeleteAction.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "CheckoutAction"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.CheckoutAction.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "CheckinAction"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.CheckinAction.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FreezeAction"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.FreezeAction.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ChangeStateAction"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeStateAction.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">ChangeStateAction>lifecycleAction"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.LifecycleAction.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ChangeClassAction"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeClassAction.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "MoveContentAction"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.MoveContentAction.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "LockAction"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.LockAction.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "UnlockAction"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.UnlockAction.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "PromoteVersionAction"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.PromoteVersionAction.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "DemoteVersionAction"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.DemoteVersionAction.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ApplySecurityTemplateAction"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ApplySecurityTemplateAction.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "RaiseEventAction"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.RaiseEventAction.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "InstallAddOnAction"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.InstallAddOnAction.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "TakeFederatedOwnershipAction"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.TakeFederatedOwnershipAction.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">Localization"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.Localization.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ErrorNameType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ErrorNameType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "DiagnosticType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.DiagnosticType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ErrorRecordType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ErrorRecordType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "FaultStackType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SearchScopeType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.SearchScopeType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectStoreScope"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectStoreScope.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "MergedScope"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.MergedScope.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">MergedScope>mergeMode"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.MergeMode.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "RepositorySearchModeType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.RepositorySearchModeType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SearchRequestType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.SearchRequestType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "RepositorySearch"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.RepositorySearch.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "PrincipalSearch"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.PrincipalSearch.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">PrincipalSearch>principalSearchType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.PrincipalSearchType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">PrincipalSearch>principalSearchAttribute"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.PrincipalSearchAttribute.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">PrincipalSearch>principalSort"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.PrincipalSort.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "StoredSearch"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.StoredSearch.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">StoredSearch>ExecuteXML"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ExecuteXML.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectRequestType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectRequestType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetObjectsRequest"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectRequestType[].class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectResponseType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectResponseType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "SingleObjectResponse"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.SingleObjectResponse.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectSetResponse"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectSetResponse.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ErrorStackResponse"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ErrorStackResponse.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetObjectsResponse"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectResponseType[].class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ChangeRequestType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeRequestType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">ExecuteChangesRequest"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ExecuteChangesRequest.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ChangeResponseType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeResponseType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">ExecuteChangesResponse"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeResponseType[].class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetSearchMetadataRequest"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.GetSearchMetadataRequest.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetSearchMetadataResponse"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.GetSearchMetadataResponse.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ElementSpecificationType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ElementSpecificationType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ContentRequestType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ContentRequestType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ContentResponseType"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ContentResponseType.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ContentElementResponse"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ContentElementResponse.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ContentErrorResponse"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ContentErrorResponse.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetContentRequest"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.GetContentRequest.class);

        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", ">GetContentResponse"),
                         com.filenet.www.ns.fnce._2006._11.ws.schema.ContentResponseType[].class);

        typeMappings = java.util.Collections.unmodifiableMap(typeMappings);
    }

    public java.util.Map getTypeMappings() {
        return typeMappings;
    }

    public Class getJavaType(javax.xml.namespace.QName xmlName) {
        return (Class) typeMappings.get(xmlName);
    }

    public java.util.Map getOperationDescriptions(String portName) {
        return (java.util.Map) operationDescriptions.get(portName);
    }

    public java.util.List getOperationDescriptions(String portName, String operationName) {
        java.util.Map map = (java.util.Map) operationDescriptions.get(portName);
        if (map != null) {
            return (java.util.List) map.get(operationName);
        }
        return null;
    }

}
