/**
 * PrincipalSearch.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class PrincipalSearch  extends com.filenet.www.ns.fnce._2006._11.ws.schema.SearchRequestType  {
    private boolean includeUsers;  // attribute
    private boolean includeGroups;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.PrincipalSearchType principalSearchType;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.PrincipalSearchAttribute principalSearchAttribute;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.PrincipalSort principalSort;  // attribute
    private java.lang.String searchRealm;
    private java.lang.String searchPattern;

    public PrincipalSearch() {
    }

    public boolean isIncludeUsers() {
        return includeUsers;
    }

    public void setIncludeUsers(boolean includeUsers) {
        this.includeUsers = includeUsers;
    }

    public boolean isIncludeGroups() {
        return includeGroups;
    }

    public void setIncludeGroups(boolean includeGroups) {
        this.includeGroups = includeGroups;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.PrincipalSearchType getPrincipalSearchType() {
        return principalSearchType;
    }

    public void setPrincipalSearchType(com.filenet.www.ns.fnce._2006._11.ws.schema.PrincipalSearchType principalSearchType) {
        this.principalSearchType = principalSearchType;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.PrincipalSearchAttribute getPrincipalSearchAttribute() {
        return principalSearchAttribute;
    }

    public void setPrincipalSearchAttribute(com.filenet.www.ns.fnce._2006._11.ws.schema.PrincipalSearchAttribute principalSearchAttribute) {
        this.principalSearchAttribute = principalSearchAttribute;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.PrincipalSort getPrincipalSort() {
        return principalSort;
    }

    public void setPrincipalSort(com.filenet.www.ns.fnce._2006._11.ws.schema.PrincipalSort principalSort) {
        this.principalSort = principalSort;
    }

    public java.lang.String getSearchRealm() {
        return searchRealm;
    }

    public void setSearchRealm(java.lang.String searchRealm) {
        this.searchRealm = searchRealm;
    }

    public java.lang.String getSearchPattern() {
        return searchPattern;
    }

    public void setSearchPattern(java.lang.String searchPattern) {
        this.searchPattern = searchPattern;
    }

}
