/**
 * EnumOfObject_Helper.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class EnumOfObject_Helper {
    // Type metadata
    private static final com.ibm.ws.webservices.engine.description.TypeDesc typeDesc =
        new com.ibm.ws.webservices.engine.description.TypeDesc(EnumOfObject.class);

    static {
        typeDesc.setOption("buildNum","q0834.18");
        com.ibm.ws.webservices.engine.description.FieldDesc field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("value");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "Value"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectValue"));
        field.setMinOccursIs0(true);
        field.setMaxOccurs(true);
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("collectionTerminator");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "CollectionTerminator"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "CollectionTerminatorType"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new com.ibm.ws.webservices.engine.description.ElementDesc();
        field.setFieldName("parentReference");
        field.setXmlName(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ParentReference"));
        field.setXmlType(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/schema", "ObjectReference"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
    };

    /**
     * Return type metadata object
     */
    public static com.ibm.ws.webservices.engine.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static com.ibm.ws.webservices.engine.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class javaType,  
           javax.xml.namespace.QName xmlType) {
        return 
          new EnumOfObject_Ser(
            javaType, xmlType, typeDesc);
    };

    /**
     * Get Custom Deserializer
     */
    public static com.ibm.ws.webservices.engine.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class javaType,  
           javax.xml.namespace.QName xmlType) {
        return 
          new EnumOfObject_Deser(
            javaType, xmlType, typeDesc);
    };

}
