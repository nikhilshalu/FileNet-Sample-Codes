/**
 * StoredSearch.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class StoredSearch  extends com.filenet.www.ns.fnce._2006._11.ws.schema.SearchRequestType  {
    private com.filenet.www.ns.fnce._2006._11.ws.schema.RepositorySearchModeType repositorySearchMode;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference searchObject;
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ExecuteXML executeXML;

    public StoredSearch() {
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.RepositorySearchModeType getRepositorySearchMode() {
        return repositorySearchMode;
    }

    public void setRepositorySearchMode(com.filenet.www.ns.fnce._2006._11.ws.schema.RepositorySearchModeType repositorySearchMode) {
        this.repositorySearchMode = repositorySearchMode;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference getSearchObject() {
        return searchObject;
    }

    public void setSearchObject(com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference searchObject) {
        this.searchObject = searchObject;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ExecuteXML getExecuteXML() {
        return executeXML;
    }

    public void setExecuteXML(com.filenet.www.ns.fnce._2006._11.ws.schema.ExecuteXML executeXML) {
        this.executeXML = executeXML;
    }

}
