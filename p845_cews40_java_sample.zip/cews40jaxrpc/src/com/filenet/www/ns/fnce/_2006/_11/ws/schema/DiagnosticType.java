/**
 * DiagnosticType.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class DiagnosticType  {
    private java.lang.String diagnosticType;  // attribute
    private java.lang.String _value;

    public DiagnosticType() {
    }

    public java.lang.String getDiagnosticType() {
        return diagnosticType;
    }

    public void setDiagnosticType(java.lang.String diagnosticType) {
        this.diagnosticType = diagnosticType;
    }

    public java.lang.String get_value() {
        return _value;
    }

    public void set_value(java.lang.String _value) {
        this._value = _value;
    }

}
