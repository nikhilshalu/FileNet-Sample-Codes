/**
 * ChangeRequestType.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class ChangeRequestType  {
    private java.lang.String id;  // attribute
    private int updateSequenceNumber;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference targetSpecification;
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ActionType[] action;
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType[] actionProperties;
    private com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyFilterType refreshFilter;

    public ChangeRequestType() {
    }

    public java.lang.String getId() {
        return id;
    }

    public void setId(java.lang.String id) {
        this.id = id;
    }

    public int getUpdateSequenceNumber() {
        return updateSequenceNumber;
    }

    public void setUpdateSequenceNumber(int updateSequenceNumber) {
        this.updateSequenceNumber = updateSequenceNumber;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference getTargetSpecification() {
        return targetSpecification;
    }

    public void setTargetSpecification(com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference targetSpecification) {
        this.targetSpecification = targetSpecification;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ActionType[] getAction() {
        return action;
    }

    public void setAction(com.filenet.www.ns.fnce._2006._11.ws.schema.ActionType[] action) {
        this.action = action;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ActionType getAction(int i) {
        return this.action[i];
    }

    public void setAction(int i, com.filenet.www.ns.fnce._2006._11.ws.schema.ActionType value) {
        this.action[i] = value;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType[] getActionProperties() {
        return actionProperties;
    }

    public void setActionProperties(com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType[] actionProperties) {
        this.actionProperties = actionProperties;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyFilterType getRefreshFilter() {
        return refreshFilter;
    }

    public void setRefreshFilter(com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyFilterType refreshFilter) {
        this.refreshFilter = refreshFilter;
    }

}
