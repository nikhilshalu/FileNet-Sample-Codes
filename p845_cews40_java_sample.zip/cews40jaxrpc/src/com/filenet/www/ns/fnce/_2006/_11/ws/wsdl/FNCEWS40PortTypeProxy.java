package com.filenet.www.ns.fnce._2006._11.ws.wsdl;

public class FNCEWS40PortTypeProxy implements com.filenet.www.ns.fnce._2006._11.ws.wsdl.FNCEWS40PortType {
  private boolean _useJNDI = true;
  private boolean _useJNDIOnly = false;
  private String _endpoint = null;
  private com.filenet.www.ns.fnce._2006._11.ws.wsdl.FNCEWS40PortType __fNCEWS40PortType = null;
  
  public FNCEWS40PortTypeProxy() {
    _initFNCEWS40PortTypeProxy();
  }
  
  private void _initFNCEWS40PortTypeProxy() {
  
    if (_useJNDI || _useJNDIOnly) {
      try {
        javax.naming.InitialContext ctx = new javax.naming.InitialContext();
        __fNCEWS40PortType = ((com.filenet.www.ns.fnce._2006._11.ws.SOAP.wsdl.FNCEWS40Service)ctx.lookup("java:comp/env/service/FNCEWS40Service")).getFNCEWS40InlinePort();
      }
      catch (javax.naming.NamingException namingException) {
        if ("true".equalsIgnoreCase(System.getProperty("DEBUG_PROXY"))) {
          System.out.println("JNDI lookup failure: javax.naming.NamingException: " + namingException.getMessage());
          namingException.printStackTrace(System.out);
        }
      }
      catch (javax.xml.rpc.ServiceException serviceException) {
        if ("true".equalsIgnoreCase(System.getProperty("DEBUG_PROXY"))) {
          System.out.println("Unable to obtain port: javax.xml.rpc.ServiceException: " + serviceException.getMessage());
          serviceException.printStackTrace(System.out);
        }
      }
    }
    if (__fNCEWS40PortType == null && !_useJNDIOnly) {
      try {
        __fNCEWS40PortType = (new com.filenet.www.ns.fnce._2006._11.ws.SOAP.wsdl.FNCEWS40ServiceLocator()).getFNCEWS40InlinePort();
        
      }
      catch (javax.xml.rpc.ServiceException serviceException) {
        if ("true".equalsIgnoreCase(System.getProperty("DEBUG_PROXY"))) {
          System.out.println("Unable to obtain port: javax.xml.rpc.ServiceException: " + serviceException.getMessage());
          serviceException.printStackTrace(System.out);
        }
      }
    }
    if (__fNCEWS40PortType != null) {
      if (_endpoint != null)
        ((javax.xml.rpc.Stub)__fNCEWS40PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
      else
        _endpoint = (String)((javax.xml.rpc.Stub)__fNCEWS40PortType)._getProperty("javax.xml.rpc.service.endpoint.address");
    }
    
  }
  
  
  public void useJNDI(boolean useJNDI) {
    _useJNDI = useJNDI;
    __fNCEWS40PortType = null;
    
  }
  
  public void useJNDIOnly(boolean useJNDIOnly) {
    _useJNDIOnly = useJNDIOnly;
    __fNCEWS40PortType = null;
    
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (__fNCEWS40PortType == null)
      _initFNCEWS40PortTypeProxy();
    if (__fNCEWS40PortType != null)
      ((javax.xml.rpc.Stub)__fNCEWS40PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectResponseType[] getObjects(com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectRequestType[] request) throws java.rmi.RemoteException, com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType{
    if (__fNCEWS40PortType == null)
      _initFNCEWS40PortTypeProxy();
    return __fNCEWS40PortType.getObjects(request);
  }
  
  public com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeResponseType[] executeChanges(com.filenet.www.ns.fnce._2006._11.ws.schema.ExecuteChangesRequest request) throws java.rmi.RemoteException, com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType{
    if (__fNCEWS40PortType == null)
      _initFNCEWS40PortTypeProxy();
    return __fNCEWS40PortType.executeChanges(request);
  }
  
  public com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectSetType executeSearch(com.filenet.www.ns.fnce._2006._11.ws.schema.SearchRequestType request) throws java.rmi.RemoteException, com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType{
    if (__fNCEWS40PortType == null)
      _initFNCEWS40PortTypeProxy();
    return __fNCEWS40PortType.executeSearch(request);
  }
  
  public com.filenet.www.ns.fnce._2006._11.ws.schema.GetSearchMetadataResponse getSearchMetadata(com.filenet.www.ns.fnce._2006._11.ws.schema.GetSearchMetadataRequest request) throws java.rmi.RemoteException, com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType{
    if (__fNCEWS40PortType == null)
      _initFNCEWS40PortTypeProxy();
    return __fNCEWS40PortType.getSearchMetadata(request);
  }
  
  public com.filenet.www.ns.fnce._2006._11.ws.schema.ContentResponseType[] getContent(com.filenet.www.ns.fnce._2006._11.ws.schema.GetContentRequest request) throws java.rmi.RemoteException, com.filenet.www.ns.fnce._2006._11.ws.schema.FaultStackType{
    if (__fNCEWS40PortType == null)
      _initFNCEWS40PortTypeProxy();
    return __fNCEWS40PortType.getContent(request);
  }
  
  
  public com.filenet.www.ns.fnce._2006._11.ws.wsdl.FNCEWS40PortType getFNCEWS40PortType() {
    if (__fNCEWS40PortType == null)
      _initFNCEWS40PortTypeProxy();
    return __fNCEWS40PortType;
  }
  
}