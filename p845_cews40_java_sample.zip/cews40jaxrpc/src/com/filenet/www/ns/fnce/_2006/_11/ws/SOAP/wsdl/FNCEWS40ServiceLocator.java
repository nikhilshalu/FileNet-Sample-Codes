/**
 * FNCEWS40ServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.SOAP.wsdl;

public class FNCEWS40ServiceLocator extends com.ibm.ws.webservices.multiprotocol.AgnosticService implements com.ibm.ws.webservices.multiprotocol.GeneratedService, com.filenet.www.ns.fnce._2006._11.ws.SOAP.wsdl.FNCEWS40Service {

     // FileNET P8 Content Engine Web Service

    public FNCEWS40ServiceLocator() {
        super(com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
           "http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl",
           "FNCEWS40Service"));

        context.setLocatorName("com.filenet.www.ns.fnce._2006._11.ws.SOAP.wsdl.FNCEWS40ServiceLocator");
    }

    public FNCEWS40ServiceLocator(com.ibm.ws.webservices.multiprotocol.ServiceContext ctx) {
        super(ctx);
        context.setLocatorName("com.filenet.www.ns.fnce._2006._11.ws.SOAP.wsdl.FNCEWS40ServiceLocator");
    }

    // Use to get a proxy class for FNCEWS40InlinePort
    private final java.lang.String FNCEWS40InlinePort_address = "http://wjc-rhel.example.net:9081/wsi/FNCEWS40SOAP/";

    public java.lang.String getFNCEWS40InlinePortAddress() {
        if (context.getOverriddingEndpointURIs() == null) {
            return FNCEWS40InlinePort_address;
        }
        String overriddingEndpoint = (String) context.getOverriddingEndpointURIs().get("FNCEWS40InlinePort");
        if (overriddingEndpoint != null) {
            return overriddingEndpoint;
        }
        else {
            return FNCEWS40InlinePort_address;
        }
    }

    private java.lang.String FNCEWS40InlinePortPortName = "FNCEWS40InlinePort";

    // The WSDD port name defaults to the port name.
    private java.lang.String FNCEWS40InlinePortWSDDPortName = "FNCEWS40InlinePort";

    public java.lang.String getFNCEWS40InlinePortWSDDPortName() {
        return FNCEWS40InlinePortWSDDPortName;
    }

    public void setFNCEWS40InlinePortWSDDPortName(java.lang.String name) {
        FNCEWS40InlinePortWSDDPortName = name;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.wsdl.FNCEWS40PortType getFNCEWS40InlinePort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(getFNCEWS40InlinePortAddress());
        }
        catch (java.net.MalformedURLException e) {
            return null; // unlikely as URL was validated in WSDL2Java
        }
        return getFNCEWS40InlinePort(endpoint);
    }

    public com.filenet.www.ns.fnce._2006._11.ws.wsdl.FNCEWS40PortType getFNCEWS40InlinePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        com.filenet.www.ns.fnce._2006._11.ws.wsdl.FNCEWS40PortType _stub =
            (com.filenet.www.ns.fnce._2006._11.ws.wsdl.FNCEWS40PortType) getStub(
                FNCEWS40InlinePortPortName,
                (String) getPort2NamespaceMap().get(FNCEWS40InlinePortPortName),
                com.filenet.www.ns.fnce._2006._11.ws.wsdl.FNCEWS40PortType.class,
                "com.filenet.www.ns.fnce._2006._11.ws.SOAP.wsdl.FNCEWS40SoapBindingStub",
                portAddress.toString());
        if (_stub instanceof com.ibm.ws.webservices.engine.client.Stub) {
            ((com.ibm.ws.webservices.engine.client.Stub) _stub).setPortName(FNCEWS40InlinePortWSDDPortName);
        }
        return _stub;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.filenet.www.ns.fnce._2006._11.ws.wsdl.FNCEWS40PortType.class.isAssignableFrom(serviceEndpointInterface)) {
                return getFNCEWS40InlinePort();
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("WSWS3273E: Error: There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        String inputPortName = portName.getLocalPart();
        if ("FNCEWS40InlinePort".equals(inputPortName)) {
            return getFNCEWS40InlinePort();
        }
        else  {
            throw new javax.xml.rpc.ServiceException();
        }
    }

    public void setPortNamePrefix(java.lang.String prefix) {
        FNCEWS40InlinePortWSDDPortName = prefix + "/" + FNCEWS40InlinePortPortName;
    }

    public javax.xml.namespace.QName getServiceName() {
        return com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.filenet.com/ns/fnce/2006/11/ws/SOAP/wsdl", "FNCEWS40Service");
    }

    private java.util.Map port2NamespaceMap = null;

    protected synchronized java.util.Map getPort2NamespaceMap() {
        if (port2NamespaceMap == null) {
            port2NamespaceMap = new java.util.HashMap();
            port2NamespaceMap.put(
               "FNCEWS40InlinePort",
               "http://schemas.xmlsoap.org/wsdl/soap/");
        }
        return port2NamespaceMap;
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            String serviceNamespace = getServiceName().getNamespaceURI();
            for (java.util.Iterator i = getPort2NamespaceMap().keySet().iterator(); i.hasNext(); ) {
                ports.add(
                    com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                        serviceNamespace,
                        (String) i.next()));
            }
        }
        return ports.iterator();
    }

    public javax.xml.rpc.Call[] getCalls(javax.xml.namespace.QName portName) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            throw new javax.xml.rpc.ServiceException("WSWS3062E: Error: portName should not be null.");
        }
        if  (portName.getLocalPart().equals("FNCEWS40InlinePort")) {
            return new javax.xml.rpc.Call[] {
                createCall(portName, "GetObjects", "null"),
                createCall(portName, "ExecuteChanges", "null"),
                createCall(portName, "ExecuteSearch", "null"),
                createCall(portName, "GetSearchMetadata", "null"),
                createCall(portName, "GetContent", "null"),
            };
        }
        else {
            throw new javax.xml.rpc.ServiceException("WSWS3062E: Error: portName should not be null.");
        }
    }
}
