/**
 * GetContentRequest.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class GetContentRequest  {
    private boolean validateOnly;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ContentRequestType[] contentRequest;

    public GetContentRequest() {
    }

    public boolean isValidateOnly() {
        return validateOnly;
    }

    public void setValidateOnly(boolean validateOnly) {
        this.validateOnly = validateOnly;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ContentRequestType[] getContentRequest() {
        return contentRequest;
    }

    public void setContentRequest(com.filenet.www.ns.fnce._2006._11.ws.schema.ContentRequestType[] contentRequest) {
        this.contentRequest = contentRequest;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ContentRequestType getContentRequest(int i) {
        return this.contentRequest[i];
    }

    public void setContentRequest(int i, com.filenet.www.ns.fnce._2006._11.ws.schema.ContentRequestType value) {
        this.contentRequest[i] = value;
    }

}
