/**
 * ObjectSetType_Deser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class ObjectSetType_Deser extends com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializer {
    /**
     * Constructor
     */
    public ObjectSetType_Deser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    /**
     * Create instance of java bean
     */
    public void createValue() {
        value = new com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectSetType();
    }
    protected boolean tryElementSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        return false;
    }
    protected boolean tryAttributeSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        return false;
    }
    protected boolean tryElementSetFromObject(javax.xml.namespace.QName qName, java.lang.Object objValue) {
        if (qName==QName_2_24) {
          ((ObjectSetType)value).setCollectionTerminator((com.filenet.www.ns.fnce._2006._11.ws.schema.CollectionTerminatorType)objValue);
          return true;}
        return false;
    }
    protected boolean tryElementSetFromList(javax.xml.namespace.QName qName, java.util.List listValue) {
        if (qName==QName_2_50) {
          com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectValue[] array = new com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectValue[listValue.size()];
          listValue.toArray(array);
          ((ObjectSetType)value).setObject(array);
          return true;}
        return false;
    }
    private final static javax.xml.namespace.QName QName_2_24 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.filenet.com/ns/fnce/2006/11/ws/schema",
                  "CollectionTerminator");
    private final static javax.xml.namespace.QName QName_2_50 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.filenet.com/ns/fnce/2006/11/ws/schema",
                  "Object");
}
