/**
 * ChangeRequestType_Deser.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class ChangeRequestType_Deser extends com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializer {
    /**
     * Constructor
     */
    public ChangeRequestType_Deser(
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType, 
           com.ibm.ws.webservices.engine.description.TypeDesc _typeDesc) {
        super(_javaType, _xmlType, _typeDesc);
    }
    /**
     * Create instance of java bean
     */
    public void createValue() {
        value = new com.filenet.www.ns.fnce._2006._11.ws.schema.ChangeRequestType();
    }
    protected boolean tryElementSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        return false;
    }
    protected boolean tryAttributeSetFromString(javax.xml.namespace.QName qName, java.lang.String strValue) {
        if (qName==QName_0_116) {
          ((ChangeRequestType)value).setId(strValue);
          return true;}
        else if (qName==QName_0_27) {
          ((ChangeRequestType)value).setUpdateSequenceNumber(com.ibm.ws.webservices.engine.encoding.ser.SimpleDeserializer.parseint(strValue));
          return true;}
        return false;
    }
    protected boolean tryElementSetFromObject(javax.xml.namespace.QName qName, java.lang.Object objValue) {
        if (qName==QName_2_123) {
          ((ChangeRequestType)value).setTargetSpecification((com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference)objValue);
          return true;}
        else if (qName==QName_2_125) {
          if (objValue instanceof java.util.List) {
            com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType[] array = new com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType[((java.util.List)objValue).size()];
            ((java.util.List)objValue).toArray(array);
            ((ChangeRequestType)value).setActionProperties(array);
          } else { 
            ((ChangeRequestType)value).setActionProperties((com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType[])objValue);}
          return true;}
        else if (qName==QName_2_126) {
          ((ChangeRequestType)value).setRefreshFilter((com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyFilterType)objValue);
          return true;}
        return false;
    }
    protected boolean tryElementSetFromList(javax.xml.namespace.QName qName, java.util.List listValue) {
        if (qName==QName_2_124) {
          com.filenet.www.ns.fnce._2006._11.ws.schema.ActionType[] array = new com.filenet.www.ns.fnce._2006._11.ws.schema.ActionType[listValue.size()];
          listValue.toArray(array);
          ((ChangeRequestType)value).setAction(array);
          return true;}
        return false;
    }
    private final static javax.xml.namespace.QName QName_2_124 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.filenet.com/ns/fnce/2006/11/ws/schema",
                  "Action");
    private final static javax.xml.namespace.QName QName_2_123 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.filenet.com/ns/fnce/2006/11/ws/schema",
                  "TargetSpecification");
    private final static javax.xml.namespace.QName QName_2_126 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.filenet.com/ns/fnce/2006/11/ws/schema",
                  "RefreshFilter");
    private final static javax.xml.namespace.QName QName_1_117 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "ID");
    private final static javax.xml.namespace.QName QName_1_13 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.w3.org/2001/XMLSchema",
                  "int");
    private final static javax.xml.namespace.QName QName_2_125 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "http://www.filenet.com/ns/fnce/2006/11/ws/schema",
                  "ActionProperties");
    private final static javax.xml.namespace.QName QName_0_27 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "",
                  "updateSequenceNumber");
    private final static javax.xml.namespace.QName QName_0_116 = 
           com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                  "",
                  "id");
}
