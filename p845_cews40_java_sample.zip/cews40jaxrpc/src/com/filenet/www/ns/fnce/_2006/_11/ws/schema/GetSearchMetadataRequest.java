/**
 * GetSearchMetadataRequest.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class GetSearchMetadataRequest  {
    private com.filenet.www.ns.fnce._2006._11.ws.schema.SearchScopeType searchScope;
    private java.lang.String classFilter;
    private com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyFilterType propertyFilter;

    public GetSearchMetadataRequest() {
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.SearchScopeType getSearchScope() {
        return searchScope;
    }

    public void setSearchScope(com.filenet.www.ns.fnce._2006._11.ws.schema.SearchScopeType searchScope) {
        this.searchScope = searchScope;
    }

    public java.lang.String getClassFilter() {
        return classFilter;
    }

    public void setClassFilter(java.lang.String classFilter) {
        this.classFilter = classFilter;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyFilterType getPropertyFilter() {
        return propertyFilter;
    }

    public void setPropertyFilter(com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyFilterType propertyFilter) {
        this.propertyFilter = propertyFilter;
    }

}
