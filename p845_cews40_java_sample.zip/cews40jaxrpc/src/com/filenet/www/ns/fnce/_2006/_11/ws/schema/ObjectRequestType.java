/**
 * ObjectRequestType.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class ObjectRequestType  {
    private java.lang.String id;  // attribute
    private boolean cacheAllowed;  // attribute
    private int maxElements;  // attribute
    private java.lang.String continueFrom;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference sourceSpecification;
    private com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyFilterType propertyFilter;

    public ObjectRequestType() {
    }

    public java.lang.String getId() {
        return id;
    }

    public void setId(java.lang.String id) {
        this.id = id;
    }

    public boolean isCacheAllowed() {
        return cacheAllowed;
    }

    public void setCacheAllowed(boolean cacheAllowed) {
        this.cacheAllowed = cacheAllowed;
    }

    public int getMaxElements() {
        return maxElements;
    }

    public void setMaxElements(int maxElements) {
        this.maxElements = maxElements;
    }

    public java.lang.String getContinueFrom() {
        return continueFrom;
    }

    public void setContinueFrom(java.lang.String continueFrom) {
        this.continueFrom = continueFrom;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference getSourceSpecification() {
        return sourceSpecification;
    }

    public void setSourceSpecification(com.filenet.www.ns.fnce._2006._11.ws.schema.ObjectReference sourceSpecification) {
        this.sourceSpecification = sourceSpecification;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyFilterType getPropertyFilter() {
        return propertyFilter;
    }

    public void setPropertyFilter(com.filenet.www.ns.fnce._2006._11.ws.schema.PropertyFilterType propertyFilter) {
        this.propertyFilter = propertyFilter;
    }

}
