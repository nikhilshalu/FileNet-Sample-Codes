/**
 * ListOfId.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class ListOfId  extends com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType  {
    private java.lang.String[] value;

    public ListOfId() {
    }

    public java.lang.String[] getValue() {
        return value;
    }

    public void setValue(java.lang.String[] value) {
        this.value = value;
    }

    public java.lang.String getValue(int i) {
        return this.value[i];
    }

    public void setValue(int i, java.lang.String value) {
        this.value[i] = value;
    }

}
