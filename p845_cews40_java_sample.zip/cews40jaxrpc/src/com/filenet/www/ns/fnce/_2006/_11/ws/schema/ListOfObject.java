/**
 * ListOfObject.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * q0834.18 v82708152146
 */

package com.filenet.www.ns.fnce._2006._11.ws.schema;

public class ListOfObject  extends com.filenet.www.ns.fnce._2006._11.ws.schema.ModifiablePropertyType  {
    private com.filenet.www.ns.fnce._2006._11.ws.schema.ListMode listMode;  // attribute
    private com.filenet.www.ns.fnce._2006._11.ws.schema.DependentObjectType[] value;

    public ListOfObject() {
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.ListMode getListMode() {
        return listMode;
    }

    public void setListMode(com.filenet.www.ns.fnce._2006._11.ws.schema.ListMode listMode) {
        this.listMode = listMode;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.DependentObjectType[] getValue() {
        return value;
    }

    public void setValue(com.filenet.www.ns.fnce._2006._11.ws.schema.DependentObjectType[] value) {
        this.value = value;
    }

    public com.filenet.www.ns.fnce._2006._11.ws.schema.DependentObjectType getValue(int i) {
        return this.value[i];
    }

    public void setValue(int i, com.filenet.www.ns.fnce._2006._11.ws.schema.DependentObjectType value) {
        this.value[i] = value;
    }

}
