/*
 * DISCLAIMER OF WARRANTIES
 * 
 * The accompanying code is sample code created by IBM Corporation. 
 * This sample code is not part of any standard or IBM product and 
 * is provided to you solely for the purpose of assisting you in the 
 * development of your applications. The code is provided "AS IS", 
 * without warranty of any kind. IBM shall not be liable for any 
 * damages arising out of your use of the sample code, even if they 
 * have been advised of the possibility of such damages.
 */
import com.filenet.www.ns.fnce._2006._11.ws.SOAP.wsdl.*;
import com.filenet.www.ns.fnce._2006._11.ws.schema.*;

import java.math.BigInteger;
import java.io.*;

public class CreateDoc {

	String messageDisplay = "";
	public CreateDoc(){
	}
	
	public void setMessageDisplay(String messageTxt){
		messageDisplay = messageTxt;
	}
	public String getMessageDisplay(){
		return messageDisplay;
	}
	
	public boolean create(Object fnStub,String userAccount, String userPassword, String library, String docTitle,boolean includeFilePath,boolean includeFileURL,String filePath,String fileURL,String mimeType, String docClass,boolean fileInFolder,String folderPath){
		int					lngPropCount = 1;
		String				strContentLocation = "";
		String				strRetrievalName = "";		
		BigInteger			ulContentSize = new BigInteger("0");
		FileInputStream   	inFile = null;
		boolean				bOpenedContent = false;
		
		//Set the Content Retrieval name to the docTitle.
		strRetrievalName=docTitle;
		// If content was specified, do some sanity checks and prepare...
		if( includeFilePath )
		{
			// Extract the location, retrieval name, and MIME type
			if( filePath == "" )
			{
				setMessageDisplay("Looks like you forgot to specify a content location - aborting");
				return false;
			}
			if( mimeType == "" )
			{
				setMessageDisplay("Looks like you forgot to specify a MIME type - aborting");
				return false;
			}
			strContentLocation = filePath;

			// Verify that the file exists and get its size
			ulContentSize = getFileContentSize(strContentLocation);
			if( ulContentSize.intValue() == 0 )
			{
				setMessageDisplay("The specified content file either does not exist, or is of zero length");
				return false;
			}
			lngPropCount += 1;
		}


		// We first need to create a Create verb, populate it

		CreateAction createVerb = new CreateAction();
		createVerb.setAutoUniqueContainmentName(new Boolean(true));
		createVerb.setClassId(docClass);

		ChangeRequestType objChange = new ChangeRequestType();
		objChange.setAction(new ActionType[1]);
		objChange.setAction(0,(ActionType)createVerb);
		objChange.setTargetSpecification(new ObjectReference());
		objChange.getTargetSpecification().setClassId("ObjectStore");
		objChange.getTargetSpecification().setObjectId(library);
		objChange.setId("1");

		// Build a list of properties to set in the new document 
		ModifiablePropertyType[] objInputProps = new ModifiablePropertyType[lngPropCount];
		SingletonString objString = new SingletonString();
		objString.setValue(docTitle);
		objString.setPropertyId("DocumentTitle");
		objInputProps[0] = objString;

		if( includeFilePath)		
		{
			// Create content properties array
			//   ContentTransfer elements will take three properties:
			//		* RetrievalName
			//		* Content
			//		* ContentType
			//   ContentReference elements will take two properties:
			//		* ContentLocation
			//		* ContentType
			PropertyType[] ctProps = null;
			if( includeFilePath )
				ctProps = new PropertyType[3];
			else
				ctProps = new PropertyType[2];

			// Set the ContentType property
			SingletonString typeProp = new SingletonString();
			typeProp.setPropertyId("ContentType");
			typeProp.setValue(mimeType);
			ctProps[0] = typeProp;

			// Create the dependent object type object
			DependentObjectType ct = new DependentObjectType();
			ct.setDependentAction(DependentAction.Insert);
			
			// ContentTransfer case
			if( includeFilePath )
			{
				ContentData contData = new ContentData();
			
				// create RetrievalName name property
				SingletonString nameProp = new SingletonString();
				nameProp.setPropertyId("RetrievalName");
				nameProp.setValue(strRetrievalName);
				ctProps[1] = nameProp;

		
				if(fnStub instanceof FNCEWS40SoapBindingStub){
					
					InlineContent inlineContent = new InlineContent();
					
					try{
						inFile = new FileInputStream(filePath);
						File tempFile = new File(filePath);
						
						inlineContent.setBinary(new byte[(int)tempFile.length()]);
						inFile.read(inlineContent.getBinary(), 0,(int)tempFile.length());
						inFile.close();
					}catch(Exception e){
						throw new Error(e.getMessage());
					}
						
					
					// create content data object
					contData.setPropertyId("Content");
					contData.setValue(inlineContent);
					ctProps[2] = contData;
					// Dependent object is of type ContentTransfer
					ct.setClassId("ContentTransfer");
			
				}else{
					throw new Error("Unable to locate a correct binding.");		
				}
			}

			
			//	create content object list
			ct.setProperty(ctProps);
			DependentObjectType[] contentObjects = new DependentObjectType[1];
			contentObjects[0] = ct;

			//	Create the content element list and set it into the document's properties
			ListOfObject objContentList = new ListOfObject();
			objContentList.setPropertyId("ContentElements");
			objContentList.setValue(contentObjects);
			objInputProps[1] = objContentList;
		}
		
		objChange.setActionProperties(objInputProps);

		// Build a list of properties to exclude on the refreshed doc object that is returned
		String[] strExclude = new String[2];
		strExclude[0] = "DateCreated";
		strExclude[1] = "DateLastModified";
		objChange.setRefreshFilter(new PropertyFilterType());
		objChange.getRefreshFilter().setExcludeProperties(strExclude);
		
		// Send off the request
		ChangeResponseType[] objResponseArray = null;
		ExecuteChangesRequest objRequest = new ExecuteChangesRequest();
		objRequest.setRefresh(new Boolean(true));
		objRequest.setChangeRequest(new ChangeRequestType[1]);
		objRequest.setChangeRequest(0,objChange);
		//System.out.println("stub class " + fnStub.getClass().getName());
		
		try
		{
			if(fnStub instanceof FNCEWS40SoapBindingStub){
				FNCEWS40SoapBindingStub fnSoapStub = (FNCEWS40SoapBindingStub)fnStub;
				objResponseArray = fnSoapStub.executeChanges(objRequest);
			}else{
				throw new Error("Unable to locate a correct binding.");		
			}
		}
		catch(FaultStackType faultStackType){
			ErrorRecordType errorRecordType = faultStackType.getErrorRecord(0);
			throw new Error("A FaultStackType exception occurred while creating a document: \n [Description: " + errorRecordType.getDescription() + "]");
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
			ex.getStackTrace();
			setMessageDisplay("An exception occurred while creating a document: [" + ex.getMessage() + "]");
			
			return false;
		}
		finally
		{
			if( bOpenedContent ){
				try{
					inFile.close();
				}catch(Exception e){
					//file must have been closed
				}
			}
		}

		// Created a document!  Sanity check the results
		String strObjectId = "";
		boolean bFound = false;

		if( objResponseArray==null || objResponseArray.length < 1 )
		{
			setMessageDisplay("The change request was executed, but a valid object was not returned");
			return false;
		}
		ChangeResponseType objResponse = objResponseArray[0];
		for(int indexOfProeprties = 0;indexOfProeprties < objResponse.getProperty().length;indexOfProeprties++){
			PropertyType objProp = objResponse.getProperty(indexOfProeprties);
		
			if (objProp.getPropertyId().compareToIgnoreCase("Id") == 0)
			{
				SingletonId singleID = (SingletonId) objProp;
				
				strObjectId = singleID.getValue();
				bFound = true;
				break;
			}
		}
		if( !bFound )
		{
			setMessageDisplay("The document was created, but the results do not contain a document ID!");
			return false;
		}

		if( fileInFolder )
		{
			if(FileDoc(fnStub,userAccount, userPassword, strObjectId, docClass, docTitle, folderPath,library)){
				setMessageDisplay("Successfully created and filed a document!  ID = [" + strObjectId + "] in folder " + folderPath + ".");
			}else{
				return false;
			}
		}
		else{
			setMessageDisplay("Successfully created a document!  ID = [" + strObjectId + "]");
		}
		return true;
	}

	private boolean FileDoc(Object fnStub,String userAccount, String userPassword, String strDocId, String strDocClass, String strDocTitle, String strFolderPath,String library)
	{
		// Create a Create verb, populate it to create a new RCR
		CreateAction createVerb = new CreateAction();
		createVerb.setAutoUniqueContainmentName(new Boolean(true));
		createVerb.setClassId("ReferentialContainmentRelationship");

		ChangeRequestType objChange = new ChangeRequestType();
		objChange.setAction(new ActionType[1]);
		objChange.setAction(0,(ActionType)createVerb);
		objChange.setTargetSpecification(new ObjectReference());
		objChange.getTargetSpecification().setClassId("ObjectStore");
		objChange.getTargetSpecification().setObjectId(library);
		objChange.setId("1");

		// Create the properties of the new RCR
		ObjectReference objHeadRef = new ObjectReference();
		objHeadRef.setClassId(strDocClass);
		objHeadRef.setObjectId(strDocId);
		objHeadRef.setObjectStore(library);
		SingletonObject propHead = new SingletonObject();
		propHead.setPropertyId("Head");
		propHead.setValue((ObjectEntryType)objHeadRef);

		ObjectReference objTailRef = new ObjectReference();
		objTailRef.setClassId("Folder");
		objTailRef.setObjectId(strFolderPath);
		objTailRef.setObjectStore(library);
		SingletonObject propTail = new SingletonObject();
		propTail.setPropertyId("Tail");
		propTail.setValue((ObjectEntryType)objTailRef);

		SingletonString propContainmentName = new SingletonString();
		propContainmentName.setPropertyId("ContainmentName");
		propContainmentName.setValue(strDocTitle);

		ModifiablePropertyType[] objProps = new ModifiablePropertyType[3];
		objProps[0] = propTail;
		objProps[1] = propHead;
		objProps[2] = propContainmentName;
		objChange.setActionProperties(objProps);
		
		
		// Send off the request
		ChangeResponseType[] objResponseArray = null;
		ExecuteChangesRequest objRequest = new ExecuteChangesRequest();
		objRequest.setRefresh(new Boolean(false));
		objRequest.setChangeRequest(new ChangeRequestType[1]);
		objRequest.setChangeRequest(0,objChange);
		try
		{
			if(fnStub instanceof FNCEWS40SoapBindingStub){
				FNCEWS40SoapBindingStub fnSoapStub = (FNCEWS40SoapBindingStub)fnStub;
				objResponseArray = fnSoapStub.executeChanges(objRequest);
			}else{
				throw new Error("Unable to locate a correct binding.");		
			}		
		}
		catch(FaultStackType faultStackType){
			ErrorRecordType errorRecordType = faultStackType.getErrorRecord(0);
			throw new Error("A FaultStackType exception occurred while filing a document: \n [Description: " + errorRecordType.getDescription() + "]");
		}
		catch(Exception ex)
		{
			setMessageDisplay("An exception occurred while filing a document: [" + ex.getMessage() + "] in folder " + strFolderPath + ".");
			return false;
		}

		return true;
	}

	public java.math.BigInteger getFileContentSize(String strSource)
	{
		java.math.BigInteger ulFileSize = new java.math.BigInteger("-1");
		try 
		{
			File inFile = new File(strSource);
			ulFileSize = new java.math.BigInteger(inFile.length() + "");
		}
		catch (Exception ex) 
		{
			return new java.math.BigInteger("0");
		}
		return ulFileSize;
	}


}
