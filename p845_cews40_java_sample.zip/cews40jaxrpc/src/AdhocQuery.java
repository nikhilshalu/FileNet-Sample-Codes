/*
 * DISCLAIMER OF WARRANTIES
 * 
 * The accompanying code is sample code created by IBM Corporation. 
 * This sample code is not part of any standard or IBM product and 
 * is provided to you solely for the purpose of assisting you in the 
 * development of your applications. The code is provided "AS IS", 
 * without warranty of any kind. IBM shall not be liable for any 
 * damages arising out of your use of the sample code, even if they 
 * have been advised of the possibility of such damages.
 */
import com.filenet.www.ns.fnce._2006._11.ws.SOAP.wsdl.*;
import com.filenet.www.ns.fnce._2006._11.ws.schema.*;

public class AdhocQuery {
	String messageDisplay = "";
	
	public void setMessageDisplay(String messageTxt){
		messageDisplay = messageTxt;
	}
	public String getMessageDisplay(){
		return messageDisplay;
	}

	public String[] runAdhocQuery(Object fnStub,String userAccount, String userPassword, String library, String txtSelect, String txtFrom, String txtWhere, String txtMaxRows){
	
	
	ObjectSetType objResponse = null;

	// Perform the requested query
	try
	{

		// Create a search object
		// Set up the scope for the query
		// Set up the SQL for the search
		RepositorySearch objSearch = new RepositorySearch();
		ObjectStoreScope objSearchScope = new ObjectStoreScope();
		objSearchScope.setObjectStore(library);
		objSearch.setSearchScope(objSearchScope);
		objSearch.setSearchSQL("SELECT ");
		if( txtSelect == "" )
			objSearch.setSearchSQL(objSearch.getSearchSQL() + "*");
		else
			objSearch.setSearchSQL(objSearch.getSearchSQL() + txtSelect);
		objSearch.setSearchSQL(objSearch.getSearchSQL() + " FROM " + txtFrom);
		if( txtWhere != "" )
			objSearch.setSearchSQL(objSearch.getSearchSQL() + " WHERE " + txtWhere);
		if( txtMaxRows != "" )
		{
			objSearch.setMaxElements(new Integer(txtMaxRows));
		}

		// Execute the search
		if(fnStub instanceof FNCEWS40SoapBindingStub){
			FNCEWS40SoapBindingStub fnSoapStub = (FNCEWS40SoapBindingStub)fnStub;
			objResponse = fnSoapStub.executeSearch(objSearch);
		}else{
			throw new Error("Unable to locate a correct binding." );
		}
	
	}
	
	catch(FaultStackType faultStackType){
		ErrorRecordType errorRecordType = faultStackType.getErrorRecord(0);
		throw new Error("A FaultStackType exception occurred while querying: \n [Description: " + errorRecordType.getDescription() + "]");
	}
	catch( Exception e2)
	{
		e2.printStackTrace();
		throw new Error("An exception occurred while querying: [" + e2.getMessage() + "]");	
	}

	// Sanity check the results data

	if( objResponse==null || objResponse.getObject()==null )
	{
		throw new Error("The query completed successfully but the results were null!");
		
	}
	if( objResponse.getObject().length < 1 )
	{
		throw new Error("No results were found for this query - exiting.");
		
	}
	long lColumnCount = objResponse.getObject(0).getProperty().length;
	if( lColumnCount < 1 )
	{
		throw new Error("The query succeeded, but the results contain no properties - exiting");
		
	}

	// Query was successful; display a list of result rows
	// First create a data table that has one column for each property in the 
	//  returned data
	
	ObjectValue[] objObjects = objResponse.getObject();
	String[] returnStrings = new String[objObjects.length];
	// Populate the rows
	
	for(int index=0; index < objObjects.length; index++){
		ObjectValue objClass = objObjects[index];
		PropertyType[] pts = objClass.getProperty();
		for(int indexOfProp=0; indexOfProp < pts.length; indexOfProp++){
			PropertyType pt = pts[indexOfProp];
			
			if(pt.getPropertyId().compareToIgnoreCase("SymbolicName") ==0){
				SingletonString ss = (SingletonString)pt;	
				returnStrings[index] = ss.getValue();
			}
			if(pt.getPropertyId().compareToIgnoreCase("this") ==0){
				SingletonObject objSO = (SingletonObject)pt;
				ObjectReference objRef = (ObjectReference)((SingletonObject)pt).getValue();
				try
				{
					objRef = (ObjectReference)objSO.getValue();
					String strParentClassName = objRef.getClassId();
					String strParentClassId = objRef.getObjectId();
					returnStrings[index] = returnStrings[index]  + " " +  strParentClassName + " " + strParentClassId;
				}
				catch (Exception e1)
				{
				}
			}
		}
		
	}

	return returnStrings;
	}
}
