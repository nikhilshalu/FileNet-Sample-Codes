/*
 * DISCLAIMER OF WARRANTIES
 * 
 * The accompanying code is sample code created by IBM Corporation. 
 * This sample code is not part of any standard or IBM product and 
 * is provided to you solely for the purpose of assisting you in the 
 * development of your applications. The code is provided "AS IS", 
 * without warranty of any kind. IBM shall not be liable for any 
 * damages arising out of your use of the sample code, even if they 
 * have been advised of the possibility of such damages.
 */
public class FolderNode {

	private String m_strName;
	private String m_strId;
	private boolean m_blnExpanded;

	public FolderNode()
	{
		m_strName = "";
		m_strId = "";
		m_blnExpanded = false;
	}

	public String getName(){
		return m_strName;	
	}
	public void setName(String valueName){
		m_strName = valueName;
	}

	public String getId(){
		return m_strId;	
	}
	public void setId(String valueId){
		m_strId = valueId;
	}

	public boolean getExpanded(){
		return m_blnExpanded;	
	}
	public void setExpanded(boolean valueExpanded){
		m_blnExpanded = valueExpanded;
	}
	public String toString(){
		return m_strName;
	}

}
