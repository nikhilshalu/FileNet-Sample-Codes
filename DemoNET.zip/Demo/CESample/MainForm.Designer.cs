namespace CESample
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.connectionGroupBox = new System.Windows.Forms.GroupBox();
            this.statusLabel = new System.Windows.Forms.Label();
            this.connectionButton = new System.Windows.Forms.Button();
            this.passTextBox = new System.Windows.Forms.TextBox();
            this.userTextBox = new System.Windows.Forms.TextBox();
            this.uriTextBox = new System.Windows.Forms.TextBox();
            this.passLabel = new System.Windows.Forms.Label();
            this.userLabel = new System.Windows.Forms.Label();
            this.uriLabel = new System.Windows.Forms.Label();
            this.createDocButton = new System.Windows.Forms.Button();
            this.getDocButton = new System.Windows.Forms.Button();
            this.createFolderButton = new System.Windows.Forms.Button();
            this.createCOButton = new System.Windows.Forms.Button();
            this.getCOButton = new System.Windows.Forms.Button();
            this.createCompoundDocButton = new System.Windows.Forms.Button();
            this.getCompoundDocButton = new System.Windows.Forms.Button();
            this.adhocQueryButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.connectionGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // connectionGroupBox
            // 
            this.connectionGroupBox.Controls.Add(this.statusLabel);
            this.connectionGroupBox.Controls.Add(this.connectionButton);
            this.connectionGroupBox.Controls.Add(this.passTextBox);
            this.connectionGroupBox.Controls.Add(this.userTextBox);
            this.connectionGroupBox.Controls.Add(this.uriTextBox);
            this.connectionGroupBox.Controls.Add(this.passLabel);
            this.connectionGroupBox.Controls.Add(this.userLabel);
            this.connectionGroupBox.Controls.Add(this.uriLabel);
            this.connectionGroupBox.Location = new System.Drawing.Point(1, 0);
            this.connectionGroupBox.Name = "connectionGroupBox";
            this.connectionGroupBox.Size = new System.Drawing.Size(506, 150);
            this.connectionGroupBox.TabIndex = 0;
            this.connectionGroupBox.TabStop = false;
            this.connectionGroupBox.Text = "Connection Parameters";
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Location = new System.Drawing.Point(11, 134);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(73, 13);
            this.statusLabel.TabIndex = 7;
            this.statusLabel.Text = "Click Connect";
            // 
            // connectionButton
            // 
            this.connectionButton.Location = new System.Drawing.Point(208, 94);
            this.connectionButton.Name = "connectionButton";
            this.connectionButton.Size = new System.Drawing.Size(103, 23);
            this.connectionButton.TabIndex = 6;
            this.connectionButton.Text = "Connect";
            this.connectionButton.UseVisualStyleBackColor = true;
            this.connectionButton.Click += new System.EventHandler(this.connectionButton_Click);
            // 
            // passTextBox
            // 
            this.passTextBox.Location = new System.Drawing.Point(139, 68);
            this.passTextBox.Name = "passTextBox";
            this.passTextBox.Size = new System.Drawing.Size(354, 20);
            this.passTextBox.TabIndex = 5;
            // 
            // userTextBox
            // 
            this.userTextBox.Location = new System.Drawing.Point(139, 44);
            this.userTextBox.Name = "userTextBox";
            this.userTextBox.Size = new System.Drawing.Size(354, 20);
            this.userTextBox.TabIndex = 4;
            // 
            // uriTextBox
            // 
            this.uriTextBox.Location = new System.Drawing.Point(139, 17);
            this.uriTextBox.Name = "uriTextBox";
            this.uriTextBox.Size = new System.Drawing.Size(354, 20);
            this.uriTextBox.TabIndex = 3;
            this.uriTextBox.Text = "http://<localhost>:<port>/wsi/FNCEWS40MTOM/";
            // 
            // passLabel
            // 
            this.passLabel.AutoSize = true;
            this.passLabel.Location = new System.Drawing.Point(12, 75);
            this.passLabel.Name = "passLabel";
            this.passLabel.Size = new System.Drawing.Size(53, 13);
            this.passLabel.TabIndex = 2;
            this.passLabel.Text = "Password";
            // 
            // userLabel
            // 
            this.userLabel.AutoSize = true;
            this.userLabel.Location = new System.Drawing.Point(12, 47);
            this.userLabel.Name = "userLabel";
            this.userLabel.Size = new System.Drawing.Size(55, 13);
            this.userLabel.TabIndex = 1;
            this.userLabel.Text = "Username";
            // 
            // uriLabel
            // 
            this.uriLabel.AutoSize = true;
            this.uriLabel.Location = new System.Drawing.Point(12, 20);
            this.uriLabel.Name = "uriLabel";
            this.uriLabel.Size = new System.Drawing.Size(43, 13);
            this.uriLabel.TabIndex = 0;
            this.uriLabel.Text = "CE URI";
            // 
            // createDocButton
            // 
            this.createDocButton.Enabled = false;
            this.createDocButton.Location = new System.Drawing.Point(12, 156);
            this.createDocButton.Name = "createDocButton";
            this.createDocButton.Size = new System.Drawing.Size(119, 23);
            this.createDocButton.TabIndex = 7;
            this.createDocButton.Text = "Create Doc";
            this.createDocButton.UseVisualStyleBackColor = true;
            this.createDocButton.Click += new System.EventHandler(this.createDocButton_Click);
            // 
            // getDocButton
            // 
            this.getDocButton.Enabled = false;
            this.getDocButton.Location = new System.Drawing.Point(137, 156);
            this.getDocButton.Name = "getDocButton";
            this.getDocButton.Size = new System.Drawing.Size(103, 23);
            this.getDocButton.TabIndex = 8;
            this.getDocButton.Text = "Get Doc";
            this.getDocButton.UseVisualStyleBackColor = true;
            this.getDocButton.Click += new System.EventHandler(this.getDocButton_Click);
            // 
            // createFolderButton
            // 
            this.createFolderButton.Enabled = false;
            this.createFolderButton.Location = new System.Drawing.Point(246, 156);
            this.createFolderButton.Name = "createFolderButton";
            this.createFolderButton.Size = new System.Drawing.Size(122, 23);
            this.createFolderButton.TabIndex = 9;
            this.createFolderButton.Text = "Create Folder";
            this.createFolderButton.UseVisualStyleBackColor = true;
            this.createFolderButton.Click += new System.EventHandler(this.createFolderButton_Click);
            // 
            // createCOButton
            // 
            this.createCOButton.Enabled = false;
            this.createCOButton.Location = new System.Drawing.Point(12, 185);
            this.createCOButton.Name = "createCOButton";
            this.createCOButton.Size = new System.Drawing.Size(119, 23);
            this.createCOButton.TabIndex = 10;
            this.createCOButton.Text = "Create CustomObject";
            this.createCOButton.UseVisualStyleBackColor = true;
            this.createCOButton.Click += new System.EventHandler(this.createCOButton_Click);
            // 
            // getCOButton
            // 
            this.getCOButton.Enabled = false;
            this.getCOButton.Location = new System.Drawing.Point(137, 185);
            this.getCOButton.Name = "getCOButton";
            this.getCOButton.Size = new System.Drawing.Size(103, 23);
            this.getCOButton.TabIndex = 11;
            this.getCOButton.Text = "Get CustomObject";
            this.getCOButton.UseVisualStyleBackColor = true;
            this.getCOButton.Click += new System.EventHandler(this.getCOButton_Click);
            // 
            // createCompoundDocButton
            // 
            this.createCompoundDocButton.Enabled = false;
            this.createCompoundDocButton.Location = new System.Drawing.Point(246, 185);
            this.createCompoundDocButton.Name = "createCompoundDocButton";
            this.createCompoundDocButton.Size = new System.Drawing.Size(122, 23);
            this.createCompoundDocButton.TabIndex = 12;
            this.createCompoundDocButton.Text = "Create CompoundDoc";
            this.createCompoundDocButton.UseVisualStyleBackColor = true;
            this.createCompoundDocButton.Click += new System.EventHandler(this.createCompoundDocButton_Click);
            // 
            // getCompoundDocButton
            // 
            this.getCompoundDocButton.Enabled = false;
            this.getCompoundDocButton.Location = new System.Drawing.Point(374, 185);
            this.getCompoundDocButton.Name = "getCompoundDocButton";
            this.getCompoundDocButton.Size = new System.Drawing.Size(116, 23);
            this.getCompoundDocButton.TabIndex = 13;
            this.getCompoundDocButton.Text = "Get CompoundDoc";
            this.getCompoundDocButton.UseVisualStyleBackColor = true;
            this.getCompoundDocButton.Click += new System.EventHandler(this.getCompoundDocButton_Click);
            // 
            // adhocQueryButton
            // 
            this.adhocQueryButton.Enabled = false;
            this.adhocQueryButton.Location = new System.Drawing.Point(374, 156);
            this.adhocQueryButton.Name = "adhocQueryButton";
            this.adhocQueryButton.Size = new System.Drawing.Size(119, 23);
            this.adhocQueryButton.TabIndex = 8;
            this.adhocQueryButton.Text = "Adhoc Query";
            this.adhocQueryButton.UseVisualStyleBackColor = true;
            this.adhocQueryButton.Click += new System.EventHandler(this.adhocQueryButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(208, 214);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 14;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(508, 241);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.adhocQueryButton);
            this.Controls.Add(this.getCompoundDocButton);
            this.Controls.Add(this.createCompoundDocButton);
            this.Controls.Add(this.getCOButton);
            this.Controls.Add(this.createCOButton);
            this.Controls.Add(this.createFolderButton);
            this.Controls.Add(this.getDocButton);
            this.Controls.Add(this.createDocButton);
            this.Controls.Add(this.connectionGroupBox);
            this.Name = "MainForm";
            this.Text = "Content Engine .NET API Demo";
            this.connectionGroupBox.ResumeLayout(false);
            this.connectionGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox connectionGroupBox;
        private System.Windows.Forms.Label uriLabel;
        private System.Windows.Forms.TextBox passTextBox;
        private System.Windows.Forms.TextBox userTextBox;
        private System.Windows.Forms.TextBox uriTextBox;
        private System.Windows.Forms.Label passLabel;
        private System.Windows.Forms.Label userLabel;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.Button connectionButton;
        private System.Windows.Forms.Button createDocButton;
        private System.Windows.Forms.Button getDocButton;
        private System.Windows.Forms.Button createFolderButton;
        private System.Windows.Forms.Button createCOButton;
        private System.Windows.Forms.Button getCOButton;
        private System.Windows.Forms.Button createCompoundDocButton;
        private System.Windows.Forms.Button getCompoundDocButton;
        private System.Windows.Forms.Button adhocQueryButton;
        private System.Windows.Forms.Button closeButton;
    }
}

