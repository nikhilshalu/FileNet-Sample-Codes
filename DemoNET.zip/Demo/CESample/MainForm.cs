/*
       IBM grants you a nonexclusive copyright license to use all programming code 
	examples from which you can generate similar function tailored to your own 
	specific needs.

	All sample code is provided by IBM for illustrative purposes only.
	These examples have not been thoroughly tested under all conditions.  IBM, 
	therefore cannot guarantee or imply reliability, serviceability, or function of 
	these programs.

	All Programs or code component contained herein are provided to you �AS IS � 
	without any warranties of any kind.
	The implied warranties of non-infringement, merchantability and fitness for a 
	particular purpose are expressly disclaimed.

	� Copyright IBM Corporation 2007, ALL RIGHTS RESERVED.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using FileNet.Api.Exception;

namespace CESample
{
    //
    // Form with UI components to collect necessary information
    // to connect to CE and establish security credentials for
    // the user. It has buttons that, when clicked, pop up
    // forms to create and get documents, custom objects, and
    // compound documents; to create Folders; and to query CE.
    //
    public partial class MainForm : Form
    {
        private CEConnection ce;

        //
        // Constructor
        //
        public MainForm()
        {
            InitializeComponent();
            ce = new CEConnection();
        }

        //
        // Handles the event generated when 'Connect' button is clicked.
        // It establishes the security credentials for the user with the CE.
        //
        private void connectionButton_Click(object sender, EventArgs e)
        {
            String user = userTextBox.Text;
            String pass = passTextBox.Text;
            String uri = uriTextBox.Text;
            try
            {
                if (CheckRequiredFields())
                {
                    ce.EstablishCredentials(user, pass, uri);
                    statusLabel.Text = "Connected to Content Engine";
                    connectionButton.Enabled = false;
                    EnableButtons(); 
                }
            }
            catch (EngineRuntimeException ere)
            {
                statusLabel.Text = ere.Message;
                System.Console.WriteLine(ere.StackTrace);
            } 
        }

        //
        // Enables the intially disabled buttons once the security credentials
        // are established for the the user.
        //
        private void EnableButtons()
        {
            createDocButton.Enabled = true;
            getDocButton.Enabled = true;
            createFolderButton.Enabled = true;
            createCOButton.Enabled = true;
            getCOButton.Enabled = true;
            createCompoundDocButton.Enabled = true;
            getCompoundDocButton.Enabled = true;
            adhocQueryButton.Enabled = true;
        }

        //
        // Handles the event generated when 'Close' button is clicked.
        // Closes this Form.
        //
        private void closeButton_Click(object sender, EventArgs e)
        {
            base.Dispose();
        }

        //
        // Checks whether all required fields are filled before 
        // performing any action.
        //
        private bool CheckRequiredFields()
        {
            bool check = true;
            if (uriTextBox.Text.Equals(""))
            {
                uriTextBox.Text = "Enter CE URI.";
                check = false;
            }
            if (userTextBox.Text.Equals(""))
            {
                userTextBox.Text = "Enter Username.";
                check = false;
            }
            if (passTextBox.Text.Equals(""))
            {
                passTextBox.Text = "Enter Password.";
                check = false;
            }
            return check;
        }

        //
        // Handles the event generated when 'createDoc' button is clicked.
        // Opens the CreateDoc Form.
        //
        private void createDocButton_Click(object sender, EventArgs e)
        {
            CreateDocForm form = new CreateDocForm(ce);
            form.Show();
        }

        //
        // Handles the event generated when 'getDoc' button is clicked.
        // Opens the GetDoc Form.
        //
        private void getDocButton_Click(object sender, EventArgs e)
        {
            GetDocForm form = new GetDocForm(ce);
            form.Show();
        }

        //
        // Handles the event generated when 'createFolder' button is clicked.
        // Opens the CreateFolder Form.
        //
        private void createFolderButton_Click(object sender, EventArgs e)
        {
            CreateFolderForm form = new CreateFolderForm(ce);
            form.Show();
        }

        //
        // Handles the event generated when 'createCustomObject' button is clicked.
        // Opens the CreateCustomObject Form.
        //
        private void createCOButton_Click(object sender, EventArgs e)
        {
            CreateCustomObjectForm form = new CreateCustomObjectForm(ce);
            form.Show();
        }

        //
        // Handles the event generated when 'getCustomObject' button is clicked.
        // Opens the GetCustomObject Form.
        //
        private void getCOButton_Click(object sender, EventArgs e)
        {
            GetCustomObjectForm form = new GetCustomObjectForm(ce);
            form.Show();
        }

        //
        // Handles the event generated when 'createCompoundDoc' button is clicked.
        // Opens up the CreateCompoundDoc Form.
        //
        private void createCompoundDocButton_Click(object sender, EventArgs e)
        {
            CreateCompoundDocForm form = new CreateCompoundDocForm(ce);
            form.Show();
        }

        //
        // Handles the event generated when 'getCompoundDoc' button is clicked.
        // Opens up the GetCompoundDoc Form.
        //
        private void getCompoundDocButton_Click(object sender, EventArgs e)
        {
            GetCompoundDocForm form = new GetCompoundDocForm(ce);
            form.Show();
        }

        //
        // Handles the event generated when 'adhocQuery' button is clicked.
        // Opens up the AdhocQuery Form.
        //
        private void adhocQueryButton_Click(object sender, EventArgs e)
        {
            AdhocQueryForm form = new AdhocQueryForm(ce);
            form.Show();
        }
    }
}