/*
      IBM grants you a nonexclusive copyright license to use all programming code 
	examples from which you can generate similar function tailored to your own 
	specific needs.

	All sample code is provided by IBM for illustrative purposes only.
	These examples have not been thoroughly tested under all conditions.  IBM, 
	therefore cannot guarantee or imply reliability, serviceability, or function of 
	these programs.

	All Programs or code component contained herein are provided to you �AS IS � 
	without any warranties of any kind.
	The implied warranties of non-infringement, merchantability and fitness for a 
	particular purpose are expressly disclaimed.

	� Copyright IBM Corporation 2007, ALL RIGHTS RESERVED.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using FileNet.Api.Core;
using FileNet.Api.Constants;
using FileNet.Api.Exception;

namespace CESample
{
    //
    // Form with UI components to collect necessary information
    // to create Document.
    //
    public partial class CreateDocForm : Form
    {
        private CEConnection ce;
        
        //
        // Constructor
        //
        public CreateDocForm(CEConnection c)
        {
            ce = c;
            InitializeComponent();
        }

        //
        // Handles the event generated when 'Browse' button is clicked.
        // It opens OpenFileDialog, which lets the user choose the file on
        // a file system. File content can be included in Document instance.
        //
        private void browseButton_Click(object sender, EventArgs e)
        {
            openFileDialog.ShowDialog();
            contentTextBox.Text = openFileDialog.FileName;            
        }

        //
        // Handles the event generated when 'Close' button is clicked.
        // Closes this Form.
        //
        private void closeButton_Click(object sender, EventArgs e)
        {
            base.Dispose();
        }

        // 
        // Handles the event generated when 'Create' button is clicked.
        // Creates the Document object with or without
	 // the content. Content can be included from any
        // file on the file system. Created Document can be
	 // filed and checked in.
        //
        private void createButton_Click(object sender, EventArgs e)
        {
            String file = contentTextBox.Text;
            String mime = mimeTextBox.Text;
            String title = titleTextBox.Text;
            String className = classTextBox.Text;
            try
            {
                if (CheckRequiredFields())
                {
                    IDocument doc = null;
                    IObjectStore os = ce.FetchOS((String)osComboBox.SelectedItem);
                    if (contentCheckBox.Checked == true)
                        doc = CEUtil.CreateDocument(true, file, mime, title, os, className);
                    else
                        doc = CEUtil.CreateDocument(false, null, mime, title, os, className);
                    doc.Save(RefreshMode.REFRESH);
                    if (fileCheckBox.Checked)
                    {
                        String folder = fileTextBox.Text;
                        if (folder.Length == 0)
                            folder = "/";
                        IReferentialContainmentRelationship rcr = CEUtil.FileContainable(os, doc, folder);
                        rcr.Save(RefreshMode.REFRESH);
                    }
                    if (checkinCheckBox.Checked)
                        CEUtil.checkInDoc(doc);
                    statusLabel.Text = "Document " + title + " created"; 
                }
            }
            catch (EngineRuntimeException ere)
            {
                statusLabel.Text = ere.Message;
                System.Console.WriteLine(ere.StackTrace);
            }
        }

        // 
        // Handles the event generated when 'Create' button is clicked.
        // Clears the text boxes and resets the status label.
        //
        private void clearbutton_Click(object sender, EventArgs e)
        {
            titleTextBox.Text = "";
            contentTextBox.Text = "";
            fileTextBox.Text = "";
            mimeTextBox.Text = "text/plain";
            classTextBox.Text = "Document";
            statusLabel.Text = "Click Create to create Document";
        }

        //
        // Handles the event generated when Form is loaded.
        // It populates the 'osComboBox' with names of the available
        // object stores.
        //
        private void CreateDocForm_Load(object sender, EventArgs e)
        {
            ArrayList osNames = ce.GetOSNames();
            osComboBox.Items.Clear();
            for (int i = 0; i < osNames.Count; i++)
            {
                osComboBox.Items.Add(osNames[i]);
            }
        }

        //
        // Checks whether all required fields are filled before 
        // performing any action.
        //
        private bool CheckRequiredFields()
        {
            bool check = true;
            if (osComboBox.SelectedItem == null)
            {
                statusLabel.Text = "Select Object Store from the ComboBox";
                check = false;
            }
            else
            {
                if (titleTextBox.Text.Equals(""))
                {
                    titleTextBox.Text = "DocumentTitle field can not be empty.";
                    check = false;
                }
                if (contentCheckBox.Checked)
                {
                    if (contentTextBox.Text.Equals(""))
                    {
                        contentTextBox.Text = "Can not be empty";
                        check = false;
                    }
                }
            }
            return check;
        }
    }
}