namespace CESample
{
    partial class AdhocQueryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.paramGroupBox = new System.Windows.Forms.GroupBox();
            this.maxTextBox = new System.Windows.Forms.TextBox();
            this.maxCheckBox = new System.Windows.Forms.CheckBox();
            this.whereTextBox = new System.Windows.Forms.TextBox();
            this.whereLabel = new System.Windows.Forms.Label();
            this.fromLabel = new System.Windows.Forms.Label();
            this.clearbutton = new System.Windows.Forms.Button();
            this.statusLabel = new System.Windows.Forms.Label();
            this.osComboBox = new System.Windows.Forms.ComboBox();
            this.queryButton = new System.Windows.Forms.Button();
            this.fromTextBox = new System.Windows.Forms.TextBox();
            this.selectTextBox = new System.Windows.Forms.TextBox();
            this.selectLabel = new System.Windows.Forms.Label();
            this.resultDataGridView = new System.Windows.Forms.DataGridView();
            this.closeButton = new System.Windows.Forms.Button();
            this.resultGroupBox = new System.Windows.Forms.GroupBox();
            this.osLabel = new System.Windows.Forms.Label();
            this.paramGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resultDataGridView)).BeginInit();
            this.resultGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // paramGroupBox
            // 
            this.paramGroupBox.AutoSize = true;
            this.paramGroupBox.Controls.Add(this.osLabel);
            this.paramGroupBox.Controls.Add(this.maxTextBox);
            this.paramGroupBox.Controls.Add(this.maxCheckBox);
            this.paramGroupBox.Controls.Add(this.whereTextBox);
            this.paramGroupBox.Controls.Add(this.whereLabel);
            this.paramGroupBox.Controls.Add(this.fromLabel);
            this.paramGroupBox.Controls.Add(this.clearbutton);
            this.paramGroupBox.Controls.Add(this.statusLabel);
            this.paramGroupBox.Controls.Add(this.osComboBox);
            this.paramGroupBox.Controls.Add(this.queryButton);
            this.paramGroupBox.Controls.Add(this.fromTextBox);
            this.paramGroupBox.Controls.Add(this.selectTextBox);
            this.paramGroupBox.Controls.Add(this.selectLabel);
            this.paramGroupBox.Location = new System.Drawing.Point(1, -1);
            this.paramGroupBox.Name = "paramGroupBox";
            this.paramGroupBox.Size = new System.Drawing.Size(404, 216);
            this.paramGroupBox.TabIndex = 20;
            this.paramGroupBox.TabStop = false;
            this.paramGroupBox.Text = "Query Parameters";
            // 
            // maxTextBox
            // 
            this.maxTextBox.Location = new System.Drawing.Point(112, 146);
            this.maxTextBox.Name = "maxTextBox";
            this.maxTextBox.Size = new System.Drawing.Size(58, 20);
            this.maxTextBox.TabIndex = 22;
            // 
            // maxCheckBox
            // 
            this.maxCheckBox.AutoSize = true;
            this.maxCheckBox.Location = new System.Drawing.Point(6, 148);
            this.maxCheckBox.Name = "maxCheckBox";
            this.maxCheckBox.Size = new System.Drawing.Size(76, 17);
            this.maxCheckBox.TabIndex = 21;
            this.maxCheckBox.Text = "Max Rows";
            this.maxCheckBox.UseVisualStyleBackColor = true;
            // 
            // whereTextBox
            // 
            this.whereTextBox.Location = new System.Drawing.Point(112, 115);
            this.whereTextBox.Name = "whereTextBox";
            this.whereTextBox.Size = new System.Drawing.Size(250, 20);
            this.whereTextBox.TabIndex = 20;
            // 
            // whereLabel
            // 
            this.whereLabel.AutoSize = true;
            this.whereLabel.Location = new System.Drawing.Point(3, 118);
            this.whereLabel.Name = "whereLabel";
            this.whereLabel.Size = new System.Drawing.Size(48, 13);
            this.whereLabel.TabIndex = 19;
            this.whereLabel.Text = "WHERE";
            // 
            // fromLabel
            // 
            this.fromLabel.AutoSize = true;
            this.fromLabel.Location = new System.Drawing.Point(3, 87);
            this.fromLabel.Name = "fromLabel";
            this.fromLabel.Size = new System.Drawing.Size(38, 13);
            this.fromLabel.TabIndex = 18;
            this.fromLabel.Text = "FROM";
            // 
            // clearbutton
            // 
            this.clearbutton.Location = new System.Drawing.Point(287, 142);
            this.clearbutton.Name = "clearbutton";
            this.clearbutton.Size = new System.Drawing.Size(75, 23);
            this.clearbutton.TabIndex = 17;
            this.clearbutton.Text = "Clear";
            this.clearbutton.UseVisualStyleBackColor = true;
            this.clearbutton.Click += new System.EventHandler(this.clearbutton_Click);
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusLabel.Location = new System.Drawing.Point(3, 187);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(142, 13);
            this.statusLabel.TabIndex = 16;
            this.statusLabel.Text = "Click Query to query CE";
            // 
            // osComboBox
            // 
            this.osComboBox.FormattingEnabled = true;
            this.osComboBox.Location = new System.Drawing.Point(112, 18);
            this.osComboBox.Name = "osComboBox";
            this.osComboBox.Size = new System.Drawing.Size(206, 21);
            this.osComboBox.TabIndex = 1;
            // 
            // queryButton
            // 
            this.queryButton.Location = new System.Drawing.Point(193, 142);
            this.queryButton.Name = "queryButton";
            this.queryButton.Size = new System.Drawing.Size(75, 23);
            this.queryButton.TabIndex = 15;
            this.queryButton.Text = "Query";
            this.queryButton.UseVisualStyleBackColor = true;
            this.queryButton.Click += new System.EventHandler(this.queryButton_Click);
            // 
            // fromTextBox
            // 
            this.fromTextBox.Location = new System.Drawing.Point(112, 84);
            this.fromTextBox.Name = "fromTextBox";
            this.fromTextBox.Size = new System.Drawing.Size(250, 20);
            this.fromTextBox.TabIndex = 13;
            // 
            // selectTextBox
            // 
            this.selectTextBox.Location = new System.Drawing.Point(112, 52);
            this.selectTextBox.Name = "selectTextBox";
            this.selectTextBox.Size = new System.Drawing.Size(250, 20);
            this.selectTextBox.TabIndex = 11;
            // 
            // selectLabel
            // 
            this.selectLabel.AutoSize = true;
            this.selectLabel.Location = new System.Drawing.Point(3, 55);
            this.selectLabel.Name = "selectLabel";
            this.selectLabel.Size = new System.Drawing.Size(48, 13);
            this.selectLabel.TabIndex = 10;
            this.selectLabel.Text = "SELECT";
            // 
            // resultDataGridView
            // 
            this.resultDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.resultDataGridView.Location = new System.Drawing.Point(3, 16);
            this.resultDataGridView.Name = "resultDataGridView";
            this.resultDataGridView.Size = new System.Drawing.Size(398, 162);
            this.resultDataGridView.TabIndex = 21;
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(170, 404);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 22;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // resultGroupBox
            // 
            this.resultGroupBox.Controls.Add(this.resultDataGridView);
            this.resultGroupBox.Location = new System.Drawing.Point(1, 217);
            this.resultGroupBox.Name = "resultGroupBox";
            this.resultGroupBox.Size = new System.Drawing.Size(404, 181);
            this.resultGroupBox.TabIndex = 23;
            this.resultGroupBox.TabStop = false;
            this.resultGroupBox.Text = "Query Result";
            // 
            // osLabel
            // 
            this.osLabel.AutoSize = true;
            this.osLabel.Location = new System.Drawing.Point(3, 21);
            this.osLabel.Name = "osLabel";
            this.osLabel.Size = new System.Drawing.Size(55, 13);
            this.osLabel.TabIndex = 24;
            this.osLabel.Text = "Select OS";
            // 
            // AdhocQueryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(407, 430);
            this.Controls.Add(this.resultGroupBox);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.paramGroupBox);
            this.Name = "AdhocQueryForm";
            this.Text = "AdhocQuery";
            this.Load += new System.EventHandler(this.AdhocQueryForm_Load);
            this.paramGroupBox.ResumeLayout(false);
            this.paramGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resultDataGridView)).EndInit();
            this.resultGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox paramGroupBox;
        private System.Windows.Forms.CheckBox maxCheckBox;
        private System.Windows.Forms.TextBox whereTextBox;
        private System.Windows.Forms.Label whereLabel;
        private System.Windows.Forms.Label fromLabel;
        private System.Windows.Forms.Button clearbutton;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.ComboBox osComboBox;
        private System.Windows.Forms.Button queryButton;
        private System.Windows.Forms.TextBox fromTextBox;
        private System.Windows.Forms.TextBox selectTextBox;
        private System.Windows.Forms.Label selectLabel;
        private System.Windows.Forms.TextBox maxTextBox;
        private System.Windows.Forms.DataGridView resultDataGridView;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.GroupBox resultGroupBox;
        private System.Windows.Forms.Label osLabel;




    }
}