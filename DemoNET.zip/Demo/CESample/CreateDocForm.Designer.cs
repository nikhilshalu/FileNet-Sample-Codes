namespace CESample
{
    partial class CreateDocForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.osComboBox = new System.Windows.Forms.ComboBox();
            this.titleLabel = new System.Windows.Forms.Label();
            this.titleTextBox = new System.Windows.Forms.TextBox();
            this.contentCheckBox = new System.Windows.Forms.CheckBox();
            this.contentTextBox = new System.Windows.Forms.TextBox();
            this.browseButton = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.mimeLabel = new System.Windows.Forms.Label();
            this.mimeTextBox = new System.Windows.Forms.TextBox();
            this.classLabel = new System.Windows.Forms.Label();
            this.classTextBox = new System.Windows.Forms.TextBox();
            this.fileCheckBox = new System.Windows.Forms.CheckBox();
            this.fileTextBox = new System.Windows.Forms.TextBox();
            this.checkinCheckBox = new System.Windows.Forms.CheckBox();
            this.createButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.paramGroupBox = new System.Windows.Forms.GroupBox();
            this.checkInLabel = new System.Windows.Forms.Label();
            this.fileLabel = new System.Windows.Forms.Label();
            this.folderNameLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.osLabel = new System.Windows.Forms.Label();
            this.clearbutton = new System.Windows.Forms.Button();
            this.statusLabel = new System.Windows.Forms.Label();
            this.paramGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // osComboBox
            // 
            this.osComboBox.FormattingEnabled = true;
            this.osComboBox.Location = new System.Drawing.Point(123, 18);
            this.osComboBox.Name = "osComboBox";
            this.osComboBox.Size = new System.Drawing.Size(186, 21);
            this.osComboBox.TabIndex = 1;
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(3, 52);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(79, 13);
            this.titleLabel.TabIndex = 3;
            this.titleLabel.Text = "DocumentTitle:";
            // 
            // titleTextBox
            // 
            this.titleTextBox.Location = new System.Drawing.Point(123, 49);
            this.titleTextBox.Name = "titleTextBox";
            this.titleTextBox.Size = new System.Drawing.Size(186, 20);
            this.titleTextBox.TabIndex = 4;
            // 
            // contentCheckBox
            // 
            this.contentCheckBox.AutoSize = true;
            this.contentCheckBox.Location = new System.Drawing.Point(6, 80);
            this.contentCheckBox.Name = "contentCheckBox";
            this.contentCheckBox.Size = new System.Drawing.Size(15, 14);
            this.contentCheckBox.TabIndex = 5;
            this.contentCheckBox.UseVisualStyleBackColor = true;
            // 
            // contentTextBox
            // 
            this.contentTextBox.Location = new System.Drawing.Point(123, 77);
            this.contentTextBox.Name = "contentTextBox";
            this.contentTextBox.Size = new System.Drawing.Size(186, 20);
            this.contentTextBox.TabIndex = 6;
            // 
            // browseButton
            // 
            this.browseButton.Location = new System.Drawing.Point(317, 75);
            this.browseButton.Name = "browseButton";
            this.browseButton.Size = new System.Drawing.Size(75, 23);
            this.browseButton.TabIndex = 7;
            this.browseButton.Text = "Browse";
            this.browseButton.UseVisualStyleBackColor = true;
            this.browseButton.Click += new System.EventHandler(this.browseButton_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog1";
            // 
            // mimeLabel
            // 
            this.mimeLabel.AutoSize = true;
            this.mimeLabel.Location = new System.Drawing.Point(3, 108);
            this.mimeLabel.Name = "mimeLabel";
            this.mimeLabel.Size = new System.Drawing.Size(62, 13);
            this.mimeLabel.TabIndex = 8;
            this.mimeLabel.Text = "Mime Type:";
            // 
            // mimeTextBox
            // 
            this.mimeTextBox.Location = new System.Drawing.Point(123, 105);
            this.mimeTextBox.Name = "mimeTextBox";
            this.mimeTextBox.Size = new System.Drawing.Size(186, 20);
            this.mimeTextBox.TabIndex = 9;
            this.mimeTextBox.Text = "text/plain";
            // 
            // classLabel
            // 
            this.classLabel.AutoSize = true;
            this.classLabel.Location = new System.Drawing.Point(3, 138);
            this.classLabel.Name = "classLabel";
            this.classLabel.Size = new System.Drawing.Size(87, 13);
            this.classLabel.TabIndex = 10;
            this.classLabel.Text = "Document Class:";
            // 
            // classTextBox
            // 
            this.classTextBox.Location = new System.Drawing.Point(123, 135);
            this.classTextBox.Name = "classTextBox";
            this.classTextBox.Size = new System.Drawing.Size(186, 20);
            this.classTextBox.TabIndex = 11;
            this.classTextBox.Text = "Document";
            // 
            // fileCheckBox
            // 
            this.fileCheckBox.AutoSize = true;
            this.fileCheckBox.Location = new System.Drawing.Point(123, 165);
            this.fileCheckBox.Name = "fileCheckBox";
            this.fileCheckBox.Size = new System.Drawing.Size(15, 14);
            this.fileCheckBox.TabIndex = 12;
            this.fileCheckBox.UseVisualStyleBackColor = true;
            // 
            // fileTextBox
            // 
            this.fileTextBox.Location = new System.Drawing.Point(123, 188);
            this.fileTextBox.Name = "fileTextBox";
            this.fileTextBox.Size = new System.Drawing.Size(186, 20);
            this.fileTextBox.TabIndex = 13;
            // 
            // checkinCheckBox
            // 
            this.checkinCheckBox.AutoSize = true;
            this.checkinCheckBox.Location = new System.Drawing.Point(123, 217);
            this.checkinCheckBox.Name = "checkinCheckBox";
            this.checkinCheckBox.Size = new System.Drawing.Size(15, 14);
            this.checkinCheckBox.TabIndex = 14;
            this.checkinCheckBox.UseVisualStyleBackColor = true;
            // 
            // createButton
            // 
            this.createButton.Location = new System.Drawing.Point(123, 288);
            this.createButton.Name = "createButton";
            this.createButton.Size = new System.Drawing.Size(75, 23);
            this.createButton.TabIndex = 15;
            this.createButton.Text = "Create";
            this.createButton.UseVisualStyleBackColor = true;
            this.createButton.Click += new System.EventHandler(this.createButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(166, 341);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 16;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // paramGroupBox
            // 
            this.paramGroupBox.AutoSize = true;
            this.paramGroupBox.Controls.Add(this.checkInLabel);
            this.paramGroupBox.Controls.Add(this.fileLabel);
            this.paramGroupBox.Controls.Add(this.folderNameLabel);
            this.paramGroupBox.Controls.Add(this.label1);
            this.paramGroupBox.Controls.Add(this.osLabel);
            this.paramGroupBox.Controls.Add(this.clearbutton);
            this.paramGroupBox.Controls.Add(this.statusLabel);
            this.paramGroupBox.Controls.Add(this.osComboBox);
            this.paramGroupBox.Controls.Add(this.checkinCheckBox);
            this.paramGroupBox.Controls.Add(this.createButton);
            this.paramGroupBox.Controls.Add(this.fileTextBox);
            this.paramGroupBox.Controls.Add(this.titleLabel);
            this.paramGroupBox.Controls.Add(this.fileCheckBox);
            this.paramGroupBox.Controls.Add(this.titleTextBox);
            this.paramGroupBox.Controls.Add(this.contentCheckBox);
            this.paramGroupBox.Controls.Add(this.contentTextBox);
            this.paramGroupBox.Controls.Add(this.classTextBox);
            this.paramGroupBox.Controls.Add(this.browseButton);
            this.paramGroupBox.Controls.Add(this.classLabel);
            this.paramGroupBox.Controls.Add(this.mimeLabel);
            this.paramGroupBox.Controls.Add(this.mimeTextBox);
            this.paramGroupBox.Location = new System.Drawing.Point(2, 5);
            this.paramGroupBox.Name = "paramGroupBox";
            this.paramGroupBox.Size = new System.Drawing.Size(402, 330);
            this.paramGroupBox.TabIndex = 17;
            this.paramGroupBox.TabStop = false;
            this.paramGroupBox.Text = "Document Parameters";
            // 
            // checkInLabel
            // 
            this.checkInLabel.AutoSize = true;
            this.checkInLabel.Location = new System.Drawing.Point(6, 217);
            this.checkInLabel.Name = "checkInLabel";
            this.checkInLabel.Size = new System.Drawing.Size(53, 13);
            this.checkInLabel.TabIndex = 23;
            this.checkInLabel.Text = "Check In:";
            // 
            // fileLabel
            // 
            this.fileLabel.AutoSize = true;
            this.fileLabel.Location = new System.Drawing.Point(3, 165);
            this.fileLabel.Name = "fileLabel";
            this.fileLabel.Size = new System.Drawing.Size(69, 13);
            this.fileLabel.TabIndex = 22;
            this.fileLabel.Text = "File in Folder:";
            // 
            // folderNameLabel
            // 
            this.folderNameLabel.AutoSize = true;
            this.folderNameLabel.Location = new System.Drawing.Point(3, 191);
            this.folderNameLabel.Name = "folderNameLabel";
            this.folderNameLabel.Size = new System.Drawing.Size(70, 13);
            this.folderNameLabel.TabIndex = 21;
            this.folderNameLabel.Text = "Folder Name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 20;
            this.label1.Text = "Include Content";
            // 
            // osLabel
            // 
            this.osLabel.AutoSize = true;
            this.osLabel.Location = new System.Drawing.Point(3, 21);
            this.osLabel.Name = "osLabel";
            this.osLabel.Size = new System.Drawing.Size(58, 13);
            this.osLabel.TabIndex = 18;
            this.osLabel.Text = "Select OS:";
            // 
            // clearbutton
            // 
            this.clearbutton.Location = new System.Drawing.Point(234, 288);
            this.clearbutton.Name = "clearbutton";
            this.clearbutton.Size = new System.Drawing.Size(75, 23);
            this.clearbutton.TabIndex = 17;
            this.clearbutton.Text = "Clear";
            this.clearbutton.UseVisualStyleBackColor = true;
            this.clearbutton.Click += new System.EventHandler(this.clearbutton_Click);
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusLabel.Location = new System.Drawing.Point(3, 256);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(190, 13);
            this.statusLabel.TabIndex = 16;
            this.statusLabel.Text = "Click Create to create document";
            // 
            // CreateDocForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(406, 376);
            this.Controls.Add(this.paramGroupBox);
            this.Controls.Add(this.closeButton);
            this.Name = "CreateDocForm";
            this.Text = "Create Document";
            this.Load += new System.EventHandler(this.CreateDocForm_Load);
            this.paramGroupBox.ResumeLayout(false);
            this.paramGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox osComboBox;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.TextBox titleTextBox;
        private System.Windows.Forms.CheckBox contentCheckBox;
        private System.Windows.Forms.TextBox contentTextBox;
        private System.Windows.Forms.Button browseButton;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.Label mimeLabel;
        private System.Windows.Forms.TextBox mimeTextBox;
        private System.Windows.Forms.Label classLabel;
        private System.Windows.Forms.TextBox classTextBox;
        private System.Windows.Forms.CheckBox fileCheckBox;
        private System.Windows.Forms.TextBox fileTextBox;
        private System.Windows.Forms.CheckBox checkinCheckBox;
        private System.Windows.Forms.Button createButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.GroupBox paramGroupBox;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.Button clearbutton;
        private System.Windows.Forms.Label osLabel;
        private System.Windows.Forms.Label folderNameLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label fileLabel;
        private System.Windows.Forms.Label checkInLabel;       
    }
}