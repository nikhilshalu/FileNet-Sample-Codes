namespace CESample
{
    partial class CreateFolderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.paramGroupBox = new System.Windows.Forms.GroupBox();
            this.osLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.createButton = new System.Windows.Forms.Button();
            this.statusLabel = new System.Windows.Forms.Label();
            this.osComboBox = new System.Windows.Forms.ComboBox();
            this.classTextBox = new System.Windows.Forms.TextBox();
            this.parentTextBox = new System.Windows.Forms.TextBox();
            this.classLabel = new System.Windows.Forms.Label();
            this.parentLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.closeButton = new System.Windows.Forms.Button();
            this.paramGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // paramGroupBox
            // 
            this.paramGroupBox.AutoSize = true;
            this.paramGroupBox.Controls.Add(this.osLabel);
            this.paramGroupBox.Controls.Add(this.clearButton);
            this.paramGroupBox.Controls.Add(this.createButton);
            this.paramGroupBox.Controls.Add(this.statusLabel);
            this.paramGroupBox.Controls.Add(this.osComboBox);
            this.paramGroupBox.Controls.Add(this.classTextBox);
            this.paramGroupBox.Controls.Add(this.parentTextBox);
            this.paramGroupBox.Controls.Add(this.classLabel);
            this.paramGroupBox.Controls.Add(this.parentLabel);
            this.paramGroupBox.Controls.Add(this.nameLabel);
            this.paramGroupBox.Controls.Add(this.nameTextBox);
            this.paramGroupBox.Location = new System.Drawing.Point(0, -1);
            this.paramGroupBox.Name = "paramGroupBox";
            this.paramGroupBox.Size = new System.Drawing.Size(380, 226);
            this.paramGroupBox.TabIndex = 0;
            this.paramGroupBox.TabStop = false;
            this.paramGroupBox.Text = "Folder Parameters";
            // 
            // osLabel
            // 
            this.osLabel.AutoSize = true;
            this.osLabel.Location = new System.Drawing.Point(7, 19);
            this.osLabel.Name = "osLabel";
            this.osLabel.Size = new System.Drawing.Size(58, 13);
            this.osLabel.TabIndex = 19;
            this.osLabel.Text = "Select OS:";
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(242, 184);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 10;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // createButton
            // 
            this.createButton.Location = new System.Drawing.Point(111, 184);
            this.createButton.Name = "createButton";
            this.createButton.Size = new System.Drawing.Size(75, 23);
            this.createButton.TabIndex = 9;
            this.createButton.Text = "Create";
            this.createButton.UseVisualStyleBackColor = true;
            this.createButton.Click += new System.EventHandler(this.createButton_Click);
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusLabel.Location = new System.Drawing.Point(7, 165);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(170, 13);
            this.statusLabel.TabIndex = 8;
            this.statusLabel.Text = "Click Create to create Folder";
            // 
            // osComboBox
            // 
            this.osComboBox.FormattingEnabled = true;
            this.osComboBox.Location = new System.Drawing.Point(111, 16);
            this.osComboBox.Name = "osComboBox";
            this.osComboBox.Size = new System.Drawing.Size(206, 21);
            this.osComboBox.TabIndex = 7;
            // 
            // classTextBox
            // 
            this.classTextBox.Location = new System.Drawing.Point(111, 124);
            this.classTextBox.Name = "classTextBox";
            this.classTextBox.Size = new System.Drawing.Size(100, 20);
            this.classTextBox.TabIndex = 6;
            this.classTextBox.Text = "Folder";
            // 
            // parentTextBox
            // 
            this.parentTextBox.Location = new System.Drawing.Point(111, 88);
            this.parentTextBox.Name = "parentTextBox";
            this.parentTextBox.Size = new System.Drawing.Size(206, 20);
            this.parentTextBox.TabIndex = 5;
            // 
            // classLabel
            // 
            this.classLabel.AutoSize = true;
            this.classLabel.Location = new System.Drawing.Point(7, 127);
            this.classLabel.Name = "classLabel";
            this.classLabel.Size = new System.Drawing.Size(67, 13);
            this.classLabel.TabIndex = 4;
            this.classLabel.Text = "Folder Class:";
            // 
            // parentLabel
            // 
            this.parentLabel.AutoSize = true;
            this.parentLabel.Location = new System.Drawing.Point(7, 91);
            this.parentLabel.Name = "parentLabel";
            this.parentLabel.Size = new System.Drawing.Size(73, 13);
            this.parentLabel.TabIndex = 3;
            this.parentLabel.Text = "Parent Folder:";
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(7, 54);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(38, 13);
            this.nameLabel.TabIndex = 2;
            this.nameLabel.Text = "Name:";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(111, 51);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(206, 20);
            this.nameTextBox.TabIndex = 1;
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(152, 228);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 1;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // CreateFolderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(381, 262);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.paramGroupBox);
            this.Name = "CreateFolderForm";
            this.Text = "Create Folder";
            this.Load += new System.EventHandler(this.CreateFolderForm_Load);
            this.paramGroupBox.ResumeLayout(false);
            this.paramGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox paramGroupBox;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Label classLabel;
        private System.Windows.Forms.Label parentLabel;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.ComboBox osComboBox;
        private System.Windows.Forms.TextBox classTextBox;
        private System.Windows.Forms.TextBox parentTextBox;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button createButton;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.Label osLabel;
    }
}