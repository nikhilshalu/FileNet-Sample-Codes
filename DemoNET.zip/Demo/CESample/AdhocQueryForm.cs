/*
       IBM grants you a nonexclusive copyright license to use all programming code 
	examples from which you can generate similar function tailored to your own 
	specific needs.

	All sample code is provided by IBM for illustrative purposes only.
	These examples have not been thoroughly tested under all conditions.  IBM, 
	therefore cannot guarantee or imply reliability, serviceability, or function of 
	these programs.

	All Programs or code component contained herein are provided to you �AS IS � 
	without any warranties of any kind.
	The implied warranties of non-infringement, merchantability and fitness for a 
	particular purpose are expressly disclaimed.

	� Copyright IBM Corporation 2007, ALL RIGHTS RESERVED.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using FileNet.Api.Core;
using FileNet.Api.Collection;
using System.Collections;
using FileNet.Api.Query;
using FileNet.Api.Exception;

namespace CESample
{
    //
    // Form with UI components to collect necessary information
    // to query CE.
    //
    public partial class AdhocQueryForm : Form
    {
        private CEConnection ce;

        //
        // Constructor
        //
        public AdhocQueryForm(CEConnection c)
        {
            ce = c;
            InitializeComponent();
        }

        //
        // Handles the event generated when 'Query' button is clicked.
        // It queries the CE and displays the return results.
        //
        private void queryButton_Click(object sender, EventArgs e)
        {
            String select = selectTextBox.Text;
            String from = fromTextBox.Text;
            String where = whereTextBox.Text;
            int rows = 0;
            try
            {
                if(CheckRequiredFields())
                {
                    IObjectStore os = (IObjectStore)ce.FetchOS((String)osComboBox.SelectedItem);
                    if (maxCheckBox.Checked)
                    {
                        if (!(maxTextBox.Text.Equals("")))
                            rows = Int32.Parse(maxTextBox.Text);
                    }
                    IRepositoryRowSet rrs = CEUtil.FetchResultRowSet(os, select, from, where, rows);
                    bool firstpass = true;
                    DataTable table = new DataTable();
                    IEnumerator ie = rrs.GetEnumerator();
                    while (ie.MoveNext())
                    {
                        IRepositoryRow rr = (IRepositoryRow)ie.Current;
                        if (firstpass)
                        {
                            ArrayList names = CEUtil.GetRowPropertiesName(rr);
                            for (int i = 0; i < names.Count; i++)
                                table.Columns.Add(new DataColumn((String)names[i]));
                            firstpass = false;
                        }
                        table.Rows.Add(CEUtil.GetResultRow(rr));
                    }
                    resultDataGridView.DataSource = table;
                    statusLabel.Text = "Query Performed successfully"; 
                }
            }
            catch (EngineRuntimeException ere)
            {
                statusLabel.Text = ere.Message;
                System.Console.WriteLine(ere.StackTrace);
            }
        }

        //
        // Handles the event generated when 'Clear' button is clicked.
        // Clears all the text fields, removes the table from 
        // resultDataGridView, and resets the status label.
        //
        private void clearbutton_Click(object sender, EventArgs e)
        {
            selectTextBox.Text = "";
            fromTextBox.Text = "";
            whereTextBox.Text = "";
            maxTextBox.Text = "";
            resultDataGridView.DataSource = null;
            statusLabel.Text = "Click Query to query CE";
        }

        //
        // Handles the event generated when 'Close' button is clicked.
        // Closes this Form.
        //
        private void closeButton_Click(object sender, EventArgs e)
        {
            base.Dispose();
        }

        //
        // Handles the event generated when this Form is loaded.
        // It populates the 'osComboBox' with names of the available
        // object stores.
        //
        private void AdhocQueryForm_Load(object sender, EventArgs e)
        {
            ArrayList osNames = ce.GetOSNames();
            osComboBox.Items.Clear();
            for (int i = 0; i < osNames.Count; i++)
            {
                osComboBox.Items.Add(osNames[i]);
            }
        }

        //
        // Checks whether all required fields are filled before 
        // performing any action.
        //
        private bool CheckRequiredFields()
        {
            bool check = true;
            if (osComboBox.SelectedItem == null)
            {
                statusLabel.Text = "Select Object Store from the ComboBox";
                check = false;
            }
            else
            {
                if(selectTextBox.Text.Equals(""))
                {
                    selectTextBox.Text = "Select field can not be empty.";
                    check = false;
                }
                if(fromTextBox.Text.Equals(""))
                {
                    fromTextBox.Text = "From field can not be empty.";
                    check = false;
                }
                if(maxCheckBox.Checked)
                {
                    if(maxTextBox.Text.Equals(""))
                    {
                        statusLabel.Text = "Max row field can not be empty.";
                        check = false;
                    }
                }
            }
            return check;
        }
    }
}