/*
       IBM grants you a nonexclusive copyright license to use all programming code 
	examples from which you can generate similar function tailored to your own 
	specific needs.

	All sample code is provided by IBM for illustrative purposes only.
	These examples have not been thoroughly tested under all conditions.  IBM, 
	therefore cannot guarantee or imply reliability, serviceability, or function of 
	these programs.

	All Programs or code component contained herein are provided to you �AS IS � 
	without any warranties of any kind.
	The implied warranties of non-infringement, merchantability and fitness for a 
	particular purpose are expressly disclaimed.

	� Copyright IBM Corporation 2007, ALL RIGHTS RESERVED.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using FileNet.Api.Exception;
using FileNet.Api.Core;
using FileNet.Api.Constants;

namespace CESample
{
    //
    // Form with UI components to collect necessary information
    // to create CompoundDocument.
    //
    public partial class CreateCompoundDocForm : Form
    {
        private CEConnection ce;
        
        //
        // Constructor
        //
        public CreateCompoundDocForm(CEConnection c)
        {
            ce = c;
            InitializeComponent();
        }

        //
        // Handles the event generated when 'Create' button is clicked.
        // Creates the CompoundDocument.
        //
        private void createButton_Click(object sender, EventArgs e)
        {
            String parent = parentTextBox.Text;
            String child = childTextBox.Text;
            try
            {
                if (CheckRequiredFields())
                {
                    IObjectStore os = ce.FetchOS((String)osComboBox.SelectedItem);
                    IComponentRelationship cr = CEUtil.CreateComponentRelationship(os, parent, child);
                    cr.Save(RefreshMode.REFRESH);
                    statusLabel.Text = "Compound Document with ID " + cr.Id + " created"; 
                }
            }
            catch (EngineRuntimeException ere)
            {
                statusLabel.Text = ere.Message;
                System.Console.WriteLine(ere.StackTrace);
            }
        }

        //
        // Handles the event generated when 'Clear' button is clicked.
        // Clears the text boxes and resets the status label.
        //
        private void clearbutton_Click(object sender, EventArgs e)
        {
            parentTextBox.Text = "";
            childTextBox.Text = "";
            statusLabel.Text = "Click Create to create CompoundDocument";
        }

        //
        // Handles the event generated when 'Close' button is clicked.
        // Closes this Form.
        //
        private void closeButton_Click(object sender, EventArgs e)
        {
            base.Dispose();
        }

        //
        // Handles the event generated when Form is loaded.
        // It populates the 'osComboBox' with names of the available
        // object stores.
        //
        private void CreateCompoundDocForm_Load(object sender, EventArgs e)
        {
            ArrayList osNames = ce.GetOSNames();
            osComboBox.Items.Clear();
            for (int i = 0; i < osNames.Count; i++)
            {
                osComboBox.Items.Add(osNames[i]);
            }
        }

        //
        // Checks whether all required fields are filled before 
        // performing any action.
        //
        private bool CheckRequiredFields()
        {
            bool check = true;
            if (osComboBox.SelectedItem == null)
            {
                statusLabel.Text = "Select Object Store from the ComboBox";
                check = false;
            }
            else
            {
                if (parentTextBox.Text.Equals(""))
                {
                    parentTextBox.Text = "Enter title for parent document.";
                    check = false;
                }
                if (childTextBox.Text.Equals(""))
                {
                    childTextBox.Text = "Enter title for child document.";
                    check = false;
                }
            }
            return check;
        }
    }
}