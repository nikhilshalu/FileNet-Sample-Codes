/*
       IBM grants you a nonexclusive copyright license to use all programming code 
	examples from which you can generate similar function tailored to your own 
	specific needs.

	All sample code is provided by IBM for illustrative purposes only.
	These examples have not been thoroughly tested under all conditions.  IBM, 
	therefore cannot guarantee or imply reliability, serviceability, or function of 
	these programs.

	All Programs or code component contained herein are provided to you �AS IS � 
	without any warranties of any kind.
	The implied warranties of non-infringement, merchantability and fitness for a 
	particular purpose are expressly disclaimed.

	� Copyright IBM Corporation 2007, ALL RIGHTS RESERVED.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using FileNet.Api.Core;
using FileNet.Api.Exception;

namespace CESample
{
    //
    // Form with UI components to collect necessary information
    // to fetch Document instance.
    //
    public partial class GetDocForm : Form
    {
        private CEConnection ce;

        //
        // Constructor
        //
        public GetDocForm(CEConnection c)
        {
            ce = c;
            InitializeComponent();
        }

        //
        // Handles the event generated when 'Browse' button is clicked.
        // Opens up the BrowserDialog, which lets user choose the folder
        // on a file system to store file with the content of fetched
        // Document instance.
        //
        private void browseButton_Click(object sender, EventArgs e)
        {
            folderBrowserDialog.ShowDialog();
            contentTextBox.Text = folderBrowserDialog.SelectedPath;
        }

        //
        // Handles the event generated when 'Close' button is clicked.
        // Closes this Form.
        //
        private void closeButton_Click(object sender, EventArgs e)
        {
            base.Dispose();
        }

        //
        // Handles the event generated when 'Get' button is clicked.
        // Fetches the Document instance and displays some of the
        // properties. If ACL checkbox is selected, the method also displays the
        // permissions of fetched instance. If 'content checkbox' is
        // selected, content of the fetched instance is stored in a
        // file in a file system folder selected by the user.
        //
        private void getButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (CheckRequiredFields())
                {
                    IObjectStore os = ce.FetchOS((String)osComboBox.SelectedItem);
                    IDocument doc = null;
                    if (idRadioButton.Checked)
                        doc = CEUtil.FetchDocByID(os, idTextBox.Text);
                    else if (pathRadioButton.Checked)
                        doc = CEUtil.FetchDocByPath(os, pathTextBox.Text);
                    statusLabel.Text = "Document Fetched";
                    Hashtable prop = CEUtil.GetContainableProperties(doc);
                    ArrayList keys = new ArrayList(prop.Keys);
                    resultListBox.Items.Clear();
                    resultListBox.Items.Add("--------------------------------");
                    resultListBox.Items.Add("Document Properties");
                    resultListBox.Items.Add("--------------------------------");
                    for (int i = 0; i < keys.Count; i++)
                    {
                        resultListBox.Items.Add(keys[i] + ":" + prop[keys[i]]);
                    }
                    if (aclCheckBox.Checked)
                    {
                        resultListBox.Items.Add("--------------------------------");
                        resultListBox.Items.Add("Document Permissions");
                        resultListBox.Items.Add("--------------------------------");
                        ArrayList per = CEUtil.GetContainablePermissions(doc);
                        for (int i = 0; i < per.Count; i++)
                        {
                            resultListBox.Items.Add(per[i]);
                            if ((i + 1) % 3 == 0)
                            {
                                resultListBox.Items.Add("" + '\n');
                            }
                        }
                    }
                    if (contentCheckBox.Checked)
                        CEUtil.WriteContentToFile(doc, contentTextBox.Text); 
                }
            }
            catch (EngineRuntimeException ere)
            {
                statusLabel.Text = ere.Message;
                System.Console.WriteLine(ere.StackTrace);
            }
        }

        //
        // Handles the event generated when 'Clear' button is clicked.
        // Clears the text boxes and list box, and resets the status label.
        //
        private void clearButton_Click(object sender, EventArgs e)
        {
            pathTextBox.Text = "";
            idTextBox.Text = "";
            contentTextBox.Text = "";
            resultListBox.Items.Clear();
            statusLabel.Text = "Click get to retrieve Document";
        }

        //
        // Handles the event generated when this Form is loaded.
        // It populates the 'osComboBox' with names of the available
        // object stores.
        //
        private void GetDocForm_Load(object sender, EventArgs e)
        {
            ArrayList osNames = ce.GetOSNames();
            osComboBox.Items.Clear();
            for (int i = 0; i < osNames.Count; i++)
            {
                osComboBox.Items.Add(osNames[i]);
            }
        }

        //
        // Checks whether all required fields are filled before 
        // performing any action.
        //
        private bool CheckRequiredFields()
        {
            bool check = true;
            if (osComboBox.SelectedItem == null)
            {
                statusLabel.Text = "Select Object Store from the ComboBox";
                check = false;
            }
            else
            {
                if (idRadioButton.Checked)
                {
                    if (idTextBox.Text.Equals(""))
                    {
                        idTextBox.Text = "Enter id.";
                        check = false;
                    }
                }
                else if (pathRadioButton.Checked)
                {
                    if (pathTextBox.Text.Equals(""))
                    {
                        pathTextBox.Text = "Enter path.";
                        check = false;
                    }
                }
                if (contentCheckBox.Checked)
                {
                    if (contentTextBox.Text.Equals(""))
                    {
                        contentTextBox.Text = "Can not be empty.";
                        check = false;
                    }
                }
            }
            return check;
        }
    }
}