/*
       IBM grants you a nonexclusive copyright license to use all programming code 
	examples from which you can generate similar function tailored to your own 
	specific needs.

	All sample code is provided by IBM for illustrative purposes only.
	These examples have not been thoroughly tested under all conditions.  IBM, 
	therefore cannot guarantee or imply reliability, serviceability, or function of 
	these programs.

	All Programs or code component contained herein are provided to you �AS IS � 
	without any warranties of any kind.
	The implied warranties of non-infringement, merchantability and fitness for a 
	particular purpose are expressly disclaimed.

	� Copyright IBM Corporation 2007, ALL RIGHTS RESERVED.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using FileNet.Api.Core;
using FileNet.Api.Constants;
using FileNet.Api.Exception;
using System.Collections;

namespace CESample
{
    //
    // Form with UI components to collect necessary information
    // to create Folder.
    //
    public partial class CreateFolderForm : Form
    {
        private CEConnection ce;

        //
        // Constructor
        //
        public CreateFolderForm(CEConnection c)
        {
            ce = c;
            InitializeComponent();
        }

        //
        // Handles the event generated when 'Close' button is clicked.
        // Closes this Form.
        //
        private void closeButton_Click(object sender, EventArgs e)
        {
            base.Dispose();
        }

        //
        // Handles the event generated when 'Clear' button is clicked.
        // Clears the text boxes and resets the status label.
        //
        private void clearButton_Click(object sender, EventArgs e)
        {
            nameTextBox.Text = "";
            parentTextBox.Text = "";
            classTextBox.Text = "Folder";
            statusLabel.Text = "Click Create to create Folder";
        }

        //
        // Handles the event generated when 'Create' button is clicked.
        // Creates the Folder instance.
        //
        private void createButton_Click(object sender, EventArgs e)
        {
            String fPath = parentTextBox.Text;
            String fName = nameTextBox.Text;
            String className = classTextBox.Text;
            try
            {
                if (CheckRequiredFields())
                {
                    IObjectStore os = ce.FetchOS((String)osComboBox.SelectedItem);
                    IFolder nf = CEUtil.CreateFolder(os, fPath, fName, className);
                    nf.Save(RefreshMode.REFRESH);
                    statusLabel.Text = "Folder " + fName + " created"; 
                }
            }
            catch (EngineRuntimeException ere)
            {
                statusLabel.Text = ere.Message;
                System.Console.WriteLine(ere.StackTrace);
            }
        }

        //
        // Handles the event generated when Form is loaded.
        // It populates the 'osComboBox' with names of the available
        // object stores.
        //
        private void CreateFolderForm_Load(object sender, EventArgs e)
        {
            ArrayList osNames = ce.GetOSNames();
            osComboBox.Items.Clear();
            for (int i = 0; i < osNames.Count; i++)
            {
                osComboBox.Items.Add(osNames[i]);
            }
        }

        //
        // Checks whether all required fields are filled before 
        // performing any action.
        //
        private bool CheckRequiredFields()
        {
            bool check = true;
            if (osComboBox.SelectedItem == null)
            {
                statusLabel.Text = "Select Object Store from the ComboBox";
                check = false;
            }
            else
            {
                if (nameTextBox.Text.Equals(""))
                {
                    nameTextBox.Text = "Name field can not be empty.";
                    check = false;
                }
                if (parentTextBox.Text.Equals(""))
                {
                    parentTextBox.Text = "Enter parent folder path.";
                    check = false;
                }
            }
            return check;
        }
    }
}