namespace CESample
{
    partial class CreateCustomObjectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.paramGroupBox = new System.Windows.Forms.GroupBox();
            this.clearbutton = new System.Windows.Forms.Button();
            this.statusLabel = new System.Windows.Forms.Label();
            this.osComboBox = new System.Windows.Forms.ComboBox();
            this.createButton = new System.Windows.Forms.Button();
            this.fileTextBox = new System.Windows.Forms.TextBox();
            this.fileCheckBox = new System.Windows.Forms.CheckBox();
            this.classTextBox = new System.Windows.Forms.TextBox();
            this.classLabel = new System.Windows.Forms.Label();
            this.closeButton = new System.Windows.Forms.Button();
            this.osLabel = new System.Windows.Forms.Label();
            this.paramGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // paramGroupBox
            // 
            this.paramGroupBox.AutoSize = true;
            this.paramGroupBox.Controls.Add(this.osLabel);
            this.paramGroupBox.Controls.Add(this.clearbutton);
            this.paramGroupBox.Controls.Add(this.statusLabel);
            this.paramGroupBox.Controls.Add(this.osComboBox);
            this.paramGroupBox.Controls.Add(this.createButton);
            this.paramGroupBox.Controls.Add(this.fileTextBox);
            this.paramGroupBox.Controls.Add(this.fileCheckBox);
            this.paramGroupBox.Controls.Add(this.classTextBox);
            this.paramGroupBox.Controls.Add(this.classLabel);
            this.paramGroupBox.Location = new System.Drawing.Point(1, 3);
            this.paramGroupBox.Name = "paramGroupBox";
            this.paramGroupBox.Size = new System.Drawing.Size(428, 164);
            this.paramGroupBox.TabIndex = 18;
            this.paramGroupBox.TabStop = false;
            this.paramGroupBox.Text = "CustomObject Parameters";
            // 
            // clearbutton
            // 
            this.clearbutton.Location = new System.Drawing.Point(345, 91);
            this.clearbutton.Name = "clearbutton";
            this.clearbutton.Size = new System.Drawing.Size(75, 23);
            this.clearbutton.TabIndex = 17;
            this.clearbutton.Text = "Clear";
            this.clearbutton.UseVisualStyleBackColor = true;
            this.clearbutton.Click += new System.EventHandler(this.clearbutton_Click);
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusLabel.Location = new System.Drawing.Point(3, 132);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(213, 13);
            this.statusLabel.TabIndex = 16;
            this.statusLabel.Text = "Click Create to create CustomObject";
            // 
            // osComboBox
            // 
            this.osComboBox.FormattingEnabled = true;
            this.osComboBox.Location = new System.Drawing.Point(91, 18);
            this.osComboBox.Name = "osComboBox";
            this.osComboBox.Size = new System.Drawing.Size(186, 21);
            this.osComboBox.TabIndex = 1;
            // 
            // createButton
            // 
            this.createButton.Location = new System.Drawing.Point(345, 53);
            this.createButton.Name = "createButton";
            this.createButton.Size = new System.Drawing.Size(75, 23);
            this.createButton.TabIndex = 15;
            this.createButton.Text = "Create";
            this.createButton.UseVisualStyleBackColor = true;
            this.createButton.Click += new System.EventHandler(this.createButton_Click);
            // 
            // fileTextBox
            // 
            this.fileTextBox.Location = new System.Drawing.Point(91, 94);
            this.fileTextBox.Name = "fileTextBox";
            this.fileTextBox.Size = new System.Drawing.Size(186, 20);
            this.fileTextBox.TabIndex = 13;
            // 
            // fileCheckBox
            // 
            this.fileCheckBox.AutoSize = true;
            this.fileCheckBox.Location = new System.Drawing.Point(6, 96);
            this.fileCheckBox.Name = "fileCheckBox";
            this.fileCheckBox.Size = new System.Drawing.Size(85, 17);
            this.fileCheckBox.TabIndex = 12;
            this.fileCheckBox.Text = "File in Folder";
            this.fileCheckBox.UseVisualStyleBackColor = true;
            // 
            // classTextBox
            // 
            this.classTextBox.Location = new System.Drawing.Point(91, 56);
            this.classTextBox.Name = "classTextBox";
            this.classTextBox.Size = new System.Drawing.Size(186, 20);
            this.classTextBox.TabIndex = 11;
            this.classTextBox.Text = "CustomObject";
            // 
            // classLabel
            // 
            this.classLabel.AutoSize = true;
            this.classLabel.Location = new System.Drawing.Point(3, 59);
            this.classLabel.Name = "classLabel";
            this.classLabel.Size = new System.Drawing.Size(66, 13);
            this.classLabel.TabIndex = 10;
            this.classLabel.Text = "Object Class";
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(177, 173);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 19;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // osLabel
            // 
            this.osLabel.AutoSize = true;
            this.osLabel.Location = new System.Drawing.Point(3, 21);
            this.osLabel.Name = "osLabel";
            this.osLabel.Size = new System.Drawing.Size(55, 13);
            this.osLabel.TabIndex = 20;
            this.osLabel.Text = "Select OS";
            // 
            // CreateCustomObjectForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(430, 200);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.paramGroupBox);
            this.Name = "CreateCustomObjectForm";
            this.Text = "Create CustomObject";
            this.Load += new System.EventHandler(this.CreateCustomObjectForm_Load);
            this.paramGroupBox.ResumeLayout(false);
            this.paramGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox paramGroupBox;
        private System.Windows.Forms.Button clearbutton;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.ComboBox osComboBox;
        private System.Windows.Forms.Button createButton;
        private System.Windows.Forms.TextBox fileTextBox;
        private System.Windows.Forms.CheckBox fileCheckBox;
        private System.Windows.Forms.TextBox classTextBox;
        private System.Windows.Forms.Label classLabel;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Label osLabel;
    }
}