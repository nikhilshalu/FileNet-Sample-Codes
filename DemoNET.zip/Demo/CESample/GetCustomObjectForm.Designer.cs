namespace CESample
{
    partial class GetCustomObjectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.paramGroupBox = new System.Windows.Forms.GroupBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.radioGroupBox = new System.Windows.Forms.GroupBox();
            this.pathRadioButton = new System.Windows.Forms.RadioButton();
            this.idTextBox = new System.Windows.Forms.TextBox();
            this.idRadioButton = new System.Windows.Forms.RadioButton();
            this.pathTextBox = new System.Windows.Forms.TextBox();
            this.statusLabel = new System.Windows.Forms.Label();
            this.getButton = new System.Windows.Forms.Button();
            this.osComboBox = new System.Windows.Forms.ComboBox();
            this.resultGroupBox = new System.Windows.Forms.GroupBox();
            this.resultListBox = new System.Windows.Forms.ListBox();
            this.closeButton = new System.Windows.Forms.Button();
            this.osLabel = new System.Windows.Forms.Label();
            this.paramGroupBox.SuspendLayout();
            this.radioGroupBox.SuspendLayout();
            this.resultGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // paramGroupBox
            // 
            this.paramGroupBox.AutoSize = true;
            this.paramGroupBox.Controls.Add(this.osLabel);
            this.paramGroupBox.Controls.Add(this.clearButton);
            this.paramGroupBox.Controls.Add(this.radioGroupBox);
            this.paramGroupBox.Controls.Add(this.statusLabel);
            this.paramGroupBox.Controls.Add(this.getButton);
            this.paramGroupBox.Controls.Add(this.osComboBox);
            this.paramGroupBox.Location = new System.Drawing.Point(1, 0);
            this.paramGroupBox.Name = "paramGroupBox";
            this.paramGroupBox.Size = new System.Drawing.Size(382, 184);
            this.paramGroupBox.TabIndex = 1;
            this.paramGroupBox.TabStop = false;
            this.paramGroupBox.Text = "CustomObject Parameters";
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(301, 114);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 13;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // radioGroupBox
            // 
            this.radioGroupBox.Controls.Add(this.pathRadioButton);
            this.radioGroupBox.Controls.Add(this.idTextBox);
            this.radioGroupBox.Controls.Add(this.idRadioButton);
            this.radioGroupBox.Controls.Add(this.pathTextBox);
            this.radioGroupBox.Location = new System.Drawing.Point(6, 42);
            this.radioGroupBox.Name = "radioGroupBox";
            this.radioGroupBox.Size = new System.Drawing.Size(370, 66);
            this.radioGroupBox.TabIndex = 12;
            this.radioGroupBox.TabStop = false;
            // 
            // pathRadioButton
            // 
            this.pathRadioButton.AutoSize = true;
            this.pathRadioButton.Location = new System.Drawing.Point(11, 13);
            this.pathRadioButton.Name = "pathRadioButton";
            this.pathRadioButton.Size = new System.Drawing.Size(62, 17);
            this.pathRadioButton.TabIndex = 2;
            this.pathRadioButton.TabStop = true;
            this.pathRadioButton.Text = "By Path";
            this.pathRadioButton.UseVisualStyleBackColor = true;
            // 
            // idTextBox
            // 
            this.idTextBox.Location = new System.Drawing.Point(101, 40);
            this.idTextBox.Name = "idTextBox";
            this.idTextBox.Size = new System.Drawing.Size(184, 20);
            this.idTextBox.TabIndex = 5;
            // 
            // idRadioButton
            // 
            this.idRadioButton.AutoSize = true;
            this.idRadioButton.Location = new System.Drawing.Point(11, 41);
            this.idRadioButton.Name = "idRadioButton";
            this.idRadioButton.Size = new System.Drawing.Size(51, 17);
            this.idRadioButton.TabIndex = 3;
            this.idRadioButton.TabStop = true;
            this.idRadioButton.Text = "By ID";
            this.idRadioButton.UseVisualStyleBackColor = true;
            // 
            // pathTextBox
            // 
            this.pathTextBox.Location = new System.Drawing.Point(101, 10);
            this.pathTextBox.Name = "pathTextBox";
            this.pathTextBox.Size = new System.Drawing.Size(184, 20);
            this.pathTextBox.TabIndex = 4;
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusLabel.Location = new System.Drawing.Point(8, 155);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(201, 13);
            this.statusLabel.TabIndex = 11;
            this.statusLabel.Text = "Click get to retrieve CustomObject";
            // 
            // getButton
            // 
            this.getButton.Location = new System.Drawing.Point(145, 114);
            this.getButton.Name = "getButton";
            this.getButton.Size = new System.Drawing.Size(75, 23);
            this.getButton.TabIndex = 10;
            this.getButton.Text = "Get";
            this.getButton.UseVisualStyleBackColor = true;
            this.getButton.Click += new System.EventHandler(this.getButton_Click);
            // 
            // osComboBox
            // 
            this.osComboBox.FormattingEnabled = true;
            this.osComboBox.Location = new System.Drawing.Point(101, 15);
            this.osComboBox.Name = "osComboBox";
            this.osComboBox.Size = new System.Drawing.Size(184, 21);
            this.osComboBox.TabIndex = 1;
            // 
            // resultGroupBox
            // 
            this.resultGroupBox.Controls.Add(this.resultListBox);
            this.resultGroupBox.Location = new System.Drawing.Point(1, 190);
            this.resultGroupBox.Name = "resultGroupBox";
            this.resultGroupBox.Size = new System.Drawing.Size(382, 120);
            this.resultGroupBox.TabIndex = 2;
            this.resultGroupBox.TabStop = false;
            this.resultGroupBox.Text = "CustomObject Properties";
            // 
            // resultListBox
            // 
            this.resultListBox.FormattingEnabled = true;
            this.resultListBox.Location = new System.Drawing.Point(6, 19);
            this.resultListBox.Name = "resultListBox";
            this.resultListBox.Size = new System.Drawing.Size(364, 95);
            this.resultListBox.TabIndex = 0;
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(146, 316);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 3;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // osLabel
            // 
            this.osLabel.AutoSize = true;
            this.osLabel.Location = new System.Drawing.Point(8, 18);
            this.osLabel.Name = "osLabel";
            this.osLabel.Size = new System.Drawing.Size(55, 13);
            this.osLabel.TabIndex = 21;
            this.osLabel.Text = "Select OS";
            // 
            // GetCustomObjectForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 344);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.resultGroupBox);
            this.Controls.Add(this.paramGroupBox);
            this.Name = "GetCustomObjectForm";
            this.Text = "Get CustomObject";
            this.Load += new System.EventHandler(this.GetCustomObjectForm_Load);
            this.paramGroupBox.ResumeLayout(false);
            this.paramGroupBox.PerformLayout();
            this.radioGroupBox.ResumeLayout(false);
            this.radioGroupBox.PerformLayout();
            this.resultGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox paramGroupBox;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.GroupBox radioGroupBox;
        private System.Windows.Forms.RadioButton pathRadioButton;
        private System.Windows.Forms.TextBox idTextBox;
        private System.Windows.Forms.RadioButton idRadioButton;
        private System.Windows.Forms.TextBox pathTextBox;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.Button getButton;
        private System.Windows.Forms.ComboBox osComboBox;
        private System.Windows.Forms.GroupBox resultGroupBox;
        private System.Windows.Forms.ListBox resultListBox;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Label osLabel;
    }
}