namespace CESample
{
    partial class CreateCompoundDocForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.paramGroupBox = new System.Windows.Forms.GroupBox();
            this.osLabel = new System.Windows.Forms.Label();
            this.childLabel = new System.Windows.Forms.Label();
            this.clearbutton = new System.Windows.Forms.Button();
            this.statusLabel = new System.Windows.Forms.Label();
            this.osComboBox = new System.Windows.Forms.ComboBox();
            this.createButton = new System.Windows.Forms.Button();
            this.childTextBox = new System.Windows.Forms.TextBox();
            this.parentTextBox = new System.Windows.Forms.TextBox();
            this.parentLabel = new System.Windows.Forms.Label();
            this.closeButton = new System.Windows.Forms.Button();
            this.paramGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // paramGroupBox
            // 
            this.paramGroupBox.AutoSize = true;
            this.paramGroupBox.Controls.Add(this.osLabel);
            this.paramGroupBox.Controls.Add(this.childLabel);
            this.paramGroupBox.Controls.Add(this.clearbutton);
            this.paramGroupBox.Controls.Add(this.statusLabel);
            this.paramGroupBox.Controls.Add(this.osComboBox);
            this.paramGroupBox.Controls.Add(this.createButton);
            this.paramGroupBox.Controls.Add(this.childTextBox);
            this.paramGroupBox.Controls.Add(this.parentTextBox);
            this.paramGroupBox.Controls.Add(this.parentLabel);
            this.paramGroupBox.Location = new System.Drawing.Point(2, 0);
            this.paramGroupBox.Name = "paramGroupBox";
            this.paramGroupBox.Size = new System.Drawing.Size(428, 150);
            this.paramGroupBox.TabIndex = 19;
            this.paramGroupBox.TabStop = false;
            this.paramGroupBox.Text = "CompoundDocument Parameters";
            // 
            // osLabel
            // 
            this.osLabel.AutoSize = true;
            this.osLabel.Location = new System.Drawing.Point(3, 21);
            this.osLabel.Name = "osLabel";
            this.osLabel.Size = new System.Drawing.Size(55, 13);
            this.osLabel.TabIndex = 22;
            this.osLabel.Text = "Select OS";
            // 
            // childLabel
            // 
            this.childLabel.AutoSize = true;
            this.childLabel.Location = new System.Drawing.Point(3, 87);
            this.childLabel.Name = "childLabel";
            this.childLabel.Size = new System.Drawing.Size(102, 13);
            this.childLabel.TabIndex = 18;
            this.childLabel.Text = "Child DocumentTitle";
            // 
            // clearbutton
            // 
            this.clearbutton.Location = new System.Drawing.Point(345, 81);
            this.clearbutton.Name = "clearbutton";
            this.clearbutton.Size = new System.Drawing.Size(75, 23);
            this.clearbutton.TabIndex = 17;
            this.clearbutton.Text = "Clear";
            this.clearbutton.UseVisualStyleBackColor = true;
            this.clearbutton.Click += new System.EventHandler(this.clearbutton_Click);
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusLabel.Location = new System.Drawing.Point(3, 121);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(251, 13);
            this.statusLabel.TabIndex = 16;
            this.statusLabel.Text = "Click Create to create CompoundDocument";
            // 
            // osComboBox
            // 
            this.osComboBox.FormattingEnabled = true;
            this.osComboBox.Location = new System.Drawing.Point(132, 18);
            this.osComboBox.Name = "osComboBox";
            this.osComboBox.Size = new System.Drawing.Size(186, 21);
            this.osComboBox.TabIndex = 1;
            // 
            // createButton
            // 
            this.createButton.Location = new System.Drawing.Point(345, 49);
            this.createButton.Name = "createButton";
            this.createButton.Size = new System.Drawing.Size(75, 23);
            this.createButton.TabIndex = 15;
            this.createButton.Text = "Create";
            this.createButton.UseVisualStyleBackColor = true;
            this.createButton.Click += new System.EventHandler(this.createButton_Click);
            // 
            // childTextBox
            // 
            this.childTextBox.Location = new System.Drawing.Point(132, 84);
            this.childTextBox.Name = "childTextBox";
            this.childTextBox.Size = new System.Drawing.Size(186, 20);
            this.childTextBox.TabIndex = 13;
            // 
            // parentTextBox
            // 
            this.parentTextBox.Location = new System.Drawing.Point(132, 52);
            this.parentTextBox.Name = "parentTextBox";
            this.parentTextBox.Size = new System.Drawing.Size(186, 20);
            this.parentTextBox.TabIndex = 11;
            // 
            // parentLabel
            // 
            this.parentLabel.AutoSize = true;
            this.parentLabel.Location = new System.Drawing.Point(3, 54);
            this.parentLabel.Name = "parentLabel";
            this.parentLabel.Size = new System.Drawing.Size(110, 13);
            this.parentLabel.TabIndex = 10;
            this.parentLabel.Text = "Parent DocumentTitle";
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(172, 156);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 20;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // CreateCompoundDocForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 187);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.paramGroupBox);
            this.Name = "CreateCompoundDocForm";
            this.Text = "Create CompoundDocument";
            this.Load += new System.EventHandler(this.CreateCompoundDocForm_Load);
            this.paramGroupBox.ResumeLayout(false);
            this.paramGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox paramGroupBox;
        private System.Windows.Forms.Label childLabel;
        private System.Windows.Forms.Button clearbutton;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.ComboBox osComboBox;
        private System.Windows.Forms.Button createButton;
        private System.Windows.Forms.TextBox childTextBox;
        private System.Windows.Forms.TextBox parentTextBox;
        private System.Windows.Forms.Label parentLabel;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Label osLabel;
    }
}