/*
       IBM grants you a nonexclusive copyright license to use all programming code 
	examples from which you can generate similar function tailored to your own 
	specific needs.

	All sample code is provided by IBM for illustrative purposes only.
	These examples have not been thoroughly tested under all conditions.  IBM, 
	therefore cannot guarantee or imply reliability, serviceability, or function of 
	these programs.

	All Programs or code component contained herein are provided to you �AS IS � 
	without any warranties of any kind.
	The implied warranties of non-infringement, merchantability and fitness for a 
	particular purpose are expressly disclaimed.

	� Copyright IBM Corporation 2007, ALL RIGHTS RESERVED.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using FileNet.Api.Exception;
using FileNet.Api.Core;

namespace CESample
{
    //
    // Form with UI components to collect necessary information
    // to fetch CompoundDocument instance.
    //
    public partial class GetCompoundDocForm : Form
    {
        private CEConnection ce;

        //
        // Constructor
        //
        public GetCompoundDocForm(CEConnection c)
        {
            ce = c;
            InitializeComponent();
        }

        //
        // Handles the event generated when 'Get' button is clicked.
        // Fetches the CompoundDocument instance (i.e. ComponenetRelationship)
        // and displays some of the properties of that instance.
        //
        private void getButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (CheckRequiredFields())
                {
                    IObjectStore os = ce.FetchOS((String)osComboBox.SelectedItem);
                    String id = idTextBox.Text;
                    IComponentRelationship cr = CEUtil.FetchComponenetRelationship(os, id);
                    statusLabel.Text = "CompoundDocument retrieved";
                    resultListBox.Items.Clear();
                    Hashtable prop = CEUtil.GetComponentRelationshipProperties(cr);
                    ArrayList keys = new ArrayList(prop.Keys);
                    for (int i = 0; i < keys.Count; i++)
                    {
                        resultListBox.Items.Add(keys[i] + ":" + prop[keys[i]]);
                    } 
                }
            }
            catch (EngineRuntimeException ere)
            {
                statusLabel.Text = ere.Message;
                System.Console.WriteLine(ere.StackTrace);
            }
        }

        //
        // Handles the event generated when 'Clear' button is clicked.
        // Clears the text box and listbox, and resets the status label.
        //
        private void clearButton_Click(object sender, EventArgs e)
        {
            idTextBox.Text = "";
            resultListBox.Items.Clear();
            statusLabel.Text = "Click Get to retrieve CompoundDocument";
        }

        //
        // Handles the event generated when 'Close' button is clicked.
        // Closes this Form.
        //
        private void closeButton_Click(object sender, EventArgs e)
        {
            base.Dispose();
        }

        //
        // Handles the event generated when Form is loaded.
        // It populates the 'osComboBox' with names of the available
        // object stores.
        //
        private void GetCompoundDocForm_Load(object sender, EventArgs e)
        {
            ArrayList osNames = ce.GetOSNames();
            osComboBox.Items.Clear();
            for (int i = 0; i < osNames.Count; i++)
            {
                osComboBox.Items.Add(osNames[i]);
            }
        }

        //
        // Checks whether all required fields are filled before 
        // performing any action.
        //
        private bool CheckRequiredFields()
        {
            bool check = true;
            if (osComboBox.SelectedItem == null)
            {
                statusLabel.Text = "Select Object Store from the ComboBox";
                check = false;
            }
            else
            {
                if (idTextBox.Text.Equals(""))
                {
                    idTextBox.Text = "Enter id.";
                    check = false;
                }
            }
            return check;
        }
    }
}