/**
	IBM grants you a nonexclusive copyright license to use all programming code 
	examples from which you can generate similar function tailored to your own 
	specific needs.

	All sample code is provided by IBM for illustrative purposes only.
	These examples have not been thoroughly tested under all conditions.  IBM, 
	therefore cannot guarantee or imply reliability, serviceability, or function of 
	these programs.

	All Programs or code component contained herein are provided to you �AS IS � 
	without any warranties of any kind.
	The implied warranties of non-infringement, merchantability and fitness for a 
	particular purpose are expressly disclaimed.

	� Copyright IBM Corporation 2007, ALL RIGHTS RESERVED.
 */
 
package bulkloader;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 * Launches BulkLoader application.
 */
public class BulkLoaderLauncher
{
	/**
	 * Starts MainFrame, the primary UI class.
	 */
	public static void main(String[] args)
	{
		SwingUtilities.invokeLater(new Runnable()
			{
				public void run()
				{
					MainFrame thisClass = new MainFrame(new CEConnection());
					thisClass.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					thisClass.setVisible(true);
				}
			});
	}
}
