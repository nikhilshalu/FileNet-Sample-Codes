/*
       IBM grants you a nonexclusive copyright license to use all programming code 
	examples from which you can generate similar function tailored to your own 
	specific needs.

	All sample code is provided by IBM for illustrative purposes only.
	These examples have not been thoroughly tested under all conditions.  IBM, 
	therefore cannot guarantee or imply reliability, serviceability, or function of 
	these programs.

	All Programs or code component contained herein are provided to you �AS IS � 
	without any warranties of any kind.
	The implied warranties of non-infringement, merchantability and fitness for a 
	particular purpose are expressly disclaimed.

	� Copyright IBM Corporation 2007, ALL RIGHTS RESERVED.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BulkLoader
{
    //
    // Windows Form to display the status of
    // Document loading operation.
    //
    public partial class LoadStatusForm : Form
    {
        //
        // Constructor
        //
        public LoadStatusForm()
        {
            InitializeComponent();
        }

        //
        // Getter for the loadProgressBar.
        //
        public ProgressBar LoadProgressBar
        {
            get
            {
                return loadProgressBar;
            }
        }

        //
        // Getter for the statusTextBox.
        //
        public RichTextBox StatusTextBox
        {
            get
            {
                return statusTextBox;
            }
        }

        //
        // Handles the event generated when 'Close' button is clicked.
        // Closes this Form.
        // 
        private void closeButton_Click(object sender, EventArgs e)
        {
            base.Dispose();
        }
    }
}