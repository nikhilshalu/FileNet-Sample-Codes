namespace BulkLoader
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.connectionGroupBox = new System.Windows.Forms.GroupBox();
            this.statusLabel = new System.Windows.Forms.Label();
            this.connectionButton = new System.Windows.Forms.Button();
            this.passTextBox = new System.Windows.Forms.TextBox();
            this.userTextBox = new System.Windows.Forms.TextBox();
            this.uriTextBox = new System.Windows.Forms.TextBox();
            this.passLabel = new System.Windows.Forms.Label();
            this.userLabel = new System.Windows.Forms.Label();
            this.uriLabel = new System.Windows.Forms.Label();
            this.loaderButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.connectionGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // connectionGroupBox
            // 
            this.connectionGroupBox.Controls.Add(this.statusLabel);
            this.connectionGroupBox.Controls.Add(this.connectionButton);
            this.connectionGroupBox.Controls.Add(this.passTextBox);
            this.connectionGroupBox.Controls.Add(this.userTextBox);
            this.connectionGroupBox.Controls.Add(this.uriTextBox);
            this.connectionGroupBox.Controls.Add(this.passLabel);
            this.connectionGroupBox.Controls.Add(this.userLabel);
            this.connectionGroupBox.Controls.Add(this.uriLabel);
            this.connectionGroupBox.Location = new System.Drawing.Point(3, 2);
            this.connectionGroupBox.Name = "connectionGroupBox";
            this.connectionGroupBox.Size = new System.Drawing.Size(506, 150);
            this.connectionGroupBox.TabIndex = 1;
            this.connectionGroupBox.TabStop = false;
            this.connectionGroupBox.Text = "Connection Parameters";
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Location = new System.Drawing.Point(11, 134);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(292, 13);
            this.statusLabel.TabIndex = 7;
            this.statusLabel.Text = "Click Test Connection to verify connection to ContentEngine";
            // 
            // connectionButton
            // 
            this.connectionButton.Location = new System.Drawing.Point(208, 94);
            this.connectionButton.Name = "connectionButton";
            this.connectionButton.Size = new System.Drawing.Size(103, 23);
            this.connectionButton.TabIndex = 6;
            this.connectionButton.Text = "Test Connection";
            this.connectionButton.UseVisualStyleBackColor = true;
            this.connectionButton.Click += new System.EventHandler(this.connectionButton_Click);
            // 
            // passTextBox
            // 
            this.passTextBox.Location = new System.Drawing.Point(139, 68);
            this.passTextBox.Name = "passTextBox";
            this.passTextBox.Size = new System.Drawing.Size(354, 20);
            this.passTextBox.TabIndex = 5;
            // 
            // userTextBox
            // 
            this.userTextBox.Location = new System.Drawing.Point(139, 44);
            this.userTextBox.Name = "userTextBox";
            this.userTextBox.Size = new System.Drawing.Size(354, 20);
            this.userTextBox.TabIndex = 4;
            // 
            // uriTextBox
            // 
            this.uriTextBox.Location = new System.Drawing.Point(139, 17);
            this.uriTextBox.Name = "uriTextBox";
            this.uriTextBox.Size = new System.Drawing.Size(354, 20);
            this.uriTextBox.TabIndex = 3;
            this.uriTextBox.Text = "http://<localhost>:<port>/wsi/FNCEWS40MTOM/";
            // 
            // passLabel
            // 
            this.passLabel.AutoSize = true;
            this.passLabel.Location = new System.Drawing.Point(12, 75);
            this.passLabel.Name = "passLabel";
            this.passLabel.Size = new System.Drawing.Size(53, 13);
            this.passLabel.TabIndex = 2;
            this.passLabel.Text = "Password";
            // 
            // userLabel
            // 
            this.userLabel.AutoSize = true;
            this.userLabel.Location = new System.Drawing.Point(12, 47);
            this.userLabel.Name = "userLabel";
            this.userLabel.Size = new System.Drawing.Size(55, 13);
            this.userLabel.TabIndex = 1;
            this.userLabel.Text = "Username";
            // 
            // uriLabel
            // 
            this.uriLabel.AutoSize = true;
            this.uriLabel.Location = new System.Drawing.Point(12, 20);
            this.uriLabel.Name = "uriLabel";
            this.uriLabel.Size = new System.Drawing.Size(43, 13);
            this.uriLabel.TabIndex = 0;
            this.uriLabel.Text = "CE URI";
            // 
            // loaderButton
            // 
            this.loaderButton.Enabled = false;
            this.loaderButton.Location = new System.Drawing.Point(119, 158);
            this.loaderButton.Name = "loaderButton";
            this.loaderButton.Size = new System.Drawing.Size(120, 23);
            this.loaderButton.TabIndex = 2;
            this.loaderButton.Text = "Open BulkLoader";
            this.loaderButton.UseVisualStyleBackColor = true;
            this.loaderButton.Click += new System.EventHandler(this.browserButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(286, 158);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 3;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(512, 193);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.loaderButton);
            this.Controls.Add(this.connectionGroupBox);
            this.Name = "MainForm";
            this.Text = "Content Engine .NET API  BulkLoader";
            this.connectionGroupBox.ResumeLayout(false);
            this.connectionGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox connectionGroupBox;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.Button connectionButton;
        private System.Windows.Forms.TextBox passTextBox;
        private System.Windows.Forms.TextBox userTextBox;
        private System.Windows.Forms.TextBox uriTextBox;
        private System.Windows.Forms.Label passLabel;
        private System.Windows.Forms.Label userLabel;
        private System.Windows.Forms.Label uriLabel;
        private System.Windows.Forms.Button loaderButton;
        private System.Windows.Forms.Button closeButton;
    }
}

