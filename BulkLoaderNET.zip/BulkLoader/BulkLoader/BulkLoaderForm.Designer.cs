namespace BulkLoader
{
    partial class BulkLoaderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BulkLoaderForm));
            this.sourceGroupBox = new System.Windows.Forms.GroupBox();
            this.dirTreeView = new System.Windows.Forms.TreeView();
            this.iconImageList = new System.Windows.Forms.ImageList(this.components);
            this.dirComboBox = new System.Windows.Forms.ComboBox();
            this.destinationGroupBox = new System.Windows.Forms.GroupBox();
            this.refreshButton = new System.Windows.Forms.Button();
            this.osTreeView = new System.Windows.Forms.TreeView();
            this.osComboBox = new System.Windows.Forms.ComboBox();
            this.optionGroupBox = new System.Windows.Forms.GroupBox();
            this.closeButton = new System.Windows.Forms.Button();
            this.loadButton = new System.Windows.Forms.Button();
            this.exceptionTextBox = new System.Windows.Forms.RichTextBox();
            this.batchTextBox = new System.Windows.Forms.TextBox();
            this.batchLabel = new System.Windows.Forms.Label();
            this.includeCheckBox = new System.Windows.Forms.CheckBox();
            this.loaderSplitContainer = new System.Windows.Forms.SplitContainer();
            this.loaderSplitContainer1 = new System.Windows.Forms.SplitContainer();
            this.batchCheckBox = new System.Windows.Forms.CheckBox();
            this.sourceGroupBox.SuspendLayout();
            this.destinationGroupBox.SuspendLayout();
            this.optionGroupBox.SuspendLayout();
            this.loaderSplitContainer.Panel1.SuspendLayout();
            this.loaderSplitContainer.Panel2.SuspendLayout();
            this.loaderSplitContainer.SuspendLayout();
            this.loaderSplitContainer1.Panel1.SuspendLayout();
            this.loaderSplitContainer1.Panel2.SuspendLayout();
            this.loaderSplitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // sourceGroupBox
            // 
            this.sourceGroupBox.Controls.Add(this.dirTreeView);
            this.sourceGroupBox.Controls.Add(this.dirComboBox);
            this.sourceGroupBox.Location = new System.Drawing.Point(3, 3);
            this.sourceGroupBox.Name = "sourceGroupBox";
            this.sourceGroupBox.Size = new System.Drawing.Size(259, 332);
            this.sourceGroupBox.TabIndex = 2;
            this.sourceGroupBox.TabStop = false;
            this.sourceGroupBox.Text = "Choose Source Directory";
            // 
            // dirTreeView
            // 
            this.dirTreeView.HideSelection = false;
            this.dirTreeView.ImageIndex = 0;
            this.dirTreeView.ImageList = this.iconImageList;
            this.dirTreeView.Location = new System.Drawing.Point(6, 47);
            this.dirTreeView.Name = "dirTreeView";
            this.dirTreeView.SelectedImageIndex = 0;
            this.dirTreeView.Size = new System.Drawing.Size(247, 279);
            this.dirTreeView.TabIndex = 1;
            this.dirTreeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.dirTreeView_AfterSelect);
            // 
            // iconImageList
            // 
            this.iconImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("iconImageList.ImageStream")));
            this.iconImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.iconImageList.Images.SetKeyName(0, "folderclose.gif");
            this.iconImageList.Images.SetKeyName(1, "file.gif");
            this.iconImageList.Images.SetKeyName(2, "folderopen.gif");
            // 
            // dirComboBox
            // 
            this.dirComboBox.FormattingEnabled = true;
            this.dirComboBox.Location = new System.Drawing.Point(6, 20);
            this.dirComboBox.Name = "dirComboBox";
            this.dirComboBox.Size = new System.Drawing.Size(157, 21);
            this.dirComboBox.TabIndex = 0;
            this.dirComboBox.SelectedIndexChanged += new System.EventHandler(this.dirComboBox_SelectedIndexChanged);
            // 
            // destinationGroupBox
            // 
            this.destinationGroupBox.Controls.Add(this.refreshButton);
            this.destinationGroupBox.Controls.Add(this.osTreeView);
            this.destinationGroupBox.Controls.Add(this.osComboBox);
            this.destinationGroupBox.Location = new System.Drawing.Point(3, 3);
            this.destinationGroupBox.Name = "destinationGroupBox";
            this.destinationGroupBox.Size = new System.Drawing.Size(266, 336);
            this.destinationGroupBox.TabIndex = 3;
            this.destinationGroupBox.TabStop = false;
            this.destinationGroupBox.Text = "Choose Destination ObjectStore and Folder";
            // 
            // refreshButton
            // 
            this.refreshButton.Location = new System.Drawing.Point(85, 309);
            this.refreshButton.Name = "refreshButton";
            this.refreshButton.Size = new System.Drawing.Size(75, 23);
            this.refreshButton.TabIndex = 2;
            this.refreshButton.Text = "Refresh";
            this.refreshButton.UseVisualStyleBackColor = true;
            this.refreshButton.Click += new System.EventHandler(this.refreshButton_Click);
            // 
            // osTreeView
            // 
            this.osTreeView.HideSelection = false;
            this.osTreeView.ImageIndex = 0;
            this.osTreeView.ImageList = this.iconImageList;
            this.osTreeView.Location = new System.Drawing.Point(6, 47);
            this.osTreeView.Name = "osTreeView";
            this.osTreeView.SelectedImageIndex = 0;
            this.osTreeView.Size = new System.Drawing.Size(254, 256);
            this.osTreeView.TabIndex = 1;
            this.osTreeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.osTreeView_AfterSelect);
            // 
            // osComboBox
            // 
            this.osComboBox.FormattingEnabled = true;
            this.osComboBox.Location = new System.Drawing.Point(6, 20);
            this.osComboBox.Name = "osComboBox";
            this.osComboBox.Size = new System.Drawing.Size(225, 21);
            this.osComboBox.TabIndex = 0;
            this.osComboBox.SelectedIndexChanged += new System.EventHandler(this.osComboBox_SelectedIndexChanged);
            // 
            // optionGroupBox
            // 
            this.optionGroupBox.Controls.Add(this.batchCheckBox);
            this.optionGroupBox.Controls.Add(this.closeButton);
            this.optionGroupBox.Controls.Add(this.loadButton);
            this.optionGroupBox.Controls.Add(this.exceptionTextBox);
            this.optionGroupBox.Controls.Add(this.batchTextBox);
            this.optionGroupBox.Controls.Add(this.batchLabel);
            this.optionGroupBox.Controls.Add(this.includeCheckBox);
            this.optionGroupBox.Location = new System.Drawing.Point(3, 3);
            this.optionGroupBox.Name = "optionGroupBox";
            this.optionGroupBox.Size = new System.Drawing.Size(201, 336);
            this.optionGroupBox.TabIndex = 4;
            this.optionGroupBox.TabStop = false;
            this.optionGroupBox.Text = "Choose Options";
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(63, 303);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(69, 23);
            this.closeButton.TabIndex = 6;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // loadButton
            // 
            this.loadButton.Location = new System.Drawing.Point(6, 250);
            this.loadButton.Name = "loadButton";
            this.loadButton.Size = new System.Drawing.Size(75, 23);
            this.loadButton.TabIndex = 5;
            this.loadButton.Text = "Load";
            this.loadButton.UseVisualStyleBackColor = true;
            this.loadButton.Click += new System.EventHandler(this.loadButton_Click);
            // 
            // exceptionTextBox
            // 
            this.exceptionTextBox.Location = new System.Drawing.Point(6, 139);
            this.exceptionTextBox.Name = "exceptionTextBox";
            this.exceptionTextBox.Size = new System.Drawing.Size(180, 96);
            this.exceptionTextBox.TabIndex = 4;
            this.exceptionTextBox.Text = "";
            // 
            // batchTextBox
            // 
            this.batchTextBox.Location = new System.Drawing.Point(6, 104);
            this.batchTextBox.Name = "batchTextBox";
            this.batchTextBox.Size = new System.Drawing.Size(68, 20);
            this.batchTextBox.TabIndex = 3;
            // 
            // batchLabel
            // 
            this.batchLabel.AutoSize = true;
            this.batchLabel.Location = new System.Drawing.Point(6, 47);
            this.batchLabel.Name = "batchLabel";
            this.batchLabel.Size = new System.Drawing.Size(126, 13);
            this.batchLabel.TabIndex = 1;
            this.batchLabel.Text = "Batch Size (Default is 10)";
            // 
            // includeCheckBox
            // 
            this.includeCheckBox.AutoSize = true;
            this.includeCheckBox.Location = new System.Drawing.Point(6, 22);
            this.includeCheckBox.Name = "includeCheckBox";
            this.includeCheckBox.Size = new System.Drawing.Size(131, 17);
            this.includeCheckBox.TabIndex = 0;
            this.includeCheckBox.Text = "Include Subdirectories";
            this.includeCheckBox.UseVisualStyleBackColor = true;
            // 
            // loaderSplitContainer
            // 
            this.loaderSplitContainer.Location = new System.Drawing.Point(12, 2);
            this.loaderSplitContainer.Name = "loaderSplitContainer";
            // 
            // loaderSplitContainer.Panel1
            // 
            this.loaderSplitContainer.Panel1.Controls.Add(this.sourceGroupBox);
            // 
            // loaderSplitContainer.Panel2
            // 
            this.loaderSplitContainer.Panel2.Controls.Add(this.loaderSplitContainer1);
            this.loaderSplitContainer.Size = new System.Drawing.Size(746, 339);
            this.loaderSplitContainer.SplitterDistance = 262;
            this.loaderSplitContainer.TabIndex = 5;
            // 
            // loaderSplitContainer1
            // 
            this.loaderSplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.loaderSplitContainer1.Location = new System.Drawing.Point(0, 0);
            this.loaderSplitContainer1.Name = "loaderSplitContainer1";
            // 
            // loaderSplitContainer1.Panel1
            // 
            this.loaderSplitContainer1.Panel1.Controls.Add(this.destinationGroupBox);
            // 
            // loaderSplitContainer1.Panel2
            // 
            this.loaderSplitContainer1.Panel2.Controls.Add(this.optionGroupBox);
            this.loaderSplitContainer1.Size = new System.Drawing.Size(480, 339);
            this.loaderSplitContainer1.SplitterDistance = 270;
            this.loaderSplitContainer1.TabIndex = 0;
            // 
            // batchCheckBox
            // 
            this.batchCheckBox.AutoSize = true;
            this.batchCheckBox.Location = new System.Drawing.Point(6, 72);
            this.batchCheckBox.Name = "batchCheckBox";
            this.batchCheckBox.Size = new System.Drawing.Size(150, 17);
            this.batchCheckBox.TabIndex = 7;
            this.batchCheckBox.Text = "Change Batch Size (<100)";
            this.batchCheckBox.UseVisualStyleBackColor = true;
            // 
            // BulkLoaderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(770, 353);
            this.Controls.Add(this.loaderSplitContainer);
            this.Name = "BulkLoaderForm";
            this.Text = "BulkLoader";
            this.Load += new System.EventHandler(this.BulkLoaderForm_Load);
            this.sourceGroupBox.ResumeLayout(false);
            this.destinationGroupBox.ResumeLayout(false);
            this.optionGroupBox.ResumeLayout(false);
            this.optionGroupBox.PerformLayout();
            this.loaderSplitContainer.Panel1.ResumeLayout(false);
            this.loaderSplitContainer.Panel2.ResumeLayout(false);
            this.loaderSplitContainer.ResumeLayout(false);
            this.loaderSplitContainer1.Panel1.ResumeLayout(false);
            this.loaderSplitContainer1.Panel2.ResumeLayout(false);
            this.loaderSplitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox sourceGroupBox;
        private System.Windows.Forms.GroupBox destinationGroupBox;
        private System.Windows.Forms.GroupBox optionGroupBox;
        private System.Windows.Forms.TreeView dirTreeView;
        private System.Windows.Forms.ComboBox dirComboBox;
        private System.Windows.Forms.Button refreshButton;
        private System.Windows.Forms.TreeView osTreeView;
        private System.Windows.Forms.ComboBox osComboBox;
        private System.Windows.Forms.TextBox batchTextBox;
        private System.Windows.Forms.Label batchLabel;
        private System.Windows.Forms.CheckBox includeCheckBox;
        private System.Windows.Forms.RichTextBox exceptionTextBox;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Button loadButton;
        private System.Windows.Forms.ImageList iconImageList;
        private System.Windows.Forms.SplitContainer loaderSplitContainer;
        private System.Windows.Forms.SplitContainer loaderSplitContainer1;
        private System.Windows.Forms.CheckBox batchCheckBox;



    }
}