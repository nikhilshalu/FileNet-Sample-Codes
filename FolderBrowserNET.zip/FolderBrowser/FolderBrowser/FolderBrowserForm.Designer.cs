namespace FolderBrowser
{
    partial class FolderBrowserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.osLabel = new System.Windows.Forms.Label();
            this.osComboBox = new System.Windows.Forms.ComboBox();
            this.closeButton = new System.Windows.Forms.Button();
            this.statusLabel = new System.Windows.Forms.Label();
            this.folderListBox = new System.Windows.Forms.ListBox();
            this.folderTreeView = new System.Windows.Forms.TreeView();
            this.folderSplitContainer = new System.Windows.Forms.SplitContainer();
            this.folderSplitContainer.Panel1.SuspendLayout();
            this.folderSplitContainer.Panel2.SuspendLayout();
            this.folderSplitContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // osLabel
            // 
            this.osLabel.AutoSize = true;
            this.osLabel.Location = new System.Drawing.Point(110, 12);
            this.osLabel.Name = "osLabel";
            this.osLabel.Size = new System.Drawing.Size(55, 13);
            this.osLabel.TabIndex = 0;
            this.osLabel.Text = "Select OS";
            // 
            // osComboBox
            // 
            this.osComboBox.FormattingEnabled = true;
            this.osComboBox.Location = new System.Drawing.Point(171, 9);
            this.osComboBox.Name = "osComboBox";
            this.osComboBox.Size = new System.Drawing.Size(290, 21);
            this.osComboBox.TabIndex = 1;
            this.osComboBox.SelectedIndexChanged += new System.EventHandler(this.osComboBox_SelectedIndexChanged);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(259, 398);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 3;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Location = new System.Drawing.Point(13, 382);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(129, 13);
            this.statusLabel.TabIndex = 4;
            this.statusLabel.Text = "Select OS to view Folders";
            // 
            // folderListBox
            // 
            this.folderListBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.folderListBox.FormattingEnabled = true;
            this.folderListBox.HorizontalScrollbar = true;
            this.folderListBox.Location = new System.Drawing.Point(0, 0);
            this.folderListBox.Margin = new System.Windows.Forms.Padding(0);
            this.folderListBox.Name = "folderListBox";
            this.folderListBox.Size = new System.Drawing.Size(336, 342);
            this.folderListBox.Sorted = true;
            this.folderListBox.TabIndex = 0;
            // 
            // folderTreeView
            // 
            this.folderTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.folderTreeView.Location = new System.Drawing.Point(0, 0);
            this.folderTreeView.Name = "folderTreeView";
            this.folderTreeView.Size = new System.Drawing.Size(239, 343);
            this.folderTreeView.TabIndex = 0;
            this.folderTreeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.folderTreeView_AfterSelect);
            // 
            // folderSplitContainer
            // 
            this.folderSplitContainer.Location = new System.Drawing.Point(15, 36);
            this.folderSplitContainer.Name = "folderSplitContainer";
            // 
            // folderSplitContainer.Panel1
            // 
            this.folderSplitContainer.Panel1.Controls.Add(this.folderTreeView);
            // 
            // folderSplitContainer.Panel2
            // 
            this.folderSplitContainer.Panel2.Controls.Add(this.folderListBox);
            this.folderSplitContainer.Size = new System.Drawing.Size(579, 343);
            this.folderSplitContainer.SplitterDistance = 239;
            this.folderSplitContainer.TabIndex = 2;
            // 
            // FolderBrowserForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(606, 433);
            this.Controls.Add(this.statusLabel);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.folderSplitContainer);
            this.Controls.Add(this.osComboBox);
            this.Controls.Add(this.osLabel);
            this.Name = "FolderBrowserForm";
            this.Text = "Folder Browser";
            this.Load += new System.EventHandler(this.FolderBrowser_Load);
            this.folderSplitContainer.Panel1.ResumeLayout(false);
            this.folderSplitContainer.Panel2.ResumeLayout(false);
            this.folderSplitContainer.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label osLabel;
        private System.Windows.Forms.ComboBox osComboBox;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.ListBox folderListBox;
        private System.Windows.Forms.TreeView folderTreeView;
        private System.Windows.Forms.SplitContainer folderSplitContainer;
    }
}