//  ------------------------------------------------------------
//  VCS INFO:
//  
//  $Revision:   1.1  $
//  $Date:   Oct 10 2001 16:38:58  $
//  $Workfile:   VWResource.java  $
//  ------------------------------------------------------------
//  All Rights Reserved.  Copyright (c) 1998-1999 FileNET Corp.
//  ------------------------------------------------------------

package samples.vwpanel.samplelaunch.resources;

/**
 * This class holds resources for the sample launch step processor.
 * @version 1, 0
 * @since IWWS1.00
 */
public class VWResource
{
	public static final String s_appTitle = new String("Panagon WorkFlo Launch Step Processor");
}